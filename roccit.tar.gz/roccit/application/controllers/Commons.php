<?php
class commons extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function show_locations()
	{
		$arr = array('status' => '1', 'locations' => array('manufacturing'=>'Manufacturing','calibration'=>'Calibration','shipping'=>'Shipping', 'repair'=>'Repair', 'customer'=>'Customer'));
		echo json_encode($arr); die;
	}
}
?>