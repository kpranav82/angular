<?php
class checklist extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model("instrument_model");
        $this->load->model("event_model");
        $this->load->model('users_model');
        $this->load->model('models_model');
        $this->load->model('customers_model');
	}

	public function checklist($id)
	{
		if(!empty($raw_json))
		{
			$arr = objectToArray($rawjson);
		}
		else
		{
			$arr =array();
		}
		if($id == '')
		{
			$msg = array('status'=>'0', 'message'=>'Please Enter Instrument ID'); 
		}
		else
		{
			$instrument_arr['instrument_id'] = clean($id);
			$result_instrument = $this->instrument_model->get_instrument($instrument_arr['instrument_id']);
			convertMongoIds($result_instrument);
			if($result_instrument)
				{
				$result = $this->models_model->get_model($result_instrument['model_id']);
				if($result)
				{
					$msg =array('status' => '1', 'result' =>array("identifier"=>$result['identifier'], "description" => $result['description'], "attributes" => $result['attributes'] , "attributeDefaults" =>$result['attributeDefaults'] ,"checklists" => $result['checklists']));
				}
				else
				{
					$msg =array('status'=>'0', 'message'=>'No Model Found');	
				}
				}
			else
			{
				$msg =array('status'=>'0', 'message'=>'No Instrument Found');
			}
		}
		echo json_encode($msg);
	}	
} 
?>