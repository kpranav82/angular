<?php 

class Error extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
	}
	
	
	public function index() {
		echo 'Please select a API Controller';
	}
}

?>