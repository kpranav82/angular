<?php

error_reporting(E_ALL);

class attributes extends MY_Controller {

    function __construct() {
        parent :: __construct();
        $this->load->model('attributes_model');
    }

    public function add_attribute() {
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $type = array('bool', 'num', 'str', 'option', 'date');
        if ($arr['attribute_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Your Attribute ID');
        } else if ($this->check_attribute_availabilty($arr["attribute_id"])) {
            $msg = array("status" => "0", "message" => "This Attribute ID already exists, Please try another");
        } else if ($arr['name'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Your Name');
        } else if ($arr['description'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Description');
        } else if ($arr['type'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Select Type');
        } else if (!in_array($arr['type'], $type)) {
            //echo 'here'; die;
            $msg = array('status' => '0', 'message' => 'Please Select Valid type of Type');
        }
        /* else if($arr['measured'] == '')
          {
          //echo 'here'; die;
          $msg = array('status'=>'0','message'=>'Please Fill Measured Field');
          } */ else if ($arr['default'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Fill Default Field');
        } else if ($arr['type'] == 'bool' && ($arr['default'] != "true" && $arr['default'] != "false")) {
            $msg = array('status' => '0', 'message' => 'Please enter correct default Value');
        } else {
            $attribute_arr['attribute_id'] = clean($arr['attribute_id']);
            $attribute_arr['name'] = clean($arr['name']);
            $attribute_arr['description'] = clean($arr['description']);
            $attribute_arr['type'] = clean($arr['type']);
            $attribute_arr['default'] = clean($arr['default']);
            $result = $this->attributes_model->add_attributes($attribute_arr);
            if ($result) {
                $msg = array('status' => '1', 'message' => 'Attribute Insertion Successfully');
            } else {
                $msg = array('status' => '0', 'message' => 'Something went wrong');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function check_attribute_availabilty($id) {
        $result = $this->attributes_model->get_all_attributes_list();
        foreach ($result as $value) {
            if (isset($value['attribute_id']) && strtolower($value['attribute_id']) == strtolower($id)) {
                return true;
            }
        }
    }

    public function get_attributes_list() {
        $search = $this->input->get('q');
        if ($search == '' || $search == 'undefined') {
            $search = '';
        } else {
            $search = $search;
        }
        $num_rec_per_page = 10;
        //echo $this->uri->segment(3); die;
        if ($this->uri->segment(3)) {
            $page = $this->uri->segment(3);
        } else {
            $page = 1;
        }
        //      $page = 3;
        $start_from = ($page - 1) * $num_rec_per_page; //offset
        $result = $this->attributes_model->get_attributes_list($start_from, $num_rec_per_page, $search);
        $records = $this->attributes_model->get_all_attributes_list($search);
        //print_r($result); die;
        convertMongoIds($result);
        if ($result) {
            $msg = array('status' => '1', 'message' => 'List of Attributes', 'List' => $result, 'total_records' => count($records)
                , 'per_page' => $num_rec_per_page);
        } else {
            $msg = array('status' => '0', 'message' => 'No Attributes Found');
        }
        echo json_encode($msg);
        die;
    }

    public function get_attribute($id) {
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $type = array('bool', 'num', 'str', 'option', 'date');
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Attribute ID');
        } else {

            $attribute_arr['attribute_id'] = clean($id);
            $result = $this->attributes_model->get_attribute($attribute_arr['attribute_id']);
            if ($result) {
                convertMongoIds($result);
                $msg = array('status' => '1', 'user' => array('id' => $result['_id'], 'name' => $result['name'], 'description' => $result['description'], 'type' => $result['type'], 'default' => $result['default']));
            } else {
                $msg = array('status' => '0', "message" => 'No Attribute Found');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function update_attribute() {
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $type = array('bool', 'num', 'str', 'option', 'date');
        if ($arr['attribute_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Attribute ID ');
        } else if ($arr['name'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Name');
        } else if ($arr['description'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Description');
        } else if ($arr['type'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter type');
        } else if (!in_array($arr['type'], $type)) {
            $msg = array('status' => '0', 'message' => 'Please Select Valid type of Type');
        }
        /* else if($arr['measured'] == '')
          {
          $msg = array('status'=>'0','message'=>'Please Fill Measured Field');
          } */ else if ($arr['default'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Fill Default Field');
        } else if ($arr['type'] == 'bool' && ($arr['default'] != "true" && $arr['default'] != "false")) {
            $msg = array('status' => '0', 'message' => 'Please enter correct default Value');
        } else {
            $attribute_arr['attribute_id'] = clean($arr['attribute_id']);
            $attribute_arr['name'] = clean($arr['name']);
            $attribute_arr['description'] = clean($arr['description']);
            $attribute_arr['type'] = clean($arr['type']);
            $attribute_arr['default'] = clean($arr['default']);
            $result = $this->attributes_model->update_attribute($attribute_arr);
            if ($result) {
                $msg = array('status' => '1', 'message' => 'Update Profile Successfully');
            } else {
                $msg = array('status' => '0', 'message' => 'something went wrong');
            }
        }
        echo json_encode($msg);
    }

}

?>