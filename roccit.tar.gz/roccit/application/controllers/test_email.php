<?php

class test_email extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('email_model');
	}
	
	public function email_test() {
		$arr['to'] = 'pranav.slinfy@gmail.com';
		$arr['subject'] = 'pranav.slinfy@gmail.com';
		$arr['message'] = 'pranav.slinfy@gmail.com';
		
		$context = stream_context_create();
		$result = stream_context_set_option($context, 'ssl', 'verify_peer', false);

		$socket = stream_socket_client('ssl://'.$host . ':443', $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
		$this->email_model->sendIndividualEmail();		
	}
}