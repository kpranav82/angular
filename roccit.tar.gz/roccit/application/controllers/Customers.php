<?php

class customers extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('customers_model');
       // $this->load->model('customers_model_test');
        $this->load->model('instrument_model');
        $this->load->model('users_model');
    }

    function index() {
         echo 'Please select api controller';
        die;
    }

    /*function add_customers() {
        // for adding customer http://192.168.1.64/roccit/customer/register
        $rawjson= json_decode(file_get_contents("php://input"));
        if(!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $arr["creator"] = $this->session->userdata('user_id');
        if ($arr['name'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Customer Name');
        } else if ($arr['details'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Customer infomation');
        } else if ($arr['creator'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Creator ID');
        } else {
            $customer_arr['name'] = $arr['name'];
            $customer_arr['details'] = $arr['details'];
            $customer_arr['creator'] = $arr['creator'];
            $result = $this->customers_model->add_customers($customer_arr);
            if ($result) {
                $msg = array('status' => '1', 'message' => 'Customer Add Successfully');
            } else {
                $msg = array('status' => '0', 'message' => 'Something Went Wrong Please Try Again');
            }
        }
        echo json_encode($msg);
    }
*/
  /*  public function list_customers() {
        $search = $this->input->get('q');
        if($search == '' || $search == 'undefined') {
            $search = '';
        } else {
            $search = $search;
        }
        $num_rec_per_page = 10;
        if($this->uri->segment(3))
        {
            $page = $this->uri->segment(3);
        }
        else
        {
            $page = 1;
        }
        $start_from = ($page - 1)* $num_rec_per_page;
        $records = $this->customers_model->list_customers($search);
        $result_customers = $this->customers_model_test->all_list_customers($start_from, $num_rec_per_page,$search);
        convertMongoIds($result_customers);
        $result_user = $this->users_model->user_list();
        $result = array();
        foreach ($result_customers as $value) {
           $user_id = array_search($value['creator'], array_column($result_user, '_id'));
           $value['user_name'] = $result_user[$user_id]['name'];
           $value['created_at'] = date('Y-m-d',$value['created_at']);
           $result[] = $value;
        }
        if ($result) {
            $msg = array('status' => '1', 'message' => 'List of Customers' ,'List' => $result,'total_records'=>count($records)
                ,'per_page'=>$num_rec_per_page);
        } else {
            $msg = array('status' => '0', 'message' => 'No Customers found');
        }
        echo json_encode($msg);
    }
*/
 /*   public function profile($id)
    {
        if(!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $arr["user_id"] = $this->session->userdata('user_id');
    	if($arr['user_id'] == '')
    	{
    		$msg = array('status'=>'0','message'=>'Please enter USer ID');
    	}
    	else if($id == '')
    	{
    		$msg = array('status'=>'0','message'=>'Please enter Customer Id');
    	}
    	else
    	{
            $c_profile['customer_id'] = $id;
            $result  = $this->customers_model->get_customer($c_profile);
            convertMongoIds($result);
            $user_data = $this->users_model->get_user($result['creator']);
    		if($result)
    		{
    			$msg = array('status'=>'1','customer'=>array('name'=>$result['name'], 'details'=>$result['details'], 'created_by' =>$result['creator'], 'user_name' =>$user_data['name']));
    		}
    		else
    		{
    			      $msg = array('status'=>'0','message'=> 'No Customer Exist');
    		}
    	}
    	echo json_encode($msg);
    }

    public function update_customer() {
        $rawjson= json_decode(file_get_contents("php://input"));
        if(!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        if($arr['customer_id'] == '')
        {
            $msg = array('status'=>'0', 'message'=>'Please Enter Customer ID');
        }
        else if($arr['name'] == '')
        {
            $msg = array('status'=>'0', 'message'=>'Please Enter Name');
        }
        else if($arr['details'] == '')
        {
            $msg = array('status'=>'0','message'=>'Please Enter Details');
        }
        else
        {
            $c_update['customer_id'] = $arr['customer_id'];
            $c_update['name'] = $arr['name'];
            $c_update['details'] = $arr['details'];
            $update = $this->customers_model->update_customer($c_update);
            if ($update) {
                $msg = array('status' => '1', 'message' => 'Update Profile Successfully');
            } else {
                $msg = array('status' => '0', 'message' => 'something went wrong');
            }
        }
        echo json_encode($msg);   
    }

        public function get_instrument_by_customer($id)
    {
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter customer ID');
        }
        else {
            $search = $this->input->get('q');
            if($search == '' || $search == 'undefined') {
            $search = '';
            } else {
            $search = $search;
            }
        
            $num_rec_per_page = 10;
            if ($this->uri->segment(4)) {
                $page = $this->uri->segment(4);
            } else {
                $page = 1;
            }
            $start_from = ($page - 1) * $num_rec_per_page;//offset
            $customer_arr['customer_id'] = clean($id);
            $result = $this->instrument_model->get_instrument_by_customer($customer_arr['customer_id'],$start_from, $num_rec_per_page,$search);
            $customer_data = $this->customers_model->get_customer($customer_arr);
            $customer_name =$customer_data['name'];
            //print_r($customer_name); die;
            $record = $this->instrument_model->get_instrument_by_customer_old($customer_arr['customer_id'],$search);
            $customer = $this->customers_model->list_customers();
            convertMongoIds($customer);
            //print_r($customer); die;
            if ($result) {
                convertMongoIds($result);
                $msg = array('status' => '1', 'message' => 'List of Instrument', 'List' => $result, 'customer_list' => $customer , 'total_records'=>count($record)
                ,'per_page'=>$num_rec_per_page, 'customer_name' => $customer_name);
            } else {
                $msg = array('status' => '0', "message" => 'No Instrument Found', 'customer_list' => $customer, 'customer_name' => $customer_name);
            }
        }
        echo json_encode($msg);
        die;
    }


    public function delete_customers($id)
    {
        if(!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $arr["user_id"] = $this->session->userdata('user_id');
        if($arr['user_id'] == '')
        {
            $msg = array('status'=>'0','message'=>'Please enter USer ID');
        }
        else if($id == '')
        {
            $msg = array('status'=>'0','message'=>'Please enter Customer Id');
        }
        else
        {
            $arr['customer_id'] = $id;
            $result = $this->customers_model->get_customer($arr);
            //print_r($result); die;
            if($result)
            {
                convertMongoIds($result);
                //print_r($result); die;
                $customer_id = $arr['customer_id'];
                $user_id = $arr['user_id'];
                 
                $deleted = $this->customers_model->delete_customers($arr);
                if ($deleted) {
                    $msg = array('status' => '1', 'message' => 'Customer Succesfully Deleted');
                } else {
                    $msg = array('status' => '0', 'message' => 'Customer Not Exist');
                }
            }
            else
            {
                $msg = array('status'=>'0' , 'message'=>'Customer Not exist');
            }
        }
        echo json_encode($msg);
    }
*/
}
?>