<?php

class login extends CI_Controller {

    public function __construct() {
        parent ::__construct();
        $this->load->model('users_model');
        $this->load->helper('jwt');
    }

    public function register() {
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        //API for User Registration    http://192.168.1.64/roccit/login/register?name=Pranav%20Kumar&email=pranav.slinfy@gmail.com&password=12345678&confirm_password=12345678

        if ($arr['name'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter your Name");
        } else if ($arr['email'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Email");
        } else if (!$this->common->validate_email($arr["email"])) {
            $msg = array("status" => "0", "message" => "Please Enter Valid Type of Email");
        } else if (!$this->common->check_email_availabilty($arr["email"])) {
            $msg = array("status" => "0", "message" => "This email already exists, Please try another");
        } else if ($arr['password'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Password");
        } else if (strlen($arr["password"]) < 6 || strlen($arr["password"]) > 15) {
            $msg = array("status" => "0", "message" => "Your password must be between 6 and 15 characters long ");
        } else if ($arr['confirm_password'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Confirm Password");
        } else if ($arr['confirm_password'] != $arr['password']) {
            $msg = array("status" => "0", "message" => "Mismatch Password");
        } else {
            $register_arr['name'] = clean($arr['name']);
            $register_arr['email'] = clean($arr['email']);
            $register_arr['password'] = clean($arr['password']);
            $register_arr['password'] = $this->common->salt_password($register_arr);
            $result = $this->users_model->add_users($register_arr);
            if ($result) {
                $msg = array("status" => "1", "message" => 'User Register Successfully');
            } else {
                $msg = array("status" => "1", "message" => 'something went wrong please try again');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function login() {
        //APi for User Login   http://192.168.1.64/roccit/login/login?email=pranav.slinfy@gmail.com&password=123456
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }

        if ($arr["email"] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Email");
        } else if (!$this->common->validate_email($arr["email"])) {
            $msg = array("status" => "0", "message" => "Email Should be Valid");
        } else if ($arr["password"] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Password");
        } else {
            $login_arr['email'] = clean($arr['email']);
            $login_arr['password'] = clean($arr['password']);
            $result = $this->users_model->check_login($login_arr);

            if (!empty($result)) {
                convertMongoIds($result);
                if ($this->common->validateHash($login_arr["password"], $result["password"])) {
                    $msg = array('status' => '1', 'message' => 'Logged In', 'user_id' => $result["_id"], 'name' => $result['name'], 'email' => $result['email']);

                    $this->session->set_userdata('email', $result['email']);
                    $this->session->set_userdata('user_id', $result['_id']);
                    $this->session->set_userdata('name', $result['name']);
                    $this->session->set_userdata('is_logged_in', true);
                    if (!empty($arr['remebr'])) {
                        $cookiedata = $result['email'] . '||' . $result['_id'] . '||' . $result['name'];
                        $token = array();
                        $token['email'] = $result['email'];
                        $token['user_id'] = $result['_id'];
                        $token['name'] = $result['name'];
                        $cookiedata = JWT::encode($token, $this->config->item('jwt_secure_key'));
                        //print_r($cookiedata); die;
                        $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
                        setcookie("roccit_session", $cookiedata, strtotime('+30 days'), '/roccit/', $domain, false);
                    }
                } else {
                    $msg = array('status' => '0', 'message' => 'Invalid Username / Password');
                }
            } else {
                $msg = array('status' => '0', 'message' => 'No User Exist for this Email');
            }
        }

        echo json_encode($msg);
    }

    public function s_m() {
        //for check whether user login or not    http://112.196.33.88/roccit/login/s_m
        if (!empty($_COOKIE['roccit_session'])) {
            $token = JWT::decode($_COOKIE['roccit_session'], $this->config->item('jwt_secure_key'));
            $this->session->set_userdata('email', $token->email);
            $this->session->set_userdata('user_id', $token->user_id);
            $this->session->set_userdata('name', $token->name);
            $this->session->set_userdata('is_logged_in', true);
        }
        if ((bool) $this->session->userdata('is_logged_in')) {
            $msg['status'] = 1;
            $msg['details']['message'] = 'logged in';
            $msg['details']['email'] = $this->session->userdata('email');
            $msg['details']['user_id'] = $this->session->userdata('user_id');
            $msg['details']['name'] = $this->session->userdata('name');
            echo json_encode($msg);
            die;
        } else {
            $msg['status'] = 0;
            $msg['details']['message'] = 'not logged in';
            echo json_encode($msg);
            die;
        }
    }

    public function forget_password() {
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        if ($arr['email'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Your Email');
        } else if (!$this->common->validate_email($arr["email"])) {
            $msg = array("status" => "0", "message" => "Please Enter Valid Type of Email");
        } else if($this->common->check_email_availabilty($arr["email"])) {
            $msg = array("status" => "0", "message" => "This email does not exists, Please try another");
        }
        else
        {
            $msg =array("status"=>'4', "message"=>'under progress');
        }
        echo json_encode($msg);
    }

    public function logout() {

        session_start();
        $this->session->sess_destroy();
        $_SESSION = array();
        //unset($_COOKIE['roccit_session']);
        setcookie("roccit_session", "", time() - 3600, '/roccit/');
		if (isset($_COOKIE['roccit_session'])) {
			unset($_COOKIE['roccit_session']);
			setcookie('roccit_session', null, -1, '/roccit/');
			return true;
		} else {
			return false;
		}
        session_name('');
        session_destroy();
		//echo 'delete'; die;
        $msg = array('status' => '1', 'message' => 'You Are Successfully Logged out');
        echo json_encode($msg); die;
    }

    public function csrf_token() {
        $csrf = array(
            'name' => $this->security->get_csrf_token_name(),
            'hash' => $this->security->get_csrf_hash()
        );
        echo json_encode($csrf);
        die;
    }
    
}

?>