<?php

class Login extends CI_Controller {

    public function __construct() {
        parent ::__construct();
        $this->load->model('users_model');
        $this->load->model('Email_model');
        $this->load->helper('jwt');
    }

    public function register() {
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        //API for User Registration    http://192.168.1.64/roccit/login/register?name=Pranav%20Kumar&email=pranav.slinfy@gmail.com&password=12345678&confirm_password=12345678

        if ($arr['name'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter your Name");
        } else if ($arr['email'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Email");
        } else if (!$this->common->validate_email($arr["email"])) {
            $msg = array("status" => "0", "message" => "Please Enter Valid Type of Email");
        } else if (!$this->common->check_email_availabilty($arr["email"])) {
            $msg = array("status" => "0", "message" => "This email already exists, Please try another");
        } else if ($arr['password'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Password");
        } else if (strlen($arr["password"]) < 6 || strlen($arr["password"]) > 15) {
            $msg = array("status" => "0", "message" => "Your password must be between 6 and 15 characters long ");
        } else if ($arr['confirm_password'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Confirm Password");
        } else if ($arr['confirm_password'] != $arr['password']) {
            $msg = array("status" => "0", "message" => "Mismatch Password");
        } else {
            $register_arr['name'] = clean($arr['name']);
            $register_arr['email'] = clean($arr['email']);
            //$register_arr['password'] = clean($arr);
            $register_arr['password'] = $this->common->salt_password($arr);
            $register_arr['confirm_code'] = $this->common->generate_random_number_for_numbers();
            $result = $this->users_model->add_users($register_arr);

            if ($result) {
                $register_arr['verification_link'] = 'http://198.61.174.115/angular/#/login?id='.base64_encode($result->{'$id'}). '&code='.$register_arr['confirm_code'];
            	//$registerarr
                $template = $this->load->view('templates/email_template',$register_arr,true);
				//$email_mail = mail($register_arr['email'], 'Verify Email', $template, 'kpranav82@yahoo.in');
            	$emailarr['to'] = $register_arr['email'];
                $emailarr['subject'] =  'Verify Email';
                $emailarr['message'] = $template;
            	//$email_mail = $this->Email_model->sendIndividualEmail($emailarr);
				$msg = "First line of text\nSecond line of text";

				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,70);
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				$headers .= 'From: Roccit <no-reply@roccit.us>' . "\r\n";
// send email
				if(mail($emailarr['to'],$emailarr['subject'],$template, $headers)){

                /*$emailarr["message"] = "Welcome," . "<br/>" . "name: " . $register_arr['name'];
                $emailarr["to"] = $register_arr['email'];
                $emailarr['subject'] = 'Account Verification Mail';*/
                //$email_mail = $this->Email_model->sendIndividualEmail($emailarr);
               // if ($email_mail == 0) {
                    $msg = array("status" => "1", "message" => "Your account was successfully created. Please check your inbox for a confirmation mail.");
                }
                else {
                    $msg = array("status" => "0", "message" => "There was error in adding this user.");
                }
            } else {
                $msg = array("status" => "0", "message" => 'something went wrong please try again');
            }
        }
        echo json_encode($msg);
        die;
    }

        public function resend_verification_code() {
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        if ($arr['email'] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Email");
        } else if (!$this->common->validate_email($arr["email"])) {
            $msg = array("status" => "0", "message" => "Please Enter Valid Type of Email");
        } else if ($this->common->check_email_availabilty($arr["email"])) {
            $msg = array("status" => "0", "message" => "This email does not exists");
        } else {
            $register_arr['email'] = clean($arr['email']);
            $get_user_by_email = $this->users_model->get_user_by_email($register_arr['email']);
            convertMongoIds($get_user_by_email);
            //debug($get_user_by_email['_id']); die;
            $register_arr['confirm_code'] = $this->common->generate_random_number_for_numbers();
            $result = $this->users_model->update_confirm_code_update($register_arr);
            //debug($result); die;
            if ($result) {
            $register_arr['name'] = $get_user_by_email['name'];
                $register_arr['verification_link'] = 'http://198.61.174.115/angular/#/login?id='.base64_encode($get_user_by_email['_id']). '&code='.$register_arr['confirm_code'];
            //'http://198.61.174.115/angular/#/login#'.base64_encode($result->{'$id'}). '#'.$register_arr['confirm_code'];
                $template = $this->load->view('templates/email_template',$register_arr,true);
				//$email_mail = mail($register_arr['email'], 'Verify Email', $template, 'kpranav82@yahoo.in');
            	$emailarr['to'] = $register_arr['email'];
                $emailarr['subject'] =  'Verify Email';
                $emailarr['message'] = $template;
            	$email_mail = $this->Email_model->sendIndividualEmail($emailarr);
                if ($email_mail == 0) {
                    $msg = array("status" => "1", "message" => "Your account got your confirmation mail. Please check your inbox for a confirmation mail.");
                }
                else {
                    $msg = array("status" => "0", "message" => "There was error in adding this user.");
                }
            } else {
                $msg = array("status" => "0", "message" => 'something went wrong please try again');
            }
        }
        echo json_encode($msg);
        die;
    }
    public function login() {
        //APi for User Login   http://192.168.1.64/roccit/login/login?email=pranav.slinfy@gmail.com&password=123456
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }

        if ($arr["email"] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Your Email");
        } else if (!$this->common->validate_email($arr["email"])) {
            $msg = array("status" => "0", "message" => "Email Should be Valid");
        } else if ($arr["password"] == '') {
            $msg = array("status" => "0", "message" => "Please Enter Password");
        } else {
            $login_arr['email'] = clean($arr['email']);
            $login_arr['password'] = clean($arr['password']);
            $check_login_verification =  $this->users_model->check_login_verification($login_arr);
            if(!empty($check_login_verification)){
                $msg = array('status' => '0', 'message' => 'Please Verify Your Email First.','is_verified'=>'0');
                echo json_encode($msg); die;
            }
            $result = $this->users_model->check_login($login_arr);

            if (!empty($result)) {
                convertMongoIds($result);
                if ($this->common->validateHash($login_arr["password"], $result["password"])) {
                    $msg = array('status' => '1', 'message' => 'Logged In', 'user_id' => $result["_id"], 'name' => $result['name'], 'email' => $result['email'], 'is_verified'=>'1');

                    $this->session->set_userdata('email', $result['email']);
                    $this->session->set_userdata('user_id', $result['_id']);
                    $this->session->set_userdata('name', $result['name']);
                    $this->session->set_userdata('is_logged_in', true);
                    if (!empty($arr['remebr'])) {
                        $cookiedata = $result['email'] . '||' . $result['_id'] . '||' . $result['name'];
                        $token = array();
                        $token['email'] = $result['email'];
                        $token['user_id'] = $result['_id'];
                        $token['name'] = $result['name'];
                        $cookiedata = JWT::encode($token, $this->config->item('jwt_secure_key'));
                        //print_r($cookiedata); die;
                        $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
                        setcookie("roccit_session", $cookiedata, strtotime('+30 days'), '/roccit/', $domain, false);
                    }
                } else {
                    $msg = array('status' => '0', 'message' => 'Invalid Username / Password');
                }
            } else {
                $msg = array('status' => '0', 'message' => 'No User Exist for this Email');
            }
        }

        echo json_encode($msg);
    }

        public function verification() {
        //APi for User Login   http://192.168.1.64/roccit/login/login?email=pranav.slinfy@gmail.com&password=123456
        //debug('here'); die;
        $verification_code = $this->uri->segment(3);
        $verification_code = base64_decode($verification_code);
        $confirm_code = $this->uri->segment(4);
        //debug($verification_code); debug($confirm_code); die;
        $get_data_by_id = $this->users_model->get_user($verification_code);
        convertMongoIds($get_data_by_id);
        if($get_data_by_id['_id'] == $verification_code && $get_data_by_id['confirm_code'] == $confirm_code && $get_data_by_id['is_verified'] == '0') {
        $verication_update =$this->users_model->verication_update($verification_code,$confirm_code);
        if ($verication_update) {
            $msg = array('status' => '1', 'message' => 'Verified Successfully', 'user_id' => $verification_code);

            } else {
        		//redirect('http://198.61.174.115/roccit/login', 'refresh');
        		//window.location.href="http://198.61.174.115/roccit/login";        
        $msg = array('status' => '0', 'message' => 'No User Exist or already verified for this Email');
            }
        }
        else {
             $msg = array('status' => '0', 'message' => 'No User Exist or already verified for this Email');
        }

        echo json_encode($msg);
    }


    public function s_m() {
        //for check whether user login or not    http://112.196.33.88/roccit/login/s_m
        if (!empty($_COOKIE['roccit_session'])) {
            $token = JWT::decode($_COOKIE['roccit_session'], $this->config->item('jwt_secure_key'));
            $this->session->set_userdata('email', $token->email);
            $this->session->set_userdata('user_id', $token->user_id);
            $this->session->set_userdata('name', $token->name);
            $this->session->set_userdata('is_logged_in', true);
        }
        if ((bool) $this->session->userdata('is_logged_in')) {
            $msg['status'] = 1;
            $msg['details']['message'] = 'logged in';
            $msg['details']['email'] = $this->session->userdata('email');
            $msg['details']['user_id'] = $this->session->userdata('user_id');
            $msg['details']['name'] = $this->session->userdata('name');
            echo json_encode($msg);
            die;
        } else {
            $msg['status'] = 0;
            $msg['details']['message'] = 'not logged in';
            echo json_encode($msg);
            die;
        }
    }

       public function forget_password() {
        $rawjson = json_decode(file_get_contents("php://input"));
        //debug($rawjson); die;
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        //debug($arr); die;
        if ($arr['email'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Your Email');
        } else if (!$this->common->validate_email($arr["email"])) {
            $msg = array("status" => "0", "message" => "Please Enter Valid Type of Email");
        } else if($this->common->check_email_availabilty($arr["email"])) {
            $msg = array("status" => "0", "message" => "This email does not exists");
        } 
        else
        {
        $check_login_verification =  $this->users_model->check_email_verification_for_password($arr);
            if(!empty($check_login_verification)){
                $msg = array('status' => '0', 'message' => 'Please Verify Your Email First.','is_verified'=>'0');
                echo json_encode($msg); die;
            }
            $register_arr['email'] = clean($arr['email']);
            $register_arr['confirm_code'] = $this->common->generate_random_number_for_numbers();
            $result = $this->users_model->update_confirm_code_for_password($register_arr);
            if ($result) {
                //$emailarr['verification_link'] = base_url() .'login/check_email_for_forgot_password/'.urldecode(base64_decode(utf8_encode($register_arr['email']))). '/'.$register_arr['confirm_code'];
                //$register_arr['verification_link'] = 'http://198.61.174.115/angular/#/updatepwd?id='.urlencode(base64_encode(utf8_encode($register_arr['email']))). '&code='.$register_arr['confirm_code'];
            $register_arr['verification_link'] = 'http://198.61.174.115/angular/#/updatepwd?id='.base64_encode(convert_uuencode($register_arr['email'])). '&code='.$register_arr['confirm_code'];    
            /*debug($register_arr['confirm_code']);
                //http://198.61.174.115/angular/#/updatepwd
                debug($emailarr['verification_link']); die;
                */$template = $this->load->view('templates/reset_password',$register_arr,true);
                //$email_mail = mail($register_arr['email'], 'Verify Email', $template, 'kpranav82@yahoo.in');
                $emailarr['to'] = $register_arr['email'];
                $emailarr['subject'] =  'RESET PASSWORD';
                $emailarr['message'] = $template;
                $email_mail = $this->Email_model->sendIndividualEmail($emailarr);
                if ($email_mail == 0) {
                    $msg = array("status" => "1", "message" => "We have sent you a mail on your registered email ID to recover your password. Please check your Email.");
                }
                else {
                    $msg = array("status" => "0", "message" => "There was error in adding this user.");
                }
                //debug($emailarr); die; 
            }
                else {
                    $msg = array("status" => "0", "message" => "Something went wrong Please Try again");
                }
        }
        echo json_encode($msg);
        die;
    }

    public function logout() {

        session_start();
        $this->session->sess_destroy();
        $_SESSION = array();
        //unset($_COOKIE['roccit_session']);
        setcookie("roccit_session", "", time() - 3600, '/roccit/');
        if (isset($_COOKIE['roccit_session'])) {
         unset($_COOKIE['roccit_session']);
         setcookie('roccit_session', null, -1, '/roccit/');
         return true;
     } else {
         return false;
     }
     session_name('');
     session_destroy();
		//echo 'delete'; die;
     $msg = array('status' => '1', 'message' => 'You Are Successfully Logged out');
     echo json_encode($msg); die;
 }

 public function csrf_token() {
    $csrf = array(
        'name' => $this->security->get_csrf_token_name(),
        'hash' => $this->security->get_csrf_hash()
        );
    echo json_encode($csrf);
    die;
}

    public function check_email_for_forgot_password() {
            //APi for User Login   http://192.168.1.64/roccit/login/login?email=pranav.slinfy@gmail.com&password=123456
            //debug('here'); die;
            $email = $this->uri->segment(3);
            $email = base64_decode($email);
            $confirm_code = $this->uri->segment(4);
            //echo $verification_code; debug($confirm_code); die;
            debug($email); die;
            $get_data_by_email = $this->users_model->get_user_by_email_verified_user($email);
            debug($get_data_by_email); die;
            convertMongoIds($get_data_by_email);
            if($get_data_by_email['email'] == $email && $get_data_by_email['confirm_code'] == $confirm_code && $get_data_by_id['is_verified'] == '1') {
            /*$verication_update =$this->users_model->verication_update($verification_code,$confirm_code);
            if ($verication_update) {
                $msg = array('status' => '1', 'message' => 'Verified Successfully', 'user_id' => $verification_code);

                } else {
                    $msg = array('status' => '0', 'message' => 'No User Exist or already verified for this Email');
                }*/
                $msg = array('status' => '0', 'message' => 'herereerer');
            }
            else {
                 $msg = array('status' => '0', 'message' => 'No User Exist or already verified for this Email');
            }

            echo json_encode($msg);
        }

    public function email_update_password() {
        //APi for User Login   http://192.168.1.64/roccit/login/login?email=pranav.slinfy@gmail.com&password=123456
        //debug('here'); die;
        $rawjson = json_decode(file_get_contents("php://input"));
        //debug($rawjson); die;
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        //debug($arr); die;
        if ($arr['password'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Your Password');
        	echo json_encode($msg); die;
        }
        $verification_code = $this->uri->segment(3);
        $verification_code = convert_uudecode(base64_decode($verification_code));
        $confirm_code = $this->uri->segment(4);
        //$password = $arr['password'];
        $password = $this->common->salt_password($arr);
    	//debug($arr);
        //debug($verification_code); debug($confirm_code); die;
        $get_data_by_id = $this->users_model->get_user_by_email_verified_user($verification_code,$confirm_code);
        convertMongoIds($get_data_by_id);
    //debug($get_data_by_id); die;
        if($get_data_by_id['email'] == $verification_code && $get_data_by_id['confirm_code'] == $confirm_code && $get_data_by_id['is_verified'] == '1') {
        //debug($verification_code);  die;
        $email_password_update =$this->users_model->email_password_update($verification_code,$confirm_code, $password);
        if ($email_password_update) {
            $msg = array('status' => '1', 'message' => 'Password Updated Successfully', 'email' => $verification_code);

            } else {
                $msg = array('status' => '0', 'message' => 'Incorrect Email or confirm code');
            }
        }
        else {
             $msg = array('status' => '0', 'message' => 'Your confirmation link has been expired.');
        }

        echo json_encode($msg);
    }




}

?>