<?php
class location extends CI_Controller
{
	function __construct()
	{
		parent:: __construct();
		$this->load->model('location_model');
	}

	public function add_location()
	{
		$arr = array();
		$arr['name'] = clean($this->input->get_post("name"));
		if($arr['name'] == '')
		{
			$msg = array('status' => '0', 'message' => 'Please Enter Location Name');
		}
		else
		{
			$result = $this->location_model->add_location($arr);
			if($result)
			{
				$msg = array('status' => '1', 'message' => 'Location Inserted Successfully');
			}
			else
			{
				$msg = array('status' => '0', 'message' => 'Try Again!! something went wrong
					');
			}
		}
		echo json_encode($msg);
	}

	public function location_list()
	{
		$result = $this->location_model->location_list();
		convertMongoIds($result);
		if($result)
		{
			$msg = array('status' => '1', 'message' => 'List of Locations','list'=> $result);
		}
		else
		{
			$msg = array('status' => '0', 'message' => 'No Location found');	
		}
		echo json_encode($msg);
	}
}
?>