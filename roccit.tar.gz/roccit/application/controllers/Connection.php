<?php 
echo phpinfo();
?>