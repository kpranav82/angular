<?php

class models extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('models_model');
        $this->load->model('attributes_model');
    }

    public function add_model() {

        $last_record = $this->mongo_db->order_by(array('created_at' => 'DESC'))->limit(1)->get('models');
        //debug($last_record);
        if (empty($last_record[0])) {
            $identifier = '1-M';
        } else {
            $last_identifier = explode('-', $last_record[0]['identifier']);
            $last_identifier[0] = $last_identifier[0] + 1;
            $identifier = implode('-', $last_identifier);
        }
        $attributes = $this->attributes_model->get_attributes_model();
        convertMongoIds($attributes);
        //$count = count($attributes);
        foreach ($attributes as $key => $value) {
            //debug($value['attribute_id']);
            $attribute_id[] = $value['attribute_id'];
        }
        //debug($attribute_id);
        $attributes_id = json_encode($attribute_id);
        //debug($attributes_id);  
        //print_r($attributes); die;
        $json = '{
			"details": {
				"identifier": "",
				"description": "this is description",
				"checklists": [{
					"_id": "pre-cal inspection",
					"steps": ["make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)","All Plumbing is connected","make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)","make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)"]
				},{
                    "_id": "medium inspection",
                    "steps": ["medium make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)","All Plumbing is connected","make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)","make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)"]
                },{
                    "_id": "last inspection",
                    "steps": ["last make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)","All Plumbing is connected","make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)","make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)"]
                }]
			}
		}';
        $rawjson = json_decode($json);
        if (!empty($rawjson)) {
            $newarr = objectToArray($rawjson);
        } else {
            $newarr = array();
        }
        $arr = $newarr['details'];
        $model_arr['identifier'] = $identifier;
        $model_arr['description'] = $arr['description'];
        $model_arr['attributes'] = $attributes_id;
        //$model_arr['attributeDefaults'] = json_encode($arr['attributeDefaults']);
        $model_arr['checklists'] = json_encode($arr['checklists']);
        $result = $this->models_model->add_model($model_arr);
        convertMongoIds($result);
        if ($result) {
            $msg = array('status' => '1', 'message' => 'Model Insertion Successfully', 'id' => $result->{'$id'});
        } else {
            $msg = array('status' => '0', 'message' => 'Try Again!! something went Wrong');
        }

        echo json_encode($msg);
        die;
    }

    public function model_list() {
        $search = $this->input->get('q');
        if ($search == '' || $search == 'undefined') {
            $search = '';
        } else {
            $search = $search;
        }
        $num_rec_per_page = 10;
        if ($this->uri->segment(3)) {
            $page = $this->uri->segment(3);
        } else {
            $page = 1;
        }
        $start_from = ($page - 1) * $num_rec_per_page; //offset
        $records = $this->models_model->all_model_list($search);
        $result = $this->models_model->model_list($start_from, $num_rec_per_page, $search);
        convertMongoIds($result);
        if ($result) {
            $msg = array('status' => '1', 'message' => 'List of Models', 'List' => $result, 'total_records' => count($records), 'per_page' => $num_rec_per_page);
        } else {
            $msg = array('status' => '0', 'message' => 'No Model found');
        }
        echo json_encode($msg);
    }

    public function get_model($id) {
        //$rawjson= json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Model ID');
        } else {
            $model_arr['model_id'] = $id;
            $result = $this->models_model->get_model($model_arr['model_id']);
            if ($result) {
                convertMongoIds($result);
                $jsonraw = array("description" => $result['description'], "attributes" => json_decode($result['attributes']), "checklists" => json_decode($result['checklists']));
                $details = json_encode($jsonraw);
                //$msg = array('status' => '1', "message" => 'Model List', 'details' => stripslashes(stripslashes(str_replace('\n','',$details))));
                $msg = array('status' => '1', "message" => 'Model List', 'details' => ($details), 'identifier' => $result['identifier']);
            } else {
                $msg = array('status' => '0', "message" => 'No Model Found');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function update_model($id) {

        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $newarr = objectToArray($rawjson);
        } else {
            $newarr = array();
        }
	 //debug($newarr);
        $arr = $newarr['details'];
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Model ID');
        } else if ($newarr['identifier'] == '') {
            echo  'here'; die;
            $msg = array('status' => '0', 'message' => 'Please Enter identifier');
        } else if (!$this->common->check_model_availabilty($newarr["identifier"],$id)) {
        $msg = array("status" => "0", "message" => "This Model ID already exists, Please try another");
        } else if ($arr['description'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter description');
        } else if ($arr['attributes'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Attributes');
        } else if ($arr['checklists'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Checklist items');
        } else {
            $model_arr['model_id'] = $id;
            $model_arr['identifier'] = strtoupper($newarr['identifier']);
            $model_arr['description'] = $arr['description'];
            //$attributes[] = $arr['attributes'];
            //debug($model_arr);
            //debug($arr['attributes']);
            $i = 0;
            foreach ($arr['attributes'] as $key => $value) { 
                //debug($value);
                $data = $this->attributes_model->get_attribute_by_atributeid($value);
                if (empty($data)) {
                    $msg = array('status' => '0', 'message' => $value.' attribute not found');
                    echo json_encode($msg);
                    die;
                } else {
                    $attributes1[] = $value;
                }
            }
            //debug($attributes1);
            $model_arr['attributes'] = json_encode($attributes1);
            $checklists = $arr['checklists'];
            //debug($checklists);
            $attribute_value = array();
            foreach ($checklists as $key => $value) {
                //debug($value['steps']);
                if(!empty($value['steps']))
                {
                    foreach ($value['steps'] as $steps_key => $steps_value) {
                        //debug($steps_value);
                        if(strpos($steps_value,'_a') > -1){
                            /*echo 'tere';*/
                            $attribute_value[] =$steps_value;
                        }                          
                    }
                    //debug($attribute_value);
                }
            }
            $final_value = array();
            if(count($attribute_value) > 0){
                foreach ($attribute_value as $key => $value) {
                    //debug($value);
                    $final_array =explode(":", $value);
                    $final_value[] = $final_array[1];

                }
                //debug($final_value);
            }
                $i = 0;
                if(count($final_value) > 0){
                    foreach ($final_value as $key => $value) {
                        $data = $this->attributes_model->get_attribute_by_atributeid($value);
                        if (empty($data)) {
                            $msg = array('status' => '0', 'message' => $value.' attribute not found');
                            echo json_encode($msg);
                            die;
                        } else {
                            $checklists1 = $checklists;
                        }
                    }
                }else{
                    $checklists1 = $arr['checklists'];
                }
            $model_arr['checklists'] = json_encode($checklists1);
            //debug($model_arr); die;
            stripcslashes($result);
            $result = $this->models_model->update_model($model_arr);
            if ($result) {
                $msg = array('status' => '1', 'message' => 'Model Updated Successfully');
            } else {
                $msg = array('status' => '0', 'message' => 'Try Again!! something went Wrong');
            }
        }
        echo json_encode($msg);
    }

}

?>