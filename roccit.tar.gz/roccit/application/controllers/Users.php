<?php

class Users extends MY_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model("users_model");
    }

    public function index() {
        echo 'Please select api controller';
        die;
    }

    public function profile($id) {
        $rawjson= json_decode(file_get_contents("php://input"));
		if(!empty($rawjson)) {
			$arr = objectToArray($rawjson);
		} else {
			$arr = array();
		}
        if ($id == '') {
            //$msg["status"] = "0";
            //$msg["message"] = "Please Enter Your User ID";
            $msg = array('status' => '0', 'message' => 'Please Enter User ID');
            
        } else {
            $profile_arr['user_id'] = $id;
            $result = $this->users_model->get_user($profile_arr['user_id']);
            if ($result) {
                if($result['is_verified'] == 0) {
                    $msg = array('status' => '0', 'message'=>'USer Not Verified Till now');
                }
                else {    
                $msg = array('status' => '1', 'user' => array('email' => $result['email'], 'name' => $result['name']));
            } } else {
                $msg = array('status' => '0', "message" => 'No user Found');
            }
        }
        echo json_encode($msg);
    }

    public function update_user() {
		$rawjson= json_decode(file_get_contents("php://input"));
		if(!empty($rawjson)) {
			$arr = objectToArray($rawjson);
		} else {
			$arr = array();
		}
        $arr["user_id"] = $this->session->userdata('user_id');
        if ($arr['user_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter User ID');
        } else if ($arr['name'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Name');
        } else {

            $update_user_arr['user_id'] = $arr['user_id'];
            $update_user_arr['name'] = $arr['name'];
            if(!empty($arr['old_password'])) {
                $update_user_arr['old_password'] = $arr['old_password'];
            }
            if(!empty($arr['password'])) {
                $update_user_arr['password'] = $arr['password'];
            }
            /*if(!empty($arr['confirm_password'])) {
                $update_user_arr['confirm_password'] = $arr['confirm_password'];
            }*/
            if(!empty($update_user_arr['old_password'])) {
                $result = $this->users_model->get_user($update_user_arr['user_id']);
                if(!$this->common->validateHash($update_user_arr["old_password"], $result["password"])) {
                    $msg = array('status' => '0', 'message' => 'Old Password Mismatch'); 
                    echo json_encode($msg); die;
                }
            }
            if(!empty($update_user_arr['old_password']) && $update_user_arr['password'] == '') {
                 $msg = array('status' => '0', 'message' => 'Please Enter New Password'); 
                    echo json_encode($msg); die;
            }
            /*if(!empty($update_user_arr['old_password']) && $update_user_arr['password'] != '' && $update_user_arr['confirm_password'] == '') {
                 $msg = array('status' => '0', 'message' => 'Please Enter Confirm Password'); 
                    echo json_encode($msg); die;
            }
            if($update_user_arr['password'] != $update_user_arr['confirm_password']) {
                 $msg = array('status' => '0', 'message' => 'New Password Does Not Match With New Confirm Password'); 
                    echo json_encode($msg); die;
            }*/
			if(!empty($update_user_arr['password'])) {
				$result = $this->users_model->get_user($update_user_arr['user_id']);
				if($this->common->validateHash($update_user_arr["password"], $result["password"])) {
					unset($update_user_arr['password']);
                    unset($update_user_arr['old_password']);
				} else {
					$update_user_arr['password'] = $this->common->salt_password($arr);
                    unset($update_user_arr['old_password']);
				}
			} else {
				unset($update_user_arr['password']);
                unset($update_user_arr['old_password']);
			}
            //debug($update_user_arr); die;
            $result = $this->users_model->update_user($update_user_arr);
            if ($result) {
                $msg = array('status' => '1', 'message' => 'Update Profile Successfully');
            } else {
                $msg = array('status' => '0', 'message' => 'something went wrong');
            }
        }
        echo json_encode($msg);
    }

    public function user_list()
    {
        $result = $this->users_model->user_list();
        convertMongoIds($result);
        if ($result)
        {
            $msg = array('status' => '1', 'message' => 'List of Users' ,'List' => $result);
        }
        else 
        {
            $msg = array('status' => '0', 'message' => 'No User found');
        }
        echo json_encode($msg);
    }

/*    public function change_password() {
        $arr = array();
        $user_id = clean($this->input->get_post('user_id'));
        $arr2['old_password'] = clean($this->input->get_post("password"));
        $arr['password'] = clean($this->input->get_post("new_password"));
        $arr2['confirm_new_password'] = clean($this->input->get_post('confirm_new_password'));
        $result = $this->users_model->get_user($user_id);
        if ($arr['user_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Your User ID');
        } else if ($arr2['old_password'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Your Old Password');
        }
//        else if (strlen($arr["password"]) < 6 || strlen($arr["password"]) > 15) 
//        {
//            $msg = array("status" => "0", "message" => "Your password must be between 6 and 15 characters long ");
//        }
        else if ($arr['password'] == '') {
            $msg = array("status" => "0", "message" => "Enter Your New Password ");
        } else if ($arr2['confirm_new_password'] == '') {
            $msg = array("status" => "0", "message" => "Please Confirm password");
        }
//        else if (strlen($new_password) < 6 || strlen($new_password) > 15) {
//            $msg = array("status" => "0", "message" => "Your New password must be between 6 and 15 characters long ");
//        }
//        else if($confirm_new_password == '')
//        {
//            $msg = array("status" => "0", "message" => "Enter Your New Confirm Password ");
//        }
//        else if (strlen($confirm_new_password) < 6 || strlen($confirm_new_password) > 15) 
//        {
//            $msg = array("status" => "0", "message" => "Your New Confirm password must be between 6 and 15 characters long ");
//        }
        else if ($arr['password'] != $arr2['confirm_new_password']) {
            $msg = array('status' => '0', 'message' => 'New Password Does Not Match With New Confirm Password');
        } else if ($arr2['old_password'] == $arr['password']) {
            $msg = array('status' => '0', 'message' => 'New Password is same as old password!! Please Use Different Password');
        } elseif (!$this->common->validateHash($arr2['old_password'], $result['password'])) {
            $msg = array('status' => '0', "message" => 'Old password is wrong');
        } 
        else 
        {
            $arr['password'] = $this->common->salt_password($arr);
            $updated = $this->users_model->update_user($arr);
            if($updated)
            {
                $msg= array('status'=>'1', 'message' =>'Password Change Successfully');
            }
            else
            {
                $msg = array('status'=>'0','message'=>'Password not updated Please try again');
            }

        }
        echo json_encode($msg);
        die;
    }

*/    /*    public function delete_user() {
      $user_id = clean($this->input->get_post('user_id'));
      if ($user_id == '') {
      $msg = array('status' => '0', 'message' => 'Please Enter User ID');
      } else {
      $result = $this->users_model->get_user($user_id);
      if ($result) {
      $deleted = $this->users_model->delete_user($user_id);
      if ($deleted) {
      $msg = array('status' => '1', 'message' => 'User Succesfully Deleted');
      } else {
      $msg = array('status' => '0', 'message' => 'User Not Exist');
      }
      } else {
      $msg = array('status' => '0', 'message' => 'User Not Exist');
      }
      }
      echo json_encode($msg);
      die;
      }
     
*/	 
	 
}
