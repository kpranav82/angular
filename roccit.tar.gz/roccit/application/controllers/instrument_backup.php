<?php

//error_reporting(E_ALL);
class instruments extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model("instrument_model");
        $this->load->model("event_model");
        $this->load->model('users_model');
        $this->load->model('models_model');
        $this->load->model('customers_model');
        $this->load->model('file_model');
        $this->load->model('attributes_model');
    }

    public function add_instrument() {
        $model = $this->models_model->all_model_list();
        $customer = $this->customers_model->list_customers();
        $arr = array('model' => $model, 'customer' => $customer);
        echo json_encode($arr);
    }

    public function save_instrument() {

        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $arr["user_id"] = $this->session->userdata('user_id');
        if ($arr["user_id"] == "") {
            $msg = array("status" => "0", "message" => "Please enter your user id");
        } else if ($arr["model_id"] == "") {
            $msg = array("status" => "0", "message" => "Please  Select a  model");
        } else if ($arr["serial_number"] == "") {
            $msg = array("status" => "0", "message" => "Please enter serial number");
        } else if ($this->check_serial_availabilty($arr["serial_number"])) {
            $msg = array("status" => "0", "message" => "This serial Number Already exists, Please try another");
        } else if ($arr["customer_id"] == "") {
            $msg = array("status" => "0", "message" => "Please enter your customer id");
        } else if ($arr["location"] == "") {
            $msg = array("status" => "0", "message" => "Please enter location");
        } else if ($arr["date"] == "") {
            $msg = array("status" => "0", "message" => "Please enter Date");
        } else {
            $arr2['model_id'] = $arr['model_id'];
            $model_result = $this->models_model->get_model($arr['model_id']);
            $attribute_name = $model_result['attributes'];
            //$arr2['atvals'] = $model_result['attributes'];
            //print_r($attribute_name); die;
            $attribute_name = json_decode($attribute_name);
            $i = 0;
            foreach ($attribute_name as $key => $value) {
                //echo $value; die;
                $data = $this->attributes_model->get_attribute_by_atributeid($value);
                $result_att[$key][$value] = $data['default'];
            }
            $arr2['atvals'] = json_encode($result_att);
            $arr2['serial_number'] = clean($arr['serial_number']);
            $arr2['customer_id'] = clean($arr['customer_id']);
            $arr2['location'] = clean($arr['location']);
            $arr2['date'] = clean($arr['date']);
            $arr2['user_id'] = clean($arr['user_id']);
            $arr2['displayName'] = clean($model_result['identifier'] . $arr['serial_number']);
            $insert = $this->instrument_model->add_instrument($arr2);
            convertMongoIds($insert);
            $arr['instrument_id'] = $insert->{'$id'};
            if ($insert) {
                $event = $this->instrument_event('creation', $arr);
                if ($event) {
                    $msg = array('status' => '1', 'message' => 'Instrument Create Successfully!!');
                } else {
                    $msg = array('status' => '0', "message" => 'Error During Event Creation Try again!');
                }
            } else {
                $msg = array('status' => '0', "message" => 'Error Try again!');
            }
        }
        echo json_encode($msg);
        die;
        //?serial=1123&model=abc&displayName=sukhi&customer=1&created=today&user=1&location=manufacturing&atvals[]=1,2&files[]=1,2&lastChanged=time
    }

    public function check_serial_availabilty($serial_number) {
        $result = $this->instrument_model->get_all_instruments();
        //print_r($result); die;
        foreach ($result as $value) {
            if (isset($value['serial_number']) && strtolower($value['serial_number']) == strtolower($serial_number)) {
                return true;
            }
        }
    }

    public function autocompleted_serial_number() {
        $result = $this->instrument_model->autocompleted_serial_number($num_rec_per_page, $search);
        convertMongoIds($result_instruments);
        if ($result) {
            $msg = $result;
        } else {
            $msg = array("status" => "0", "message" => "No Instrument Found");
        }
        echo json_encode($msg);
        die;
    }

    public function autocompleted_serial_number_result($serial_number) {
        $rawjson = json_decode(file_get_contents("php://input"));
        if ($serial_number == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Serial Number');
        } else {
            $instrument_arr['serial_number'] = clean($serial_number);
            $result = $this->instrument_model->autocompleted_serial_number_result($instrument_arr['serial_number']);
            convertMongoIds($result);
            if ($result) {
                $msg = array('status' => '1', 'result' => $result);
            } else {
                $msg = array('status' => '0', 'message' => 'No instrument Found');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function get_instrument_history($id) {
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else {
            $rawjson = json_decode(file_get_contents("php://input"));
            $filter = $this->input->get('filter');
            if ($filter == '' || $filter == 'undefined') {
                $filter = '';
            } else {
                $filter = explode(',', $filter);
            }
            if (!empty($rawjson)) {
                $arr = objectToArray($rawjson);
            } else {
                $arr = array();
            }
            $num_rec_per_page = 5;
            if ($this->uri->segment(4)) {
                $page = $this->uri->segment(4);
            } else {
                $page = 1;
            }
            $start_from = ($page - 1) * $num_rec_per_page; //offset
            $instrument_arr['instrument_id'] = clean($id);
            $result_instrument_history = $this->instrument_model->get_instrument_history($instrument_arr['instrument_id'], $filter, $start_from, $num_rec_per_page);
            convertMongoIds($result_instrument_history);
            $result_user = $this->users_model->user_list();
            $result_instrument = $this->instrument_model->get_instrument($instrument_arr['instrument_id']);
            $total_records_events = $this->instrument_model->get_all_event($id, $filter);
            $result = array();
            foreach ($result_instrument_history as $value) {
                $user_id = array_search($value['user_id'], array_column($result_user, '_id'));
                $value['user_name'] = $result_user[$user_id]['name'];
                $value['created_at'] = date('Y-m-d', $value['created_at']);
                $value['instrument_name'] = $result_instrument['displayName'];
                $result[] = $value;
            }
            if ($result) {

                $msg = array('status' => '1', 'List' => $result, 'total_records' => count($total_records_events), 'per_page' => $num_rec_per_page);
            } else {
                $msg = array('status' => '0', "message" => 'No Event Found');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function model_checklist($id) {
        if (!empty($raw_json)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }

        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else {
            $instrument_arr['instrument_id'] = clean($id);
            $result_instrument = $this->instrument_model->get_instrument($instrument_arr['instrument_id']);
            convertMongoIds($result_instrument);
            if ($result_instrument) {
                $result = $this->models_model->get_model($result_instrument['model_id']);
                $checklists = objectToArray(json_decode($result['checklists']));
                $checklist_value = array();
                foreach ($checklists as $key => $value) {
                    $checklist_value[] = $value['_id'];
                }
                if ($result) {
                    $msg = array('status' => '1', "checklists" => $checklist_value);
                } else {
                    $msg = array('status' => '0', 'message' => 'No Model Found');
                }
            } else {
                $msg = array('status' => '0', 'message' => 'No Instrument Found');
            }
        }
        echo json_encode($msg);
    }

    public function model_checklist_result($id) {
        $arr['checklist_id'] = $this->input->get('checklist_id');
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Model ID');
        }
        else if ($arr['checklist_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Checklist ID');
        } else {
            $instrument_arr['model_id'] = clean($id);
                $result = $this->models_model->get_model($instrument_arr['model_id']);
                $checklists = objectToArray(json_decode($result['checklists']));
                $checklist_value = array();
                foreach ($checklists as $key => $value) {
                    if($value['_id'] == $arr['checklist_id'])
                    {
                        $checklist_value = $value;
                    }
                }
            foreach ($checklist_value['steps'] as $value) {
                if(!empty($value))
                {
                    if(strpos($value,'_a') > -1)
                    {
                        $final_array =explode(":", $value);
                        $final_value[] = $final_array[1];
                    }
                }
            }
            $i = 0;
            foreach ($final_value as $key => $value) {
                $data = $this->attributes_model->get_attribute_by_atributeid($value);
                $result_att['attributes']['attribute_name'] = $value;
                $result_att['attributes']['default'] = $data['default'];
                $result_att['attributes']['type'] = $data['type'];
                foreach ($checklist_value['steps'] as $key1 => $value1) {
                    if(!empty($value1))
                    {
                        if(strpos($value1,'_a') > -1)
                        {
                            $final_array =explode(":", $value1);
                            if($final_array[1] == $value){
                                $checklist_value['steps'][$key1]  = $result_att; 
                            }
                        }
                    }
            }
            }if ($result) {
                    $msg = array('status' => '1', "checklists" => $checklist_value);
                } else {
                    $msg = array('status' => '0', 'message' => 'No Checklist Found');
                }
             
        }
        echo json_encode($msg);
    }

    public function instrument_event($type, $arr) {
        $event_arr['user_id'] = $arr['user_id'];
        $event_arr['instrument_id'] = $arr['instrument_id'];
        $event_arr['created_at'] = time();
        $event_arr['actions'] = '';
        $event_arr['action'] = $type;
        $actions = array();
        switch ($type) {
            case 'creation':
                $actions['type'] = 'creation';
                if (!empty($arr['note'])) {
                    $actions['note'] = clean($arr['note']);
                }
                $event_arr['actions'] = json_encode($actions);
                //print_r($event_arr); die;
                return $create = $this->event_model->add_event($event_arr);
                break;

            case 'move':
                $actions['type'] = 'move';
                $actions['prev'] = clean($arr['prev_location']);
                $actions['new'] = clean($arr['new_location']);
                if (!empty($arr['note'])) {
                    $actions['note'] = clean($arr['note']);
                }
                $event_arr['actions'] = json_encode($actions);
                return $move = $this->event_model->add_event($event_arr);
                break;

            case 'attribute':
                if (!empty($arr['note'])) {
                    $actions['note'] = clean($arr['note']);
                }
                $actions['type'] = 'attribute';
                if (count($arr['prev']) > 0 || $arr['prev'] != 'null') { 
                    $actions['prev'] = clean($arr['prev']);
                }
                if (count($arr['update']) > 0 || $arr['update'] != 'null') {
                    $actions['update'] = clean($arr['update']);
                }
                if (count($arr['new']) > 0 || $arr['new'] != 'null') {
                    $actions['new'] = clean($arr['new']);
                }
                $event_arr['actions'] = json_encode($actions);
                return $attribute = $this->event_model->add_event($event_arr);
                break;

            case 'note':
                $actions['type'] = 'note';
                $actions['note'] = clean($arr['note']);
                $event_arr['actions'] = json_encode($actions);
                return $note = $this->event_model->add_event($event_arr);
                break;

            case 'checklist':
                $actions['type'] = 'checklist';
                if (!empty($arr['note'])) {

                    $actions['note'] = clean($arr['note']);
                    $actions['checklist_id'] = clean($arr['checklist_id']);
                }
                $event_arr['actions'] = json_encode($actions);
                return $checklist = $this->event_model->add_event($event_arr);
                break;
            default:
                $msg = array('status' => '0', 'message' => 'Something went wrong!!! Please Try Again');
                break;
        }
        echo json_encode($msg);
        die;
    }

    public function delete_all() {
        $this->mongo_db->delete_all('instruments');
    }

    public function get_all_instruments() {
        $search = $this->input->get('q');
        if ($search == '' || $search == 'undefined') {
            $search = '';
        } else {
            $search = $search;
        }
        $num_rec_per_page = 10;
        //echo $this->uri->segment(3); die;
        if ($this->uri->segment(3)) {
            $page = $this->uri->segment(3);
        } else {
            $page = 1;
        }
        $start_from = ($page - 1) * $num_rec_per_page; //offset
        $result_instruments = $this->instrument_model->get_instrument_page($start_from, $num_rec_per_page, $search);
        convertMongoIds($result_instruments);
        $result_model = $this->models_model->model_list();
        $result_customer = $this->customers_model->list_customers();
        $result_user = $this->users_model->user_list();
        $result_instruments_records = $this->instrument_model->get_all_instruments($search);
        $result = array();
        foreach ($result_instruments as $key => $value) {
            $customer_id = array_search($value['customer_id'], array_column($result_customer, '_id'));
            $user_id = array_search($value['user_id'], array_column($result_user, '_id'));
            $model_id = array_search($value['model_id'], array_column($result_model, '_id'));
            $value['customer_name'] = $result_customer[$customer_id]['name'];
            $value['user_name'] = $result_user[$user_id]['name'];
            $value['model_name'] = $result_model[$model_id]['identifier'];
            $value['created_at'] = date('Y-m-d', $value['created_at']);
            $result[] = $value;
        }
        if ($result) {
            convertMongoIds($result);
            $msg = array('status' => '1', 'message' => 'List of Instrument', 'List' => $result, 'total_records' => count($result_instruments_records)
                , 'per_page' => $num_rec_per_page);
        } else {
            $msg = array('status' => '0', 'message' => 'No instrument Found');
        }
        echo json_encode($msg);
        die;
    }

    public function get_instrument($id) {
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else {
            $instrument_arr['instrument_id'] = clean($id);
            $result = $this->instrument_model->get_instrument($instrument_arr['instrument_id']);
            $model_result = $this->models_model->get_model($result['model_id']);
            $model_name = $model_result['identifier'];
            $result_attributes = objectToArray(json_decode($result['atvals']));
            $result_attribute = json_decode($result['atvals']);
            $i = 0;
            foreach ($result_attributes as $key => $value) {
                foreach ($value as $key => $data1) {
                    $data = $this->attributes_model->get_attribute_by_atributeid(trim($key));
                    $result_att[$key]['attribute_name'] = $key;
                    $result_att[$key]['default'] = $data1;
                    $result_att[$key]['type'] = $data['type'];
                }
            }
            convertMongoIds($result_att);
            convertMongoIds($result);
            $model_data = $this->models_model->get_model($result['model_id']);
            $result['checklist'] = $model_data['checklists'];
            if ($model_data) {
                $msg = array('status' => '1', 'Instrument' => $result, 'model_name' => $model_name, 'attibute_result' => $result_att);
            } else {
                $msg = array('status' => '0', "message" => 'No Instrument Found');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function update_attribute() {
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $arr["user_id"] = $this->session->userdata('user_id');
        if ($arr['instrument_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else if (!empty($arr['type']) && (!in_array($arr['type'], array('move', 'attribute', 'checklist', 'note')))) {
            $msg = array("status" => "0", "message" => "Please enter correct type");
        } else {
            if (count($arr['all']) > 0) {
                foreach ($arr['all'] as $key => $all) {
                    if (!empty($all['default'])) {
                        $arr_all[$all['attribute_name']] = clean($all['default']);
                    } else {
                        $msg = array("status" => "0", "message" => "Please enter value for old");
                    }
                }
            }else{
                unset($arr['all']);
            }
            if (count($arr['update']) > 0) {
                foreach ($arr['update'] as $key => $update) {
                    if (!empty($update['default'])) {
                        $arr_update[$update['attribute_name']] = clean($update['default']);
                        $event_update[$update['attribute_name']] = clean($update['default']);
                        $arr['update'] = json_encode($arr_update);
                    } else {
                        $msg = array("status" => "0", "message" => "Please enter value for update");
                    }
                }
            }else{
                unset($arr['update']);
            }
            if (count($arr['new']) > 0) {
                foreach ($arr['new'] as $key => $new) {
                    if (!empty($new['default'])) {
                        $arr_new[$new['attribute_name']] = clean($new['default']);
                        $event[$new['attribute_name']] = clean($new['default']);
                        $arr['new'] = json_encode($arr_new);
                    } else {
                        $msg = array("status" => "0", "message" => "Please enter value for new");                    
                    }
                }
            }else{
                unset($arr['new']);
            }
            $type = 'attribute';
            $result = $this->instrument_model->get_instrument($arr['instrument_id']);
            if ($result) {
                $arr['prevs'] = clean($result['atvals']);
            } else {
                $arr['prevs'] = '';
            }
            $arr['prev1'] = objectToArray(json_decode(stripslashes($arr['prevs'])));
            if (count($arr['prev1']) > 0) {
                foreach ($arr['prev1'] as $key => $update1) {
                    $arr_prev = $update1;
                }
            }
            $arr['prev2'] = json_encode(array_intersect_key($arr_prev, $event_update));
            $arr['prev'] = $arr['prev2'];
            $arr1['instrument_id'] = clean($arr['instrument_id']);
            $arr2['instrument_id'] = $arr1['instrument_id'];
            $arr2['all'] = json_encode($arr_all);
            $event = $this->instrument_event($type, $arr);
            if ($event) {
                $update = $this->instrument_model->update_instrument($arr2, $type = 'update_attr');
                if ($update) {
                    $msg = array('status' => '1', 'message' => 'Update Successfully');
                } else {
                    $msg = array('status' => '0', 'message' => 'Error Please Try Again!!!');
                }
            } else {
                $msg = array('status' => '0', 'message' => 'Error Please Try Again!!!');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function move() {

        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }

        $arr["user_id"] = $this->session->userdata('user_id');
        if ($arr['instrument_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else if ($arr["location"] == "") {
            $msg = array("status" => "0", "message" => "Please enter location");
        } else if (!empty($arr['type']) && (!in_array($arr['type'], array('move', 'attribute', 'checklist', 'note')))) {
            $msg = array("status" => "0", "message" => "Please enter correct type");
        } else {
            $arr2['location'] = $arr['new_location'] = $arr['location'];
            $arr2['instrument_id'] = $arr['instrument_id'];
            $type = 'move';
            $result = $this->instrument_model->get_instrument($arr2['instrument_id']);

            if ($result) {
                $arr['prev_location'] = clean($result['location']);
            }
            if ($result['location'] != $arr2['location']) {
                if (!empty($type)) {
                    $event = $this->instrument_event($type, $arr);
                    if ($event) {
                        $update = $this->instrument_model->update_instrument($arr2);
                        if ($update) {
                            $msg = array('status' => '1', 'message' => 'Update Successfully');
                        } else {
                            $msg = array('status' => '0', 'message' => 'Error Please Try Again!!!');
                        }
                    } else {
                        $msg = array('status' => '0', 'message' => 'Error Please Try Again!!!');
                    }
                } else {
                    $update = $this->instrument_model->update_instrument($arr2);
                    if ($update) {
                        $msg = array('status' => '1', 'message' => 'Update Successfully');
                    } else {
                        $msg = array('status' => '0', 'message' => 'Error Please Try Again!!!');
                    }
                }
            } else {
                $msg = array('status' => '0', 'message' => 'Same Location Exist');
            }
        }
        echo json_encode($msg);
        die;
    }


        public function checklist_event() {
        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }

        $arr["user_id"] = $this->session->userdata('user_id');
        if ($arr['instrument_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else if ($arr["checklist_id"] == "") {
            $msg = array("status" => "0", "message" => "Please enter location");
        } else if (!empty($arr['type']) && (!in_array($arr['type'], array('move', 'attribute', 'checklist', 'note')))) {
            $msg = array("status" => "0", "message" => "Please enter correct type");
        } else {
            $arr2['checklist_id'] = $arr['checklist_id'];
            $arr2['instrument_id'] = $arr['instrument_id'];
            $type = 'checklist';
            if (!empty($type)) {
                    $event = $this->instrument_event($type, $arr);
                    if ($event) {
                            $msg = array('status' => '1', 'message' => 'Checklist Created Successfully');
                        } else {
                            $msg = array('status' => '0', 'message' => 'Error Please Try Again!!!');
                        }
                    }
                }    
        echo json_encode($msg);
        die;
    }


    public function note() {

        $rawjson = json_decode(file_get_contents("php://input"));
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }

        $arr["user_id"] = $this->session->userdata('user_id');
        if ($arr['instrument_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else if ($arr["note"] == "") {
            $msg = array("status" => "0", "message" => "Please enter note");
        } else if (!empty($arr['type']) && (!in_array($arr['type'], array('move', 'attribute', 'checklist', 'note')))) {
            $msg = array("status" => "0", "message" => "Please enter correct type");
        } else {
            $type = 'note';
            if (!empty($type)) {
                $event = $this->instrument_event($type, $arr);
                if ($event) {
                    $msg = array('status' => '1', 'message' => 'Note Event Created Successfully');
                } else {
                    $msg = array('status' => '0', 'message' => 'Error Please Try Again!!!');
                }
            }
        }

        echo json_encode($msg);
        die;
    }

    public function get_event($id) {
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        $arr["user_id"] = $this->session->userdata('user_id');
        if ($arr['user_id'] == '') {
            $msg = array('status' => '0', 'message' => 'Please enter User ID');
        } else if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please enter Event Id');
        } else {
            $c_profile['event_id'] = $id;

            $user_data = $this->users_model->get_user($result['user_id']);
            $result['user_name'] = $user_data['name'];
            $instrument_data = $this->instrument_model->get_instrument($result['instrument_id']);
            $result['instrument_name'] = $instrument_data['displayName'];
            $result = $this->instrument_model->get_event($c_profile);
            convertMongoIds($result);
            if ($result) {
                $msg = array('status' => '1', 'result' => $result);
            } else {
                $msg = array('status' => '0', 'message' => 'No Event Exist');
            }
        }
        echo json_encode($msg);
    }

    public function upload_file($id) {
        $arr["user_id"] = $this->session->userdata('user_id');
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else {
            $arr['instrument_id'] = clean($id);
            if (!empty($_FILES)) {
                $files = $_FILES['file'];
                $imagename = $this->reArrayImages($files, 'instruments');
                $file_arr['image_name'] = $imagename;
                $file_arr['user_id'] = $arr['user_id'];
                $file_arr['instrument_id'] = $arr['instrument_id'];
                $insert_ids[] = $this->file_model->add_file($file_arr);
                $msg = array("status" => "1", "message" => "Images Uploaded Successfully", 'id' => $imagename, 'created_at' => time());
            } else {
                $msg = array("status" => "0", "message" => "Please Upload files");
            }
        }
        echo json_encode($msg);
        die;
    }

    public function reArrayImages($filearr, $file_folder) {

        $file_name = $filearr['name'];
        $file_type = $filearr['type'];
        $exts = @end(explode('.', $file_name));
        $image_name = $this->common->random_generator('10') . '.' . $exts;
        $path = "./uploads/" . $file_folder . "/" . $image_name;

        @chmod($path, 0777);
        @copy($filearr['tmp_name'], $path);
        $this->auto_rotate_image($path);
        $this->thumnail($image_name, $file_folder);
        return $image_name;
    }

    public function thumnail($img, $file_folder) {
        $this->load->library('image_lib');
        $config['image_library'] = 'gd2';
        $config['source_image'] = './uploads/' . $file_folder . '/' . $img;
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        $config['quality'] = '100%';
        $config['width'] = 250;
        $config['height'] = 250;
        $config['thumb_marker'] = '';
        $config['master_dim'] = 'height';
        $config['new_image'] = './uploads/' . $file_folder . '/thumbnail/' . $img;

        $this->image_lib->clear();
        $this->image_lib->initialize($config);
        $this->image_lib->resize();
    }

    public function auto_rotate_image($path) {//iphone rotation fix
        //$path = $path;
        $exif = exif_read_data($path);
        if (isset($exif['Orientation'])) {
            $rotate = false;
            switch ($exif['Orientation']) {//only really interested in the rotation
                case 1: // nothing
                    break;
                case 2:// horizontal flip
                    break;
                case 3: // 180 rotate left
                    $rotate = 180;
                    break;
                case 4: // vertical flip
                    break;
                case 5: // vertical flip + 90 rotate right
                    break;
                case 6: // 90 rotate right
                    $rotate = 270;
                    break;
                case 7: // horizontal flip + 90 rotate right
                    break;
                case 8: // 90 rotate left
                    $rotate = 90;
                    break;
            }

            if ($rotate) {

                $config = array();
                $config['image_library'] = 'gd2';
                $config['source_image'] = $path;
                $config['rotation_angle'] = $rotate;
                $config['overwrite'] = TRUE;
                $this->load->library('image_lib', $config);

                if (!$this->image_lib->rotate()) {
                    echo $this->image_lib->display_errors();
                }
            }
        }
    }

    public function unlink_image($path, $img) {
        chmod("$path", 0777);
        unlink('./uploads/' . $path . '/' . $img);
        unlink('./uploads/' . $path . '/thumbnail/' . $img);

        return "success";
        die;
    }

    public function get_images($id) {
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }

        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else {
            $instrument_arr['instrument_id'] = clean($id);
            $result = $this->file_model->get_images($instrument_arr);
            //debug($result);
            /*$user_id = $result[0]['user_id'];
            $user_data = $this->users_model->get_user($user_id);
            $user_name = $user_data['name'];
            //debug($result);*/
            //debug($user_name); die;
            $result_user = $this->users_model->user_list();
            foreach ($result as $key => $img) {
                //$user_id = $result[0]['user_id'];
                $user_id = array_search($img['user_id'], array_column($result_user, '_id'));
                //$user_data = $this->users_model->get_user($user_id);
                //$user_name = $user_data['name'];
                $result[$key]['image_path'] = base_url() . 'uploads/instruments/thumbnail/' . clean($img['image_name']);
                $result[$key]['image_path_zoom'] = base_url() . 'uploads/instruments/' . clean($img['image_name']);
                $result[$key]['image_name'] = clean($img['image_name']);
                //$result[$key]['user_name'] = clean($user_name);
                $result[$key]['user_name'] = $result_user[$user_id]['name'];
                $result[$key]['created_at'] = date('Y-m-d', $img['created_at']);
                //$result[$key]['date'] = clean($img['created_at']);
            }
            convertMongoIds($result);
            if ($result) {

                $msg = array('status' => '1', 'List' => $result);
            } else {
                $msg = array('status' => '0', "message" => 'No File Found');
            }
        }
        echo json_encode($msg);
        die;
    }

    public function delete_image($id) {
        if (!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please select image Id');
        } else {
            $arr['image_id'] = clean($id);
            $img_data = $this->file_model->get_image($arr);
            convertMongoIds($img_data);
            $img = $img_data['image_name'];
            if ($img_data) {
                $deleted = $this->file_model->image_delete($arr);

                if ($deleted) {
                    $msg = array('status' => '1', 'message' => 'Image Deleted Successfully', 'name' => $img);
                } else {
                    $msg = array('status' => '0', 'message' => 'Image Not found');
                }
                $path = 'instruments';
                $this->unlink_image($path, $img);
            } else {
                $msg = array('status' => '0', 'message' => 'Image Not found');
            }
        }
        echo json_encode($msg);
    }

    public function unused_attributes($id) {
        if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Instrument ID');
        } else {
            $instrument_arr['instrument_id'] = clean($id);
            $instrument_attributes = $this->instrument_model->get_instrument($instrument_arr['instrument_id']);
            convertMongoIds($instrument_attributes);
            $attribute_used = $instrument_attributes['atvals'];
            $attribute_used = objectToArray(json_decode($attribute_used));
            $att_used = array('');
            if ($attribute_used) {
                foreach ($attribute_used as $key => $used) {
                    foreach ($used as $key => $value) {
                        $att_used[] = clean($key);
                    }
                }
            }
            $result = $this->instrument_model->unused_attributes($att_used);
            convertMongoIds($result);
            if ($result) {
                $msg = array('status' => '1', 'unused_attributes' => $result);
            } else {
                $msg = array('status' => '0', $msg = 'No Unused attribute found');
            }
        }

        echo json_encode($msg);
        die;
    }

    public function get_all_event() {

        $event = $this->mongo_db->get('event');
        convertMongoIds($event);
        print_r($event);
        die;
    }

    public function list_files() {
        $result = $this->mongo_db->where('status', '1')->get('file');
        if ($result) {
            print_r($result);
        } else {
            echo 'no file found';
        }
    }
}

?>