<?php
class models_test extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('models_model');
	}

	public function add_model()
	{	
		$last_record = $this->mongo_db->order_by(array('created_at' => 'DESC'))->limit(1)->get('models');
		if(empty($last_record[0])){
			$identifier = '106-M';
		}else{
			$last_identifier =  explode('-', $last_record[0]['identifier']);
			$last_identifier[0]= $last_identifier[0]+1;
			$identifier = implode('-', $last_identifier);
		}
		$json = '{
			"details": {
				"identifier": "",
				"description": "this is description",
				"attributes": ["custom", "bom", "software"],
				"attributeDefaults": {
					"travelerRev": "Model 106 revision 13C, 2014/10/6",
					"components": "scrubber(value): scrubber(pump) : External scrubber: Pump: Value: Circuit borad: Photodiode PCB: Optional bench: Cell: Lamp:"
				},
				"checklists": [{
					"_id": "pre-cal inspection",
					"steps": ["make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)","All Plumbing is connected","make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)","make sure the first page of the traveler(lot numbers, manaul revisons,initials,etc)"]
				}]
			}
		}';
		$rawjson= json_decode($json);
		if(!empty($rawjson)) {
			$newarr = objectToArray($rawjson);
		} else {
			$newarr = array();
		}
			$arr = $newarr['details'];
			$model_arr['identifier'] = $identifier;
			$model_arr['description'] = $arr['description'];
			$model_arr['attributes'] = json_encode($arr['attributes']);
			$model_arr['attributeDefaults'] = json_encode($arr['attributeDefaults']);
			$model_arr['checklists'] = json_encode($arr['checklists']);
			$check = $this->models_model->check_identifier($model_arr);
			//print_r($check); die;
			if(!empty($check)) {
				//print_r($model_arr); die;
					$model_arr['identifier'] =  explode('-', $model_arr[0]['identifier']);
					$model_arr['identifier'][0] = $model_arr['identifier'][0] + 1;
					//$model_arr['identifier'][0] = $model_arr['identifier'] + 1;
					$model_arr['identifier'] = implode('-', $model_arr['identifier']);
					//$last_identifier =  explode('-', $last_record[0]['identifier']);
					//$last_identifier[0]= $last_identifier[0]+1;
					//$identifier = implode('-', $last_identifier);
					$result = $this->models_model->add_model($model_arr);
			convertMongoIds($result);
			if($result)
			{
				$msg = array('status'=>'1','message'=>'Model Insertion Successfully', 'id' => $result->{'$id'});
			}		
			else
			{
				$msg = array('status'=>'0','message'=>'Try Again!! something went Wrong');
			}
				}
			else {
				$result = $this->models_model->add_model($model_arr);
			convertMongoIds($result);
			if($result)
			{
				$msg = array('status'=>'1','message'=>'Model Insertion Successfully', 'id' => $result->{'$id'});
			}		
			else
			{
				$msg = array('status'=>'0','message'=>'Try Again!! something went Wrong');
			}
			}
		
		echo json_encode($msg); die;
	}

	public function model_list()
	{
		$search = $this->input->get('q');
		if($search == '' || $search == 'undefined') {
			$search = '';
		} else {
			$search = $search;
		}
		$num_rec_per_page = 10;
        if ($this->uri->segment(3)) {
            $page = $this->uri->segment(3);
        } else {
            $page = 1;
        }
        $start_from = ($page - 1) * $num_rec_per_page;//offset
        $records = $this->models_model->all_model_list($search); 
		$result = $this->models_model->model_list($start_from, $num_rec_per_page,$search);
		convertMongoIds($result);
        if ($result)
        {
            $msg = array('status' => '1', 'message' => 'List of Models' ,'List' => $result,'total_records'=>count($records),'per_page'=>$num_rec_per_page);
        }
        else 
        {
            $msg = array('status' => '0', 'message' => 'No Model found');
        }
        echo json_encode($msg);
	}

	public function get_model($id)
	{
		//$rawjson= json_decode(file_get_contents("php://input"));
        if(!empty($rawjson)) {
            $arr = objectToArray($rawjson);
        } else {
            $arr = array();
        }
        if($id == '')
        {
            $msg = array('status'=>'0' , 'message'=>'Please Enter Model ID');
        }
        else
        {
        	$model_arr['model_id'] = $id;
        	$result = $this->models_model->get_model($model_arr['model_id']);
        	if($result)
        	{
        		convertMongoIds($result);
                $jsonraw =  array("identifier"=>$result['identifier'], "description" => $result['description'], "attributes" => json_decode($result['attributes']) , "attributeDefaults" => json_decode($result['attributeDefaults']) ,"checklists" => json_decode($result['checklists']));
				$details = json_encode($jsonraw);
				//$msg = array('status' => '1', "message" => 'Model List', 'details' => stripslashes(stripslashes(str_replace('\n','',$details))));
				$msg = array('status' => '1', "message" => 'Model List', 'details' =>($details));
        	}
        	else
        	{
        	    $msg = array('status' => '0', "message" => 'No Model Found');
            }
        }
        echo json_encode($msg); die;
    }

    public function update_model($id)
	{

		$rawjson= json_decode(file_get_contents("php://input"));
		//debug($rawjson); die;
		if(!empty($rawjson)) {
			$newarr = objectToArray($rawjson);
		} else {
			$newarr = array();
		}

		$arr = $newarr['details'];
		if ($id == '') {
            $msg = array('status' => '0', 'message' => 'Please Enter Model ID');
        }
        else if($arr['identifier'] == '')
        {
        	$msg = array('status' => '0', 'message' => 'Please Enter identifier');	
        }
		else if($arr['description'] == '')
		{
			$msg = array('status'=>'0','message'=>'Please Enter description');	
		}
		else if($arr['attributes'] == '')
		{
			$msg = array('status'=>'0','message'=>'Please Enter Attributes');	
		}
		else if($arr['attributeDefaults'] == '')
		{
			$msg = array('status'=>'0','message'=>'Please Enter Defaults Attributes');	
		}
		else if($arr['checklists'] == '')
		{
			$msg = array('status'=>'0','message'=>'Please Enter Checklist items');	
		}
		else
		{
			$model_arr['model_id'] = $id;
			$model_arr['identifier'] = $arr['identifier'];
			$model_arr['description'] = $arr['description'];
			$model_arr['attributes'] = json_encode($arr['attributes']);
			$model_arr['attributeDefaults'] = json_encode($arr['attributeDefaults']);
			$model_arr['checklists'] = json_encode($arr['checklists']);
			stripcslashes($result);
			$check = $this->models_model->check_identifier($model_arr);
			//print_r($check); die;
			if(!empty($check)) {
					$msg = array('status'=>'0','message'=>'Identifier Already Exist!! Please Try another');
				}
			else {
				$result = $this->models_model->update_model($model_arr);
				if($result)
				{
					$msg = array('status'=>'1','message'=>'Model Updated Successfully');
				}		
				else
				{
					$msg = array('status'=>'0','message'=>'Try Again!! something went Wrong');
				}	
				}
			}	
		echo json_encode($msg);
	}

}

?>