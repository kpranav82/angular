<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$CI = & get_instance();
		$loggedin = $CI->session->userdata('is_logged_in');
		if(!(bool)$loggedin) {
			$msg = array('status' => '0', 'message' => 'User not logged in');
			echo json_encode($msg); die;
		}
	}
}