<?php

class instrument_model_old extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function add_instrument($arr) {
        $arr['status'] = '1';
        $arr['created_at'] = time();
        $arr['updated_at'] = time();
        /* print_r($arr); die; */
        $result = $this->mongo_db->insert('instruments', $arr);
        return $result;
    }

    public function get_instrument_page($start_from, $num_rec_per_page, $search) {
        if (!empty($search)) {
            $result = $this->mongo_db->where('status', '1')->like('location', $search)->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('instruments');
            return $result;
        } else {
            $result = $this->mongo_db->where('status', '1')->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('instruments');
            return $result;
        }
    }

    public function get_instrument_by_customer($id, $start_from, $num_rec_per_page, $search) {
        try {
            //print_r($id); die; 
            if (!empty($search)) {
                $result = $this->mongo_db->where(array('customer_id' => $id, "status" => '1'))->like('location', $search)->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('instruments');
                return $result;    
            } else {
                $result = $this->mongo_db->where(array('customer_id' => $id, "status" => '1'))->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('instruments');
                return $result;
                die;
                return $result;
            }
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function get_instrument_by_customer_old($id,$search) {
        try {
            if(!empty($search))
            {
                $result = $this->mongo_db->where(array('customer_id' => $id, "status" => '1'))->like('location', $search)->order_by(array('created_at' => 'DESC'))->get('instruments');
                return $result;
            
            }
            else
            {
            $result = $this->mongo_db->where(array('customer_id' => $id, "status" => '1'))->order_by(array('created_at' => 'DESC'))->get('instruments');
            /* print_r($result); die; */
            return $result;
            }
        } catch (MongoException $ex) {
            return false;
        }
    }


    public function get_all_instruments($search) {
        if (!empty($search)) {
            $result = $this->mongo_db->where('status', '1')->like('location', $search)->get('instruments');
            return $result;
        } else {
            $result = $this->mongo_db->where('status', '1')->order_by(array('created_at' => 'DESC'))->get('instruments');
            return $result;
        }
    }

    public function get_instrument($id) {
        try {
            $mongoid = new MongoId($id);
            return $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->find_one('instruments');
        } catch (MongoException $ex) {
            return false;
        }
    }

/*    public function get_checklist($checklist_id) {
        try {
            $result = $this->mongodb->where('_id' => $checklist_id)->find_one()            
            } catch (Exception $e) {
                    
            }        
    }
*/
    public function get_instrument_history_old($id, $filter) {
        try {
            if (!empty($filter)) {
                //debug($filter);
                for ($i = 0; $i < count($filter); $i++) {
                    //  echo $i;
                    $arr[$i] = array("action" => $filter[$i]);
                }
                //debug($arr);
                $where = array('$and' => array(array("status" => '1'), array('instrument_id' => $id), array('$or' => $arr)));
                //debug($where);
                $result = $this->mongo_db->where($where)->get('event');
                return $result;
                //debug($result);
                //die;
            } else {
                $result = $this->mongo_db->where(array('instrument_id' => $id, "status" => '1'))->get('event');
                return $result;
            }
        } catch (MongoException $ex) {
            return false;
        }
    }

        public function get_instrument_history($id, $filter, $start_from ,$num_rec_per_page) {
        try {
            if (!empty($filter)) {
                //debug($filter);
                for ($i = 0; $i < count($filter); $i++) {
                    $arr[$i] = array("action" => $filter[$i]);
                }
                $where = array('$and' => array(array("status" => '1'), array('instrument_id' => $id), array('$or' => $arr)));
                //debug($where);
                $result = $this->mongo_db->where($where)->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('event');
                return $result;
            } else {
                $result = $this->mongo_db->where(array('instrument_id' => $id, "status" => '1'))->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('event');
                return $result;
            }
        } catch (MongoException $ex) {
            return false;
        }
    }
    
    public function get_all_event($id,$filter)
    {
        try {
            if(!empty($filter))
            {
                for ($i = 0; $i < count($filter); $i++) {
                    $arr[$i] = array("action" => $filter[$i]);
                }
                $where = array('$and' => array(array("status" => '1'), array('instrument_id' => $id), array('$or' => $arr)));
                //debug($where);
                $result = $this->mongo_db->where($where)->order_by(array('created_at' => 'DESC'))->get('event');
                return $result;
            } else {
                $result = $this->mongo_db->where(array('instrument_id' => $id, "status" => '1'))->order_by(array('created_at' => 'DESC'))->get('event');
                return $result;
            }
        } catch (MongoException $ex) {
            return false;
        }

   }


    public function list_get_instrument_by_customer($id) {
        try {
            $result = $this->mongo_db->where(array('customer_id' => $id, "status" => '1'))->get('instruments');
            return $result;
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function update_instrument($instrument_arr) {
        try {
            $instrument_id = $instrument_arr['instrument_id'];
            unset($instrument_arr['instrument_id']);
            $instrument_arr['updated_at'] = time();
            $result = $this->mongo_db->where(array('_id' => new MongoId($instrument_id), "status" => '1'))->set($instrument_arr)->update('instruments', $instrument_arr);
            return $result;
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function get_event($arr)
    {
        try {
            $mongoid = new MongoId($arr['event_id']);
            $result = $this->mongo_db->where(array('_id' => $mongoid,'status'=>array('$ne'=>'4')))->find_one('event');
            return $result;
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function autocompleted_serial_number($num_rec_per_page,$search)
    {
        try{
            //echo 'here'; die;
            $field = array(
        '$project' => array(
            "serial_number" => 1,'_id' =>1
            )
        );
            $collection = $this->mongo_db->where('status','1')->like('serial_number',$search)->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->aggregate('instruments',$field);
            print_r($collection); die;
            $result = $collection->aggregate('instruments',$collection);

            return $result;
        }
        catch (MongoException $ex) {
            return false;
        }
    }


}

?>
