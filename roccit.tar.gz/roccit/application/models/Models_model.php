<?php
class models_model extends CI_Model
{
	function __construct()
	{
		parent:: __construct();
	}

	public function add_model($arr)
	{
		$arr['status'] = '1';
		$arr['created_at'] = time();
		$arr['updated_at'] = time();
		$result = $this->mongo_db->insert('models',$arr);
		return $result;
	}

	public function model_list($start_from, $num_rec_per_page,$search)
	{
		try {
		if(!empty($search))
		{
			$result = $this->mongo_db->where('status','1')->like('identifier',$search)->order_by(array('identifier' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('models');
			return $result;
		}
		else
		{
			$result = $this->mongo_db->where('status','1')->order_by(array('identifier' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('models');
			return $result;
		}
		}
		catch (MongoException $ex) {
            return false;
        }

	}

	public function all_model_list($search)
	{
		try {
		if(!empty($search))
		{
			$result = $this->mongo_db->where('status','1')->like('identifier',$search)->order_by(array('identifier' => 'DESC'))->get('models');
			return $result;
		}
		else
		{
			$result = $this->mongo_db->where('status','1')->order_by(array('identifier' => 'DESC'))->get('models');
			return $result;
		}
		}
		catch (MongoException $ex) {
            return false;
        }
	}

	

	public function get_model($id)
	{
		try {
			$mongoid = new MongoId($id);
			return $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->find_one('models');
		} catch (MongoException $ex) {
			return false;
		}
	}

	public function check_identifier($model_arr)
	{
		try{
			//print_r($model_arr['identifier']); die;
			$identifier = $model_arr['identifier'];
			//print_r($identifier);
			$result = $this->mongo_db->where('identifier', $identifier)->find_one('models');
			return $result;
		}
		catch (MongoException $ex) {
			return false;
		}
	}

	public function update_model($model_arr)
	{
	    try {
	    	/*debug($model_arr); die;*/
			$id = $model_arr['model_id'];
            $mongoid = new MongoId($id);
            unset($model_arr['model_id']);
            $model_arr['updated_at'] = time();
            $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->set($model_arr)->update('models', $model_arr);
        return $result;
        } catch (MongoException $ex) {
            return false;
        }
    
	}
}
?>