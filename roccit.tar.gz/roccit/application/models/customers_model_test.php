<?php 
class customers_model_test extends CI_Model
{
	function __construct()
	{
		parent::__construct();
/*	}
	public function add_customers($arr)
	{
		$arr['status'] = '1';
		$arr['created_at'] = time();
		$arr['updated_at'] = time();
		$result = $this->mongo_db->insert('customer', $arr);
		return $result;
	}
*/
/*	public function list_customers()
	{
		$result = $this->mongo_db->where('status','1')->order_by(array('created_at' => 'DESC'))->get('customer');
		return $result;
	}

	public function list_customers($search)
	{
		try {
			if(!empty($search))
				{
					$result = $this->mongo_db->where('status','1')->like('name',$search)->order_by(array('created_at' => 'DESC'))->get('customer');
					return $result;
				}
			else
				{
					$result = $this->mongo_db->where('status','1')->order_by(array('created_at' => 'DESC'))->get('customer');
					return $result;
				}
		}
		catch (MongoException $ex) {
            return false;
        }
	}*/

/*	public function all_model_list($start_from, $num_rec_per_page,$search)
	{
		try {
		if(!empty($search))
		{
			$result = $this->mongo_db->where('status','1')->like('name',$search)->order_by(array('created_at' => 'DESC'))->get('models');
			return $result;
		}
		else
		{
			$result = $this->mongo_db->where('status','1')->order_by(array('created_at' => 'DESC'))->get('models');
			return $result;
		}
		}
		catch (MongoException $ex) {
            return false;
        }
	}
*/
/*	public function all_list_customers($start_from, $num_rec_per_page,$search)
	{
		try {
		if(!empty($search))
		{
			$result = $this->mongo_db->where('status','1')->like(array('$or' =>array(array('name'=>$search),array('creator'=>$search))))->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('customer');
			$result = $this->mongo_db->where('status','1')->like(array('$or'=> array(array("name" => $search), array('creator' => $search))))->order_by(array('creator' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('customer');
			return $result;
			//like(array('$or'=> array(array("name" => $search), array('creator' => $search))))
		}
		else
		{
			$result = $this->mongo_db->where('status','1')->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('customer');
			return $result;
		}
		}
		catch (MongoException $ex) {
            return false;
        }

	}*/

/*	public function get_customer($arr)
	{
		try {
			/*print_r($arr); die;*/
			$mongoid = new MongoId($arr['customer_id']);
			$result = $this->mongo_db->where(array('_id' => $mongoid,'status'=>array('$ne'=>'4')))->find_one('customer');
			return $result;
		} catch (MongoException $ex) {
			return false;
		}
	}*/


/*	public function update_customer($arr)
	{
		$customer_id = $arr['customer_id'];
		unset($arr['customer_id']);
        $arr['updated_at'] = time();
		$result = $this->mongo_db->where('_id', new MongoId($customer_id))->set($arr)->update('customer', $arr);
		//print_r($result); die;
		return $result;

	}*/

/*	public function delete_customers($arr)
	{
		//print_r($arr); die;
		$customer_id = $arr['customer_id'];
		unset($arr['customer_id']);
		unset($arr['user_id']);
        $arr['updated_at'] = time();
		$arr['status'] = '4';
		$result = $this->mongo_db->where('_id', new MongoId($customer_id))->set($arr)->update('customer',$arr);
		return $result;

	}*/
}
?>