<?php

class file_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function add_file($file_arr) {
        $file_arr['status'] = '1';
        $file_arr['created_at'] = time();
        $file_arr['updated_at'] = time();
        //debug($file_arr); die;
        $insert_id = $this->mongo_db->insert('file', $file_arr);
        return $insert_id;
    }

    public function list_files() {
        $result = $this->mongo_db->where('status', '1')->get('file');
        return $result;
    }

    public function get_images($id)
    {
        try {
            /*print_r($id); die;*/
            $file_id = $id['instrument_id'];
            $result = $this->mongo_db->select(array('image_name','created_at','user_id'))->where(array('instrument_id'=>$file_id, 'status'=>'1'))->get('file');
            //print_r($result); die;
            return $result;
        } catch (MongoException $ex) {
            return false;
        }

    }

    public function get_image($arr)
    {
        try {
        $mongoid = new MongoId($arr['image_id']);
            $result = $this->mongo_db->where(array('_id' => $mongoid,'status'=>array('$ne'=>'4')))->find_one('file');
//$result = $this->mongo_db->where(array('_id' => $mongoid,'status'=>array('$ne'=>'4')))->find_one('customer');
            //print_r($result); die;
            return $result;
        } catch (MongoException $ex) {
            return false;
        }        
    }

    public function image_delete($arr)
    {
        try {
            $id = $arr['image_id'];
            unset($arr['image_id']);
            //debug($id);
            $mongoid = new MongoId($id);
            //debug($mongoid); die;
            $arr['updated_at'] = time();
            $arr['status'] = '4';
            /*debug($arr); die;*/
            $result = $this->mongo_db->where('_id',$mongoid)->set($arr)->update('file',$arr);
            //print_r($result); die;
            return $result;
        } catch (MongoException $ex) {
            return false;
        }

    }


}

?>