<?php

class common extends CI_Model {

    function __construct() {
        parent::__construct();
        $http = "";
        if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {
            $http = "http://";
        } else {
            $http = "https://";
        }
        $prevurl = array("prevurl" => base_url());
        $this->session->set_userdata($prevurl);
        $this->session->set_userdata("currenturl", base_url());
    }

    public function get_extension($file_name) {
        $ext = explode('.', $file_name);
        $ext = array_pop($ext);
        return strtolower($ext);
    }

    function create_unique_slug($string, $table, $field = 'slug', $key = NULL, $value = NULL) {
        $t = & get_instance();
        $slug = url_title($string);
        $slug = strtolower($slug);
        $i = 0;
        $params = array();
        $params[$field] = $slug;

        if ($key)
            $params["$key !="] = $value;

        while ($t->db->where($params)->get($table)->num_rows()) {
            if (!preg_match('/-{1}[0-9]+$/', $slug))
                $slug .= '-' . ++$i;
            else
                $slug = preg_replace('/[0-9]+$/', ++$i, $slug);

            $params [$field] = $slug;
        }
        return $slug;
    }

    public function get_extensions($file_name = NULL) {
        $ext1 = explode('.', $file_name);
        $ext = array_pop($ext1);
        //print_r($this->config->item("allowedimages"));die;
        if (!in_array($ext, $this->config->item("allowedimages"))) {
            $this->session->set_flashdata("errormsg", "Wrong file format only jpg,png,gif allowded");
        } else {

            return strtolower($ext);
        }
    }

    public function get_extensions_attachement($file_name = NULL) {
        $ext1 = explode('.', $file_name);
        $ext = array_pop($ext1);
        //print_r($this->config->item("allowedimages"));die;
        if (!in_array($ext, $this->config->item("alloweddocs"))) {
            $this->session->set_flashdata("errormsg", "Wrong file format only doc, docx allowded");
        } else {

            return strtolower($ext);
        }
    }

/// for random genrator text	
    public function generate_random_number($digits = 6) {
        srand((double) microtime() * 10000000);
        $input = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");
        $random_generator = "";
        for ($i = 1; $i <= $digits; $i++) {
            if (rand(1, 2) == 1) {
                $rand_index = array_rand($input);
                $random_generator .=$input[$rand_index];
            } else {
                $random_generator .=rand(1, 9);
            }
        }
        return $random_generator;
    }

    public function generate_random_number_for_numbers($digits = 6) {
        srand((double) microtime() * 10000000);
        $input = array('1','2','3','4','5','6','7','8','9','0');
        $random_generator = "";
        for ($i = 1; $i <= $digits; $i++) {
            if (rand(1, 2) == 1) {
                $rand_index = array_rand($input);
                $random_generator .=$input[$rand_index];
            } else {
                $random_generator .=rand(1, 9);
            }
        }
        return $random_generator;
    }


    public function convert_date($arr) {
        $from_data = explode('/', $arr);
        $from = strtotime($from_data[1] . "-" . $from_data[0] . "-" . $from_data[2] . " " . "00:00:00");
        return $from;
    }

    function validate_email($email = NULL) {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }

    //to check login status
    public function check_authentication() {

        $controllername = $this->router->class;
        $methodname = $this->router->method;

        if (($controllername == "login") && $methodname != "logout") {
            $username = $this->session->userdata("username");
            if (isset($username) && $username != "") {
                redirect(base_url() . "dashboard");
            }
        }

        if ($controllername != "login") {
            // echo $this->config->item("usertype");die;
            if ($this->config->item("usertype") == "admin") {
                $this->db->select("username");
                $this->db->from("admin");
                $query = $this->db->get();
                $resultset = $query->row_array();
                //debug($resultset);
                //echo $this->session->userdata("username");
                //	echo $this->db->last_query();die;
                if ($resultset["username"] != $this->session->userdata("username")) {
                    $this->session->set_flashdata("errormsg", "Please login to access admin panel first");
                    redirect(base_url() . "login/");
                }
            }
        }
    }

    public function checkpasswordvalidity($arr) {
        $this->db->select("*");
        $this->db->from("admin");
        $this->db->where("username", $this->session->userdata("username"));
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        $result = $query->row_array();

        if ($this->validateHash($arr["oldpassword"], $result["password"])) {
            return false;
        } else {
            return true;
        }
    }

    //update user profile data
    public function update_profile($arr = NULL) {
        //2736f2f2cb760b84488b342f26e6210e:xl
        $newarr["password"] = $this->salt_password(array("password" => $arr["newpassword"]));
        if (isset($arr["username"]) && $arr["username"] != "") {
            $newarr["username"] = $arr["username"];
        }
        return $this->db->update("admin", $newarr);
    }

    //remove parameter from url
    public function removeUrl($parametername = NULL, $querystring = NULL) {
        $newquerystring = "";
        $querystring = explode("&", $querystring);

        foreach ($querystring as $key => $val) {
            $newval = explode("=", $val);
            if ($newval[0] != "") {
                if ($newval[0] != $parametername) {
                    $newquerystring.="&" . $newval[0] . "=" . $newval[1];
                }
            }
        }

        $newquerystring = substr($newquerystring, 1, strlen($newquerystring));

        return $newquerystring;
    }

    public function addUrl($parametername = NULL, $parametervalue = NULL, $querystring = NULL) {

        //echo $parametername."=".$parametervalue;		
        $querystring = explode("&", $querystring);
        $newquerystring = "";
        $i = 0;
        if (count($querystring) != 0 && $querystring[0] != "") {
            foreach ($querystring as $key => $val) {
                $valnew = explode("=", $val);
                if ($valnew[0] != $parametername) {
                    $newquerystring.="&" . $valnew[0] . "=" . $valnew[1];
                } else {
                    $newquerystring.="&" . $parametername . "=" . $parametervalue;
                    $i = 1;
                }
            }
        }
        if ($i == 0) {
            $newquerystring.="&" . $parametername . "=" . $parametervalue;
        }
        return $newquerystring = substr($newquerystring, 1, strlen($newquerystring));
    }

    //to check user login status 	
    public function is_logged_in() {

        $is_logged_in = $this->session->userdata('is_logged_in');
        if ($is_logged_in != true) {
            return false;
        }
    }
    
    //public function 

    //login user and set session
    public function authenticateuserlogin($loginarray) {

        $this->db->select("users.*");
        $this->db->from("users");
        $this->db->where(array("users.email" => $loginarray["email"], "users.status <>" => 4));
        $result = $this->db->get();
        $countrows = $result->num_rows();
        $result = $result->row_array();

        $response = array();
        if (!empty($result)) {
            if ($this->validateHash($loginarray["password"], $result["password"])) {
				if($result["status"] == 1 && $result["verified"] == 1 ) {
					$this->session->set_userdata('user_id', $result['id']);
					$this->session->set_userdata('is_logged_in', '1');
					$this->session->set_userdata('email', $result['email']);
					$this->session->set_userdata('name', $result['name']);
					$this->session->set_userdata('type', $result['type']);
					$this->session->set_userdata('status', $result['status']);
					$response['status'] = 'success';
					$response['message'] = 'Logging In';
					$response['data'] = '';
				} 
				else if($result["status"] == 1 && $result["verified"] == 0) {
                    $response['status'] = 'error';
                    $response['message'] = 'User not verified';
                    $response['data'] = '';
                } else {
                    $response['status'] = 'error';
                    $response['message'] = 'You are blocked by the administrator or your account closed';
                    $response['data'] = '';
                }
                
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Invalid email or password';
                $response['data'] = '';
            }
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Email does not exist';
            $response['data'] = '';
        }
        return $response;
    }

    public function authenticateuserlogin_ws($loginarray) {

        $this->db->select("users.*");
        $this->db->from("users");
        $this->db->where(array("users.email" => $loginarray["email"], "users.status <>" => 4));
        $result = $this->db->get();
        $result = $result->row_array();

        $response = array();
        if (!empty($result)) {
            if ($this->validateHash($loginarray["password"], $result["password"])) {
                if($result["status"] == 1 && $result["verified"] == 1 ) {
                    $response['status'] = '1';
                    $response['message'] = 'Successfully Logged In';
                    $response['user_id'] = $result['id'];
                    $response['type'] = $result['type'];
                    $response['email'] = $result['email'];
                }
                else if($result["status"] == 1 && $result["verified"] == 0) {
                    $response['status'] = '0';
                    $response['message'] = 'User not verified';
                } else {
                    $response['status'] = '0';
                    $response['message'] = 'You are blocked by the administrator';
                }

            } else {
                $response['status'] = '0';
                $response['message'] = 'Invalid email or password';
            }
        } else {
            $response['status'] = '0';
            $response['message'] = 'Email does not exist';
        }
        return $response;
    }
	
	public function authenticateuserlogin_ws_unverified($loginarray) {

        $this->db->select("users.*");
        $this->db->from("users");
        $this->db->where(array("users.email" => $loginarray["email"], "users.status <>" => 4));
        $result = $this->db->get();
        $result = $result->row_array();

        $response = array();
        if (!empty($result)) {
            if ($this->validateHash($loginarray["password"], $result["password"])) {
                if($result["status"] == 1) {
                    $response['status'] = '1';
                    $response['message'] = 'Successfully Logged In';
                    $response['user_id'] = $result['id'];
                    $response['type'] = $result['type'];
                    $response['email'] = $result['email'];
                    $response['verified'] = $result['verified'];
					if(is_user_subscribed($result['id'])){
						$response['subscribed'] = '1';
					} else {
						$response['subscribed'] = '0';
					}
                    
                    $response['form_filled'] = $result['form_filled'];
					if(empty($result['form_flag'])) {
						$response['form_flag'] = "";
					} else {
						$response['form_flag'] = $result['form_flag'];
					}
                }
                else {
                    $response['status'] = '0';
                    $response['message'] = 'You are blocked by the administrator';
                }

            } else {
                $response['status'] = '0';
                $response['message'] = 'Invalid email or password';
            }
        } else {
            $response['status'] = '0';
            $response['message'] = 'Email does not exist';
        }
        return $response;
    }

    public function cookielogin($email) {

        $this->db->select("*");
        $this->db->from("users");
        $this->db->where(array("email" => $email, "status " => 1));
        $result = $this->db->get();
        $countrows = $result->num_rows();
        $result = $result->row_array();

        $response = array();
        if (!empty($result)) {
				   $this->session->set_userdata('email', $result['email']);
				   $this->session->set_userdata('name', $result['name']);
				   $this->session->set_userdata('type', $result['type']);
				   $this->session->set_userdata('status', $result['status']);
            return $this->session->set_userdata('user_id', $result['id']);
        }
    }

//for user login

    public function login_check_user($data) {
        $login["email"] = trim($data['email']);
        $login["password"] = trim($data['password']);

        return $this->common->authenticateuserlogin($login);
    }

    public function login_check_user_ws($data) {
        $login["email"] = trim($data['email']);
        $login["password"] = trim($data['password']);

        return $this->common->authenticateuserlogin_ws($login);
    }
	
	public function login_check_user_ws_unverified($data) {
        $login["email"] = trim($data['email']);
        $login["password"] = trim($data['password']);

        return $this->common->authenticateuserlogin_ws_unverified($login);
    }

    public function get_age($birth_date) {
        return floor((time() - strtotime($birth_date)) / 31556926);
    }

    //make encrypted. password
    public function salt_password($arr = NULL) {
        //print_r($arr["password"]);die;
        $salt_key = $this->common->random_generator(2);
        $pas = md5($salt_key . $arr["password"]);
        $column = ':';
        return $pas . $column . $salt_key;
    }

    public function validateHash($password = NULL, $hash = NULL) {


        $hashArr = explode(':', $hash);

        if (md5($hashArr[1] . $password) === $hashArr[0]) {
            //echo "matched";die;
            return true;
        } else {
            //echo "not matched";die;
            return false;
        }
    }

    public function random_generator($digits = NULL) {
        // function starts
        srand((double) microtime() * 10000000);
        $input = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");
        $random_generator = "";
        // Initialize the string to store random numbers
        for ($i = 1; $i <= $digits; $i++) {
            // Loop the number of times of required digits
            if (rand(1, 2) == 1) {
                // to decide the digit should be numeric or alphabet
                // Add one random alphabet
                $rand_index = array_rand($input);
                $random_generator .=$input[$rand_index];
                // One char is added
            } else {
                // Add one numeric digit between 1 and 9
                $random_generator .=rand(1, 9);
                // one number is added
            }
            // end of if else
        }
        // end of for loop
        return $random_generator;
    }

///===================================================================================================/
    public function get_time_stamp($date = NULL) {
        $date = explode("/", $date);
        $date = $date[1] . "-" . $date[0] . "-" . $date[2]; //d-m-y
        $time = strtotime($date);
        return $time;
    }

    public function get_date_time($date_time) {
        $posted_date = array();
        $posted_date_time = array();

        $posted_date_time = explode(" ", $date_time);
        $posted_date = explode("/", $posted_date_time[0]);
        $posted_time = explode(":", $posted_date_time[1]);
        $starttime = $posted_date[0] . "-" . $posted_date[1] . "-" . $posted_date[2] . " " . $posted_time[0] . ":" . $posted_time[1] . ":00 " . $posted_date_time[3];
        $result = strtotime($starttime);
        //$result = mktime($posted_time[0],$posted_time[1],0,$posted_date[1],$posted_date[0],$posted_date[2],$posted_date_time[2]);
        return $result;
    }

// for get data by id
    public function get_data_passing_id($table, $id) {
        $this->db->select("*");
        $this->db->from("$table");
        $this->db->where(array("status" => 1, "archive <>" => "1", 'id' => $id));
        $this->db->order_by("name asc");
        $result = $this->db->get();
        // $this->db->last_query(); die;
        $c = $result->result_array();
        //echo print_r($c); 
        return $c;
    }

//for content pages data like login, signup, security
    public function getcontentpagedata($arr) {
        //$resultset=$this->db->select("*")->from("contents")->get();
        $this->db->select("*");
        $this->db->from("content_pages");
        $this->db->where(array("page_name" => $arr));
        $query = $this->db->get();
        //$this->db->last_query();
        return $resultset = $query->row_array();
    }

//for header phone number and email id
    public function header_content_data() {
        $sql = "select contact_email, contact_number from content_pages where id=4";
        $query = $this->db->query($sql);
        $resultset = $query->row_array();

        return $resultset;
    }

//for update logged in time
    public function last_login($table, $id) {
        $this->db->where("id", $id);
        $noti['last_login'] = time();
        $result = $this->db->update("$table", $noti);
        //echo $this->db->last_query(); die;
        return $result;
    }

    //show time in ago
    public function convert_time_days($time) {

        $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
        $lengths = array("60", "60", "24", "7", "4.35", "12", "10");
        $now = time();
        $difference = $now - $time;
        $tense = "ago";

        for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
            $difference /= $lengths[$j];
        }

        $difference = round($difference);
        if ($difference != 1) {
            $periods[$j].= "s";
        }
        return "$difference $periods[$j] ago ";
    }

    public function validate_forgot_email_exist($arr) {

        $this->db->select('email');
        $this->db->from('users');
        if (empty($arr["id"])) {
            $this->db->where(array("email" => $arr["email"], "status <>" => "4"));
        } else {
            $this->db->where(array("email" => $arr["email"], "status <>" => "4", "id <>" => $arr["id"]));
        }
        $query = $this->db->get();
        //echo	$this->db->last_query();die;
        $resultset = $query->num_rows();

        if ($resultset == 0) {
            return false;
        } else {
            return true;
        }
    }

    public function get_mktime_time_stamp($date = NULL) {
        $data = explode("-", $date);
        $open_time = mktime(23, 59, 59, $data[1], $data[2], $data[0]);
        return $open_time;
    }

    public function get_user_name($userid, $type) {
        if ($type == "personal") {
            $query = $this->db->get_where('users', array('id' => $userid));
            //echo $this->db->last_query();die;
            $result = $query->row_array(); //For single row
            //debug($result);
            $name = $result["name"];
        } else {
            $query = $this->db->get_where('organisations', array('id' => $userid));
            $result = $query->row_array(); //For single row
            $name = $result["name"];
        }

        return $name;
    }

    public function check_email_availabilty($email) {
        //$this->db->select('email');
        //$this->db->from('users');
        $resultset = $this->mongo_db->where('email', $email)->find_one('user');
        //$resultset = $query->num_rows();
        if ($resultset == 0) {
            return true;
        } else {
            return false;
        }
    }

    
    public function check_model_availabilty($identifier,$key) {
        $mongoid = new MongoId($key);
        $resultset = $this->mongo_db->where_not_in('_id', array($mongoid))->where('identifier', $identifier)->find_one('models');
        //$resultset = $query->num_rows();
        //debug($resultset);
        if ($resultset == 0) {
            return true;
        } else {
            return false;
        }
    }

    public function check_instrument_name_availabilty($displayName) {
        //$this->db->select('email');
        //$this->db->from('users');
        //debug('here'); die;
        $resultset = $this->mongo_db->where('displayName', $displayName)->find_one('instruments');
        //$resultset = $query->num_rows();
        if ($resultset == 0) {
            return true;
        } else {
            return false;
        }
    }

    /*public function check_attribute_availabilty($id) {
        //$this->db->select('*');
        //$this->db->from('attributes');
        //$this->db->where("attribute_id", $id);
        //$resultset = $this->mongo_db->where('attribute_id', $id)->find_one('attributes');
        //$resultset = $query->num_rows();
        //echo $id; die;
        $result = $this->mongo_db
        $resultset = $this->mongo_db->where(array('$strcasecmp'=>array("attribute_id",
         $id)))->find_one('attributes');
        //print_r($resultset); die;
        if ($resultset == 0) {
            return true;
        } else {
            return false;
        }
    }
	*/
	 public function check_email_existence($email, $id) {
        $this->db->select('email');
        $this->db->from('users');
        if ($id != "") {
            $this->db->where(array('email' => $email, 'distributor_id <>' => $id, "status <>" => 4));
        } else {
            $this->db->where(array('email' => $email, "status <>" => 4));
        }
        $query = $this->db->get();

        $resultset = $query->num_rows();
        if ($resultset == 0) {
           return false;
        } else {
            return true;
        }
    }

    public function check_customer_number_availabilty($customer_number, $id = NULL) {
        $this->db->select('customer_number');
        $this->db->from('distributors');
        if ($id != "") {
            $this->db->where(array('customer_number' => $customer_number, 'id <>' => $id, "status <>" => 4));
        } else {
            $this->db->where(array('customer_number' => $customer_number, "status <>" => 4));
        }
        $query = $this->db->get();
        $resultset = $query->num_rows();
        if ($resultset == 0) {
            return true;
        } else {
            return false;
        }
    }

    public function check_colorlist_availabilty($arr) {
        $this->db->select('color_lists.color_list');
        $this->db->from('color_lists');
        if ($arr['id'] != "") {
            $this->db->where(array('color_list' => $arr['color_list'], 'id <>' => $arr['id'], "status <>" => 4));
        } else {
            $this->db->where(array('color_list' => $arr['color_list'], "status <>" => 4));
        }
        $query = $this->db->get();
        $resultset = $query->num_rows();
        if ($resultset == 0) {
            return true;
        } else {
            return false;
        }
    }

    public function check_color_availabilty($arr) {
        $this->db->select('colors.color');
        $this->db->from('colors');
        if ($arr['id'] != "") {
            $this->db->where(array('color' => $arr['color'], 'id <>' => $arr['id'], "status <>" => 4));
        } else {
            $this->db->where(array('color' => $arr['color'], "status <>" => 4));
        }
        $query = $this->db->get();
        $resultset = $query->num_rows();
        if ($resultset == 0) {
            return true;
        } else {
            return false;
        }
    }

    public function check_user_cookie() {

        $cookie_data = $this->input->cookie('cm_email');
        if (!empty($cookie_data)) {

            $this->cookielogin($cookie_data);
        }
    }

    public function count_product_finishing($arr) {
        $counts = array();
        foreach ($arr as $key => $subarr) {
            // Add to the current product_finishing count if it exists
            if (isset($counts[$subarr['product_finishing']])) {
                $counts[$subarr['product_finishing']] ++;
            }
            // or initialize to 1 if it doesn't exist
            else
                $counts[$subarr['product_finishing']] = 1;

            // Or the ternary one-liner version 
            // instead of the preceding if/else block
            $counts[$subarr['product_finishing']] = isset($counts[$subarr['product_finishing']]) ? $counts[$subarr['product_finishing']] ++ : 1;
        }
        return $counts;
    }

    public function count_product_material($arr) {
        $counts = array();
        foreach ($arr as $key => $subarr) {
            // Add to the current product_finishing count if it exists
            if (isset($counts[$subarr['material']])) {
                $counts[$subarr['material']] ++;
            }
            // or initialize to 1 if it doesn't exist
            else
                $counts[$subarr['material']] = 1;

            // Or the ternary one-liner version 
            // instead of the preceding if/else block
            $counts[$subarr['material']] = isset($counts[$subarr['material']]) ? $counts[$subarr['material']] ++ : 1;
        }
        return $counts;
    }

    public function count_product_color($arr) {
        $result = array();
        $material = array();
        foreach ($arr as $key => $val) {
            if (array_key_exists($val['material'], $material)) {

                array_push($material[$val['material']], $val['color']);
            } else {
                $material[$val['material']] = array();

                array_push($material[$val['material']], $val['color']);
            }
        }
        foreach ($material as $key => $val) {
            $counts = array();
            foreach ($val as $abc => $subarr) {

                // Add to the current product_finishing count if it exists
                if (isset($counts[$subarr])) {
                    $counts[$subarr] ++;
                }
                // or initialize to 1 if it doesn't exist
                else
                    $counts[$subarr] = 1;

                // Or the ternary one-liner version 
                // instead of the preceding if/else block
                $counts[$subarr] = isset($counts[$subarr]) ? $counts[$subarr] ++ : 1;
            }
            $result[$key] = $counts;
        }
        return $result;
    }

    public function getproductprice($product_code, $product_attr_table) {

        $customer_number = $this->session->userdata('customer_number');
        $price_group = $this->session->userdata('price_group');
        $time = time();

        ////// check product exist for customer in override price table ///////////////
        $this->db->select("price");
        $this->db->from("override_price_lists");
        $where = "product_code = '" . $product_code . "' and customer_number = '" . $customer_number . "' and effective_date <=  '" . $time . "' and expiration_date >= '" . $time . "' and status !=4";
        $this->db->where($where);
        $this->db->order_by('id', 'asc');
        $this->db->limit(1, 0);
        $query = $this->db->get();
        $count = $query->num_rows();
        $resultset = $query->row_array();

        if ($count > 0) {
            $price = $resultset['price'];
        } else {

            ////// if price group assign to user,gt product price from price list  table ///////////////
            if (!empty($price_group) > 0) {
                $this->db->select($price_group);
                $this->db->from("product_price_lists");
                $where = "product_code = '" . $product_code . "' and status !=4";
                $this->db->where($where);
                $this->db->order_by('id', 'asc');
                $this->db->limit(1, 0);
                $query = $this->db->get();
                $count = $query->num_rows();
                $result = $query->row_array();

                if ($count > 0) {
                    $price = $result[$price_group];
                } else {
                    $this->db->select($product_attr_table . ".price");
                    $this->db->from($product_attr_table);
                    $this->db->join("products", "products.id=" . $product_attr_table . ".product_id");
                    $where = "products.product_code = '" . $product_code . "' and products.status != 4";
                    $this->db->where($where);
                    $query = $this->db->get();
                    $product = $query->row_array();
                    $price = $product['price'];
                }
            } else {
                $this->db->select($product_attr_table . ".price");
                $this->db->from($product_attr_table);
                $this->db->join("products", "products.id=" . $product_attr_table . ".product_id");
                $where = "products.product_code = '" . $product_code . "' and products.status != 4";
                $this->db->where($where);
                $query = $this->db->get();
                $product = $query->row_array();
                $price = $product['price'];
            }
        }

        return $price;
    }
	
	public function check_category_name($arr) {
		$this->db->select("*");
		$this->db->from("categories");
		$this->db->where("title", $arr['title']);
		$q = $this->db->get();
		$result = $q->row_array();
		if(count($result) > 0) {
			return true;
		}
	}

    public function check_city_name($arr) {
        $this->db->select("*");
        $this->db->from("cities");
        $this->db->where("city", $arr['city']);
        $q = $this->db->get();
        $result = $q->row_array();
        if(count($result) > 0) {
            return true;
        }
    }
	
	public function check_sub_provider_name($arr) {
        $this->db->select("*");
        $this->db->from("sub_providers");
        $this->db->where("sub_provider_name", $arr['sub_provider_name']);
        $q = $this->db->get();
        $result = $q->row_array();
        if(count($result) > 0) {
            return true;
        }
    }
	public function check_sub_sub_provider_name($arr) {
        $this->db->select("*");
        $this->db->from("sub_sub_providers");
        $this->db->where("sub_sub_provider_name", $arr['sub_sub_provider_name']);
        $q = $this->db->get();
        $result = $q->row_array();
        if(count($result) > 0) {
            return true;
        }
    }

    public function check_state_name($arr) {
        $this->db->select("*");
        $this->db->from("states");
        $this->db->where("state", $arr['state']);
        $this->db->where("status <>",4);
        $q = $this->db->get();
        $result = $q->row_array();
        if(count($result) > 0) {
            return true;
        }
    }
	public function check_provider_name($arr) {
        $this->db->select("*");
        $this->db->from("providers");
        $this->db->where("provider_name", $arr['provider_name']);
        $q = $this->db->get();
        $result = $q->row_array();
        if(count($result) > 0) {
            return true;
        }
    }
    
      public function count_product_lable($arr) {
		  
        $counts = array();
        foreach ($arr as $key => $subarr) {
            // Add to the current product_finishing count if it exists
            if (isset($counts[$subarr['product_lable']])) {
                $counts[$subarr['product_lable']] ++;
            }
            // or initialize to 1 if it doesn't exist
            else
                $counts[$subarr['product_lable']] = 1;

            // Or the ternary one-liner version 
            // instead of the preceding if/else block
            $counts[$subarr['product_lable']] = isset($counts[$subarr['product_lable']]) ? $counts[$subarr['product_lable']] ++ : 1;
        }
		
        return $counts;
    }
	
	 public function count_product_size($arr) {
        $result = array();
        $lable = array();
        foreach ($arr as $key => $val) {
            if (array_key_exists($val['product_lable'], $lable)) {

                array_push($lable[$val['product_lable']], $val['size']);
            } else {
                $lable[$val['product_lable']] = array();

                array_push($lable[$val['product_lable']], $val['size']);
            }
        }
		
        foreach ($lable as $key => $val) {
            $counts = array();
            foreach ($val as $abc => $subarr) {

                // Add to the current product_finishing count if it exists
                if (isset($counts[$subarr])) {
                    $counts[$subarr] ++;
                }
                // or initialize to 1 if it doesn't exist
                else
                    $counts[$subarr] = 1;

                // Or the ternary one-liner version 
                // instead of the preceding if/else block
                $counts[$subarr] = isset($counts[$subarr]) ? $counts[$subarr] ++ : 1;
            }
            $result[$key] = $counts;
        }
		
        return $result;
    }
	
	public function get_product_categories() {
		$this->db->select("*");
		$this->db->from("categories");
		$this->db->where("status" , 1);
		$q = $this->db->get();
		return $q->result_array();
	}
	
	public function get_states() {
		$this->db->select("state, id");
		$this->db->from("states");
		$this->db->where("status" , 1);
		$this->db->order_by("state asc");
		$q = $this->db->get();
		return $q->result_array();
	}
	
	public function get_cities($state_id) {
		$this->db->select("city, id");
		$this->db->from("cities");
		$this->db->where(array("status" => 1, "state_id" => $state_id));
		$q = $this->db->get();
		return $q->result_array();
	}
	
	public function state_name($state_id) {
		$this->db->select("*");
		$this->db->from("states");
		$this->db->where(array("status" => 1, "id" => $state_id));
		$q = $this->db->get();
		$result = $q->row_array();
		return $result['state'];
	}
	public function city_name($city_id) {
		$this->db->select("*");
		$this->db->from("cities");
		$this->db->where(array("status" => 1, "id" => $city_id));
		$q = $this->db->get();
		$result = $q->row_array();
		return $result['city'];
	}
	
	public function get_providers() {
		$this->db->select("provider_name, id, navigation_name");
		$this->db->from('providers');
		$this->db->where('providers.status', 1);
		$this->db->order_by('providers.id asc');
		$q = $this->db->get();
		return $q->result_array();
	}
	public function get_sub_providers($id) {
		$this->db->select("sub_provider_name, id");
		$this->db->from('sub_providers');
		$this->db->where(array('sub_providers.status' => 1, "sub_providers.provider_id" => $id));
		$this->db->order_by('sub_providers.id asc');
		$q = $this->db->get();
		return $q->result_array();
	}
	public function get_sub_sub_providers($id) {
		$this->db->select("sub_sub_provider_name, id");
		$this->db->from('sub_sub_providers');
		$this->db->where(array('sub_sub_providers.status'=> 1,"sub_sub_providers.sub_provider_id" => $id));
		$this->db->order_by('sub_sub_providers.id asc');
		$q = $this->db->get();
		return $q->result_array();
	}
	public function get_top_menu_providers() {
		$this->db->select("*");
		$this->db->from('providers');
		$this->db->where(array('providers.status'=> 1));
		$this->db->order_by('providers.sort_order, providers.id asc');
		$q = $this->db->get();
		return $q->result_array();
	}
	
	public function prime_member_check($user_id) {
		$this->db->select("*");
		$this->db->from('subscriptions');
		$this->db->where(array('subscriptions.status'=> 1, 'subscriptions.user_id' => $user_id));
		$q = $this->db->get();
		return $q->row_array();
	}
	
	public function is_subscribed() {
		$user_id = $this->session->userdata('user_id');
		if(!empty($user_id)) {
			$result = $this->prime_member_check($user_id);
			if(!empty($result)) {
				return true;
			} else {
				redirect(base_url());
			}
		}
	}

}