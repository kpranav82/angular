<?php

require 'PHPMailer-master/PHPMailerAutoload.php';

class email_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function test_config() {

        //debug($config);
    }

    public function sendIndividualEmail1() {
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        $ci = get_instance();
        $ci->load->library('email');
        $config['protocol'] = "smtp";
        $config['smtp_host'] = "smtp.googlemail.com";
        $config['smtp_port'] = "465";
        $config['smtp_user'] = "slinfydotcom@gmail.com";
        $config['smtp_pass'] = "khattra@007";
        $config['smtp_crypto'] = 'ssl';
        $config['charset'] = "utf-8";
        $config['mailtype'] = "html";
        $config['newline'] = "\r\n";

        $ci->email->initialize($config);

        $ci->email->from('sarvjeetsabherwal@gmail.com', 'Blabla');
        $list = array('pranav.slinfy@gmail.com');
        $ci->email->to($list);
        $this->email->reply_to('sarvjeetsabherwal@gmail.com', 'Explendid Videos');
        $ci->email->subject('This is an email test');
        $ci->email->message('It is working. Great!');
        $ci->email->send();
    }

    public function sendIndividualEmail($emailarr) {
        //print_r($emailarr); die;
        error_reporting(E_ALL);
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: Roccit <no-reply@roccit.us>' . "\r\n";
        $message = $emailarr['message'];
        $subject= $emailarr['subject'];
        $to= $emailarr['to'];
        $result = mail($to,$subject,$message,$headers);        
        if ($result) {
            $err = 0;
        } else {
          echo 'Error';
         }
        return $err;
    }

    /*     * *********************************************** Email function ends ************************************************* */

    public function UserPasswordsendIndividualEmail($emailarr) {

        @$this->load->library('email', $config);
        @$this->load->library('parser', $config);
        $this->email->set_newline("\r\n");

        $this->email->to($emailarr["to"]); // change it to yours
        if ($_SERVER['SERVER_NAME'] == "localhost" || $_SERVER['SERVER_NAME'] == "192.168.1.226" || $_SERVER['SERVER_NAME'] == "112.196.33.85") {
            $this->email->from($config['smtp_user'], $this->config->item('sitename'));
        } else {
            $this->email->from($this->config->item('admin_email'), $this->config->item('sitename'));
        }
        $this->email->subject($emailarr["subject"]);
        $this->email->message($emailarr["message"]);
        $result = $this->email->send();
        if ($result) {
            $err = true;
        } else {
            //show_error($this->email->print_debugger());
            $this->email->print_debugger();
            $err = false;
        }
        return $err;
    }

    public function send_contact_email($emailarr) {
        //print_r($emailarr); die;

        @$this->load->library('email', $config);
        @$this->load->library('parser', $config);
        $this->email->set_newline("\r\n");

        $this->email->to($emailarr["to"]); // change it to yours
        if ($_SERVER['SERVER_NAME'] == "localhost" || $_SERVER['SERVER_NAME'] == "192.168.1.226" || $_SERVER['SERVER_NAME'] == "112.196.33.85") {
            $this->email->from($config['smtp_user'], $this->config->item('sitename'));
        } else {
            $this->email->from($this->config->item('admin_email'), $this->config->item('sitename'));
        }
        //print_r($emailarr); die;

        $this->email->subject($emailarr["subject"]);
        $this->email->message($emailarr["message1"]);
        $result = $this->email->send();
        if ($result) {
            $err = true;
        } else {
            //show_error($this->email->print_debugger());
            $this->email->print_debugger();
            $err = false;
        }
        return $err;
    }

    public function send_email_vtracking($emailarr) {

        @$this->load->library('email', $config);
        @$this->load->library('parser', $config);
        $this->email->set_newline("\r\n");

        $this->email->to($emailarr["to"]); // change it to yours
        if ($_SERVER['SERVER_NAME'] == "localhost" || $_SERVER['SERVER_NAME'] == "192.168.1.226" || $_SERVER['SERVER_NAME'] == "112.196.33.85") {
            $this->email->from($config['smtp_user'], $this->config->item('sitename'));
        } else {
            $this->email->from($this->config->item('admin_email'), $this->config->item('sitename'));
        }
        //print_r($emailarr); die;

        $this->email->subject($emailarr["subject1"]);
        $this->email->message($emailarr["message1"]);
        $result = $this->email->send();
        if ($result) {
            $err = true;
        } else {
            //show_error($this->email->print_debugger());
            $this->email->print_debugger();
            $err = false;
        }
        return $err;
    }

}
