<?php

class attributes_model extends CI_Model {

    function __construct() {
        parent ::__construct();
    }

    public function add_attributes($arr) {
        $arr['status'] = '1';
        $arr['measured'] = '0';
        $arr['created_at'] = time();
        $arr['updated_at'] = time();
        $result = $this->mongo_db->insert('attributes', $arr);
        return $result;
    }

    public function get_attributes_list($start_from, $num_rec_per_page,$search) {
        if(!empty($search))
        {
            $result = $this->mongo_db->where('status', '1')->like('name',$search)->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('attributes');
        return $result;
        }
        else
        {
            $result = $this->mongo_db->where('status', '1')->order_by(array('created_at' => 'DESC'))->limit($num_rec_per_page)->offset($start_from)->get('attributes');
            return $result;
        }
    }

    public function get_attributes_model() 
        {
            $result = $this->mongo_db->where('status', '1')->limit(3)->get('attributes');
            //print_r($result); die;
            return $result;
        }
    

    public function get_all_attributes_list($search) {
        if(!empty($search))
        {
            $result = $this->mongo_db->where('status', '1')->like('name',$search)->get('attributes');
            return $result;
        }
        else
        {
            $result = $this->mongo_db->where('status', '1')->get('attributes');
            return $result;
        }
    }

    public function get_attribute($id) {
        try {
            $mongoid = new MongoId($id);
            return $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->find_one('attributes');
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function get_attribute_by_atributeid($id) {
        try {
            //echo 'here'; die;
            //$mongoid = new MongoId($id);
            return $result = $this->mongo_db->where(array('attribute_id' => $id, "status" => '1'))->find_one('attributes');
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function update_attribute($attribute_arr) 
    {
        try {
        $attribute_id = $attribute_arr['attribute_id'];
        unset($attribute_arr['attribute_id']);
        $attribute_arr['updated_at'] = time();
        $result = $this->mongo_db->where(array('_id' => new MongoId($attribute_id), "status" => '1'))->set($attribute_arr)->update('attributes', $attribute_arr);
        return $result;
        } catch (MongoException $ex) {
            return false;
        }
    }

}

?>