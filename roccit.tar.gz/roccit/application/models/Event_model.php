<?php
class event_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function add_event($event_arr)
	{
		$event_arr['status'] = '1';
		$event =$this->mongo_db->insert('event',$event_arr);
		return $event;
	}
}
?>