<?php

class users_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function add_users($arr) {
        $arr['status'] = '1';
        //$arr['confim_code'] = ''; 
        $arr['created_at'] = time();
        $arr['updated_at'] = time();
        $result = $this->mongo_db->insert('user', $arr);
        return $result;
    }

    public function check_login($arr) {
        $arr["email"] = trim($arr['email']);
        $arr["password"] = trim($arr['password']);
        $result = $this->mongo_db->where(array('email' => $arr['email'], "status" => '1'))->find_one('user');
        return $result;
    }

    public function manage_users() {
        return $result = $this->mongo_db->where('status', '1')->get('user');
    }

    public function edit_users($id) {
		try {
			$mongoid = new MongoId($id);
			return $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->find_one('user');
		} catch (MongoException $ex) {
			return false;
		}
    }

    public function get_user($id) {
		try {
            //print_r($id); die;
			$mongoid = new MongoId($id);
			return $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->find_one('user');
		} catch (MongoException $ex) {
			return false;
		}
    }

    public function update_user($arr) {
        try {

            $id = $arr['user_id'];
            $mongoid = new MongoId($id);
            unset($arr['user_id']);
            $arr['updated_at'] = time();
            $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->set($arr)->update('user', $arr);
        return $result;
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function user_list()
    {
        $result = $this->mongo_db->where('status', '1')->get('user');
        /* print_r($result); die; */
        return $result;
    }

/*    public function delete_user($user_id) {
        $result = $this->mongo_db->where('_id', new MongoId($user_id))->delete('user');
        return $result;
    }
*/

    /*public function forget_password($arr)
    {
        $result = $this->mongo_db->where(array('email' => $arr['email'], "status" => '1'))->find_one('user');
        return $result;
    }

    public function change_password($arr)
    {
        echo 'here'; die;
    }
    */
}

?>