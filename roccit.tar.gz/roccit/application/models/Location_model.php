<?php
class location_model extends CI_Model
{
	function __construct()
	{
		parent:: __construct();
	}

	public function add_location($arr)
	{
		$arr['status'] = '1';
		$arr['created_at'] = time();
		$arr['updated_at'] = time();
		//print_r($arr); die;
		$result = $this->mongo_db->insert('location',$arr);
		return $result;
	}

	public function location_list()
	{
		$result = $this->mongo_db->where('status','1')->get('location');
		return $result;
	}
}
?>