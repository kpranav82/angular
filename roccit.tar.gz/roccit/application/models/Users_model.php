<?php

class Users_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function add_users($arr) {
        $arr['status'] = '1';
        $arr['is_verified'] = '0';
        /*$arr['confim_code'] = $this->common->generate_random_number_for_numbers();*/ 
        $arr['created_at'] = time();
        $arr['updated_at'] = time();
        //debug($arr); die;
        $result = $this->mongo_db->insert('user', $arr);
        return $result;
    }

    public function check_login($arr) {
        $arr["email"] = trim($arr['email']);
        $arr["password"] = trim($arr['password']);
        $result = $this->mongo_db->where(array('email' => $arr['email'], "status" => '1'))->find_one('user');
        return $result;
    }

    public function check_login_verification($arr) {
        $arr["email"] = trim($arr['email']);
        $arr["password"] = trim($arr['password']);
        $result = $this->mongo_db->where(array('email' => $arr['email'], "status" => '1','is_verified'=> '0'))->find_one('user');
        return $result;
    }
	
	   public function check_email_verification_for_password($arr) {
        $arr["email"] = trim($arr['email']);
        //$arr["password"] = trim($arr['password']);
        $result = $this->mongo_db->where(array('email' => $arr['email'], "status" => '1','is_verified'=> '0'))->find_one('user');
        return $result;
    }

    public function manage_users() {
        return $result = $this->mongo_db->where('status', '1')->get('user');
    }

    public function edit_users($id) {
		try {
			$mongoid = new MongoId($id);
			return $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->find_one('user');
		} catch (MongoException $ex) {
			return false;
		}
    }

    public function get_user($id) {
		try {
            //print_r($id); die;
			$mongoid = new MongoId($id);
			return $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->find_one('user');
		} catch (MongoException $ex) {
			return false;
		}
    }

    public function update_user($arr) {
        try {

            $id = $arr['user_id'];
            $mongoid = new MongoId($id);
            unset($arr['user_id']);
            $arr['updated_at'] = time();
            $result = $this->mongo_db->where(array('_id' => $mongoid, "status" => '1'))->set($arr)->update('user', $arr);
        return $result;
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function user_list()
    {
        $result = $this->mongo_db->where('status', '1')->get('user');
        /* print_r($result); die; */
        return $result;
    }

/*    public function delete_user($user_id) {
        $result = $this->mongo_db->where('_id', new MongoId($user_id))->delete('user');
        return $result;
    }
*/

    /*public function forget_password($arr)
    {
        $result = $this->mongo_db->where(array('email' => $arr['email'], "status" => '1'))->find_one('user');
        return $result;
    }

    public function change_password($arr)
    {
        echo 'here'; die;
    }
    */

    public function verication_update($verification_code,$confirm_code) {
        /*$mongoid = new MongoId($verification_code);
        unset($verification_code);*/
        $arr['confirm_code'] = '0';
        $arr['is_verified'] ='1';
        $arr['updated_at'] = time();
        //debug($verification_code); debug($confirm_code);  debug($arr);die;
        $result = $this->mongo_db->where(array('_id' => new MongoId($verification_code), "status" => '1', "confirm_code" =>$confirm_code))->set($arr)->update('user',$arr);
        //echo $result; die;
        return $result;

    }

    public function update_confirm_code_update($register_arr) {
        //debug($register_arr);
        $email = $register_arr['email'];
        unset($register_arr['email']);
        $arr['updated_at'] = time();
        $result = $this->mongo_db->where(array('email' => $email, "status" => '1',"is_verified"=>"0"))->set($register_arr)->update('user',$arr);
        //echo $result; die;
        return $result;
    }

    public function update_confirm_code_for_password($register_arr) {
        //debug($register_arr); die;
        $email = $register_arr['email'];
        unset($register_arr['email']);
        $arr['updated_at'] = time();
        $result = $this->mongo_db->where(array('email' => $email, "status" => '1',"is_verified"=>"1"))->set($register_arr)->update('user',$arr);
        //echo $result; die;
        return $result;
    }

        public function get_user_by_email($email) {
        try {
            //print_r($id); die;
            //$mongoid = new MongoId($id);
            return $result = $this->mongo_db->where(array('email' => $email, "status" => '1',"is_verified"=>"0"))->find_one('user');
        } catch (MongoException $ex) {
            return false;
        }
    }
    public function get_user_by_email_verified_user($email) {
        try {
            //print_r($id); die;
            //$mongoid = new MongoId($id);
            return $result = $this->mongo_db->where(array('email' => $email, "status" => '1',"is_verified"=>"1"))->find_one('user');
        } catch (MongoException $ex) {
            return false;
        }
    }
	public function get_user_by_email_verified_user_update($email,$confirm_code) {
        try {
            //print_r($id); die;
            //$mongoid = new MongoId($id);
            return $result = $this->mongo_db->where(array('email' => $email, "status" => '1',"is_verified"=>"1", "confirm_code" => $confirm_code))->find_one('user');
        } catch (MongoException $ex) {
            return false;
        }
    }

    public function email_password_update($verification_code,$confirm_code,$password) {
        /*$mongoid = new MongoId($verification_code);
        unset($verification_code);*/
        $arr['confirm_code'] = '0';
        $arr['updated_at'] = time();
        $arr['password'] = $password;
        //debug($verification_code); debug($confirm_code);  debug($arr);die;
        $result = $this->mongo_db->where(array('email' => $verification_code, "status" => '1', "confirm_code" =>$confirm_code,'is_verified' =>'1'))->set($arr)->update('user',$arr);
        //echo $result; die;
        return $result;

    }

}

?>