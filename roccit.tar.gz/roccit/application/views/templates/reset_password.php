<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table width="800" style="border-collapse:collapse; border:1px solid #ccc;" cellpadding="0" cellspacing="0" align="center">
	<tr>
		<td>
			<table style="background-color:#2a97ae;" width="100%" border="0" cellpadding="9" cellspacing="0">
				<tr>
					<td style="padding: 11px 19px">
						<img src="<?php echo base_url() ?>uploads/images/logo.png">		
					</td>
				</tr>
			</table>
			<table align="center" width="100%" cellpadding="7" cellspacing="15">
				<tr>
					<td style="font-size:16px;border:none;font-family:cursive;border-collapse:collapse; text-align:center;"><b>  Password Reset</b>
					</td>
				</tr>
				<tr>
					<td style="font-family:arial;font-size:15px;text-align:center;padding:5px 228px;line-height:2;"> If you've lost your password or wish  to reset it, use this link below to get started. </td>
				</tr>
				<tr>
					<td style="text-align:center;padding-top:5%;"><a href="<?php echo $verification_link ?>" style="text-decoration:none;font-family:arial;font-size:14px;color:#fff;background:#2a97ae;padding:1.5% 2%;">Recover your password</a> </td>
				</tr>
				<tr>
					<td style="text-align:center;font-family:arial;font-size:14px;line-height:2;padding-top:5%;">If you did not request a password reset,you can safely ignore this email.Only a person with access to your email can reset your account password.</td>
				</tr>
			</table>
			<table style="background-color:#000;" width="100%" border="0" cellpadding="9" cellspacing="0">
				<tr>
					<td style="color:#fff;font-size:12px;text-align:center;">
						Copyright © 2016 Roccit. All rights reserved.	
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>