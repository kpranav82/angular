<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table width="800" style="border-collapse:collapse; border:1px solid #ccc;" cellpadding="0" cellspacing="0" align="center">
	<tr>
		<td>
			<table style="background-color:#2a97ae;" width="100%" border="0" cellpadding="9" cellspacing="0">
				<tr>
					<td style="padding: 11px 19px">
						<img src="<?php echo base_url() ?>uploads/images/logo.png">		
					</td>
				</tr>
			</table>
			<table align="center" width="100%" cellpadding="7" cellspacing="15">
				<tr>
					<td style="font-size:16px;border:none;font-family:cursive;border-collapse:collapse; text-align:center;"><b>Please,Verify Your Email Address</b>
					</td>
				</tr>
				<tr>
					<td style="font-family:arial;font-size:15px;">Welcome!<span><?php echo $name; ?></span> Thanks for signing up.Please Click here OR  follow this link to activate your account: </td>
				</tr>
				<tr>
                <td><span>Your Verification Link:- <a href="<?php echo $verification_link ?>" ?><?php echo $verification_link ?></a></span>  </td>
				</tr>
				<tr>
					<td>Cheers!</td>
				</tr>
			</table>
			<table style="background-color:#000;" width="100%" border="0" cellpadding="9" cellspacing="0">
				<tr>
					<td style="color:#fff;font-size:12px;text-align:center;">
						Copyright © 2016 Roccit. All rights reserved.	
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>