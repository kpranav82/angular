var myApp = angular.module('myApp', [
  'ui.router','bw.paging','kendo.directives','ngSanitize','ngFileUpload','ngDialog','720kb.datepicker','JSONedit','oc.lazyLoad'
  ]);
myApp.controller('MainCntl', [
  '$scope',
  '$state',
  '$rootScope',
  '$window',
  '$http',
  function ($scope, $state, $rootScope,$window,$http,$location) {
    if(localStorage.getItem('userId') == 'undefined' ){
      localStorage.setItem('userId',0);
    }
    $rootScope.$state = $state;
    $rootScope.loader = false;
    $http.post(baseUrl + '/instruments/autocompleted_serial_number').success(function(response){
     var fruits = [];
     angular.forEach(response, function (value, prop) {  
      fruits.push(value.serial_number);
    });
     $rootScope.someMovies = fruits;
     $rootScope.moreMovies = fruits;
   });

  }
  ]);
myApp.controller('sidebarCtrl',function($scope,$state,$rootScope){
  $rootScope.state1 = $state; 
});
myApp.run(function ($rootScope, $location, $state, $stateParams, $http, Auth, $window) {
  $rootScope.$on('$stateChangeStart', function (event, next, current, toState) {
    //Hit Api for Roles And give page autorization
    
    if(!localStorage.getItem('userId')){
      localStorage.setItem('userId',0);
    }
    $rootScope.loader = true;
    $rootScope.urls = true;
    $rootScope.sessionData = {};
    $rootScope.side_bar = false;
    $rootScope.slide_btn = false;
    $rootScope.ovrflow = false;
   $rootScope.overhid = false;
    var w = window.innerWidth;
    if(w <= 1024){
	 $rootScope.slide_btn = true;
      $rootScope.sideBar =function(){
        $rootScope.side_bar = $rootScope.side_bar ? false : true;
        $rootScope.overlay = $rootScope.overlay ? false :true;
        $rootScope.overhid = $rootScope.overhid ? false :true;
        angular.element('#btnBack').addClass("slide_in2");
      }
    }
    else{
     $rootScope.side_bar = false;
     $rootScope.overlay = false;
     $rootScope.overhid = false;
      $rootScope.slide_btn = false;
    }
   $rootScope.overlay = false ;
  // $rootScope.lefthidn = function(){
  // console.log(document.getElementsByClassName('side-bar'));
  // }
   // $rootScope.lefthidn();
  $rootScope.overhiden = function(){
     // console.log(document.getElementsByClassName('side-bar'));
   $rootScope.side_bar = false;
   $rootScope.overlay = false;
   $rootScope.overhid = false;
  }
  $rootScope.scrolhiden = function(){
  	$rootScope.side_bar = false;
    $rootScope.overlay = false;
    $rootScope.overhid = false;
  }
    var wind = angular.element($window);
    wind.bind('resize', function () {
     var wi = window.innerWidth;
     if(wi <= 1024){
      angular.element('#test').addClass("slide_in");
      $rootScope.sideBar =function(){
        $rootScope.side_bar = $rootScope.side_bar ? false : true;
        $rootScope.overlay = $rootScope.overlay ? false :true;
        $rootScope.overhid = $rootScope.overhid ? false :true;
        angular.element('#btnBack').addClass("slide_in2");
      }
    }
    angular.element('#test').removeClass("slide_in");
  })
    Auth.getsession().then(function (results) {
      $rootScope.sessionstatus = results.data.status;
      $rootScope.sessionData = results.data.details;
      if($rootScope.sessionstatus != ' ' && $rootScope.sessionstatus != 'undefined'){
        localStorage.setItem('userId', $rootScope.sessionData.user_id);
      }
     if (results.data.status == 1) {
        $rootScope.loggedin = true;
        if(results.data.details.user_id && next.data.auth == false) {
          $state.go('dashboard');
          $rootScope.loader = false;
          $rootScope.urls = false;
        }
      }
      else {
        $rootScope.loader = false;
        $rootScope.urls = false;

        $rootScope.loggedin = false;
        if(next.data.auth == false){
          return   
          $rootScope.loader = false;
          $rootScope.urls = false;
        }
        else if($location.path() == '/signup') {
          $state.go('signup');
          $rootScope.urls = false;

          $rootScope.loader = false;
        } 
        else {
          $state.go('login');
          $rootScope.urls = false;
          $rootScope.loader = false;
        }
      }
      $rootScope.urls = false;
      // API for logout user
      $rootScope.logout = function(){
        $rootScope.loader = true;
        $rootScope.urls = true;
        $http.get(baseUrl+ "/login/logout")
        .success(function(response){
          $rootScope.sessionData={};
          $rootScope.loggedin = false;
          $rootScope.urls = false;
          $rootScope.loader = false;

          localStorage.setItem('userId',0);
          $state.go("login");
        });
      };
    });
  });
});



