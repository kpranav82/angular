$(document).ready(function()
{
	   jQuery.validator.addMethod("noSpace", function (value, element) {
        return value.indexOf(" ") < 0 && value != "";
    }, "No space please");
    jQuery.validator.addMethod("nonNumeric", function (value, element) {
        return this.optional(element) || !value.match(/[0-9]+/);
    }, "Only alphabatic characters allowed.");
    jQuery.validator.addMethod("alpha", function (value, element) {
        return this.optional(element) || !value.match(/[a-z]+/);
    }, "Only alphabatic characters allowed.");


	$('#add_category').validate(
	
	{
		rules:
		{
			category_name:
			{
				required: true,
				minlength: 2
			},
			
			},
		
		 messages:
		 {
			category_name: 
			{
				required: "Please fill your category Name",
				minlength:  "YOUR Category NAME MUST BE ATLEAST LENGTH OF 2 WORDS"
            },
			
	},
	
	
	
	submitHandler: function (form) {

            form.submit();
	}
		});
	
	
	});

