var rout = angular.module('myApp');
rout.config(function($stateProvider,$urlRouterProvider){
	$stateProvider
   .state('signup', {
        url: '/signup',
        templateUrl: 'Templates/sign-up.html',
        controller: 'signupcntl',
        data : {pageName : 'signUp', auth : false},
        resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "signup",
                    files: ['assets/js/controllers/common/signupcntrl.js']
                })
             }]
        }
    })
   .state('login',{
        url:'/login',
        templateUrl:'Templates/login.html',
        controller: 'logincntl',
        data : {pageName : 'login', auth : false},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "login",
                    files: ['assets/js/controllers/common/logincntrl.js']
                })
             }]
        }
   })
   .state('updatepwd',{
        url:'/updatepwd',
        templateUrl:'Templates/updatepwd.html',
        controller: 'logincntl',
        data : {pageName : 'login', auth : false},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "updatepwd",
                    files: ['assets/js/controllers/common/logincntrl.js']
                })
             }]
        }
    })
   .state('dashboard',{
        url:'/dashboard',
        templateUrl:'Templates/dashboard.html',
        controller: 'dashboardcnt',
        data:{auth : true},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "dashboard",
                    files: ['assets/js/controllers/common/dashboardcnt.js']
                })
             }]
        }

    })
    .state('updateProfile',{
        url:'/updateProfile',
        templateUrl:'Templates/updateProfile.html',
        controller: 'updateProfileCnt',
        data:{},
		resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "updateProfile",
                    files: ['assets/js/controllers/updateProfileCnt.js']
                })
             }]
        }
    })
   .state('attribute',{
        url:'/addattribute',
        templateUrl:'Templates/add_attribute.html',
        controller: 'Attributecnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "attribute",
                    files: ['assets/js/controllers/AttributeCnt.js']
                })
             }]
        }
    })
   
   .state('viewAttribute',{
        url:'/viewattribute',
        templateUrl:'Templates/view_attribute.html',
        controller: 'viewAttributecnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "viewattribute",
                    files: ['assets/js/controllers/viewAttributeCnt.js']
                })
             }]
        }
    })
   .state('addInstrument',{
        url:'/addInstrument',
        templateUrl:'Templates/add_instrument.html',
        controller: 'addInstrumentCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "addInstrument",
                    files: ['assets/js/controllers/addInstrumentCnt.js']
                })
             }]
        }
    })
   .state('viewInstrument',{
        url:'/viewInstrument',
        templateUrl:'Templates/view_instrument.html',
        controller: 'viewInstrumentCnt',
        data:{},
   		resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "viewInstrument",
                    files: ['assets/js/controllers/viewInstrumentCnt.js']
                })
             }]
        }
    })
   .state('viewInstrument1',{
        url:'/viewInstrument1/:page/:loc',
        templateUrl:'Templates/view_instrument.html',
        controller: 'viewInstrumentCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "viewInstrument",
                    files: ['assets/js/controllers/viewInstrumentCnt.js']
                })
             }]
        }
    })
   .state('manageInstrumnt',{
        url:'/manageInstrumnt/:id',
        templateUrl:'Templates/manageInstrumnt.html',
        controller: 'InstrumenthistCntl',
        data:{},
   		resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "manageInstrument",
                    files: ['assets/js/controllers/InstrumenthistCntl.js']
                })
             }]
        }
    })
   .state('editInstrument',{
        url:'/editInstrument/:id',
        templateUrl:'Templates/edit_instrument.html',
        controller: 'editInstrumentCnt',
        data:{},
   		resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "editInstrument",
                    files: ['assets/js/controllers/EditInstrumentCnt.js']
                })
             }]
        }
    })
   .state('addmodel',{
        url:'/addmodel',
        templateUrl:'Templates/add_model.html',
        controller: 'addmodelCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "addmodel",
                    files: ['assets/js/controllers/addmodelCntl.js']
                })
             }]
        }
    })
    .state('tutorials',{
        url:'/tutorials',
        templateUrl:'Templates/tutorials.html',
        controller: 'tutorialsCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "tutorials",
                    files: ['assets/js/controllers/tutorialsCnt.js']
                })
             }]
        }
    })
        .state('addInstTutorial',{
        url:'/addInstTutorial',
        templateUrl:'Templates/addInstTutorial.html',
        controller: 'tutorialsCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "addInstTutorial",
                    files: ['assets/js/controllers/tutorialsCnt.js']
                })
             }]
        }
    })
         .state('viewInstTutorial',{
        url:'/viewInstTutorial',
        templateUrl:'Templates/viewInstTutorial.html',
        controller: 'tutorialsCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "viewInstTutorial",
                    files: ['assets/js/controllers/tutorialsCnt.js']
                })
             }]
        }
    })
          .state('AddCustTut',{
        url:'/AddCustTut',
        templateUrl:'Templates/AddCustTut.html',
        controller: 'tutorialsCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "AddCustTut",
                    files: ['assets/js/controllers/tutorialsCnt.js']
                })
             }]
        }
    })
          .state('viewCustmTut',{
        url:'/viewCustmTut',
        templateUrl:'Templates/viewCustmTut.html',
        controller: 'tutorialsCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "viewCustmTut",
                    files: ['assets/js/controllers/tutorialsCnt.js']
                })
             }]
        }
    })
          .state('viewAttrTut',{
        url:'/viewAttrTut',
        templateUrl:'Templates/viewAttrTut.html',
        controller: 'tutorialsCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "viewAttrTut",
                    files: ['assets/js/controllers/tutorialsCnt.js']
                })
             }]
        }
    })
           .state('AddAttrTut',{
        url:'/AddAttrTut',
        templateUrl:'Templates/AddAttrTut.html',
        controller: 'tutorialsCnt',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "AddAttrTut",
                    files: ['assets/js/controllers/tutorialsCnt.js']
                })
             }]
        }
    })
    .state('editmodel1',{
        url:'/editmodel1/:id',
        templateUrl:'Templates/edit_model.html',
        controller: 'editModelCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "editmodel",
                    files: ['assets/js/controllers/editModelcntl.js']
                })
             }]
        }
    })
    .state('addCustomer',{
        cache:false,
        url:'/addCustomer',
        templateUrl:'Templates/add_customer.html',
        controller: 'addcustmCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "addCustomer",
                    files: ['assets/js/controllers/addcustmCntl.js']
                })
             }]
        }
    })
    .state('viewCustomer',{ 
        cache:false, 
        url:'/viewCustomer',
        templateUrl:'Templates/view_customer.html',
        controller: 'viewcustmCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "viewCustomer",
                    files: ['assets/js/controllers/viewcustmCntl.js']
                })
             }]
        }
    })
    .state('manageCustomer',{
        url:'/manageCustomer/:id',
        templateUrl:'Templates/manage_customer.html',
        controller: 'editcustmCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "manageCustomer",
                    files: ['assets/js/controllers/editcustmCntl.js']
                })
             }]
        }
    })
    .state('CustomerInstrument',{
        url:'/CustomerInstrument/:id',
        templateUrl:'Templates/customer_instrument.html',
        controller: 'showcustmCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "CustomerInstrument",
                    files: ['assets/js/controllers/showCustomdataCntl.js']
                })
             }]
        }
    })
    .state('viewInsthist',{
        url:'/viewInsthist/:id',
        templateUrl:'Templates/viewInstrumentHist.html',
        controller: 'showcustmCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "viewInsthist",
                    files: ['assets/js/controllers/showCustomdataCntl.js']
                })
             }]
        }
    })
    .state('InstrumentHistory',{
        url:'/InstrumentHistory/:id',
        templateUrl:'Templates/instrument_history.html',
        controller: 'InstrumenthistCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "InstrumentHistory",
                    files: ['assets/js/controllers/InstrumenthistCntl.js']
                })
             }]
        }
    })
    .state('InstrumentinstHistory',{
        url:'/InstrumentinstHistory/:id',
        templateUrl:'Templates/instrumentinst_history.html',
        controller: 'InstrumenthistCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "InstrumentHistory",
                    files: ['assets/js/controllers/InstrumenthistCntl.js']
                })
             }]
        }
    })
    .state('checklist',{
        url:'/checklist/:chkdata/:model_id/:inst_id',
        templateUrl:'Templates/checklist.html',
        controller: 'checklistCntl',
        data:{},
    	resolve: {
             loginModule: ['$ocLazyLoad', function ($ocLazyLoad) {
                return $ocLazyLoad.load({
                    name: "checklist",
                    files: ['assets/js/controllers/checklistCntrl.js']
                })
             }]
        }
    })
    $urlRouterProvider.otherwise('/login');
});






