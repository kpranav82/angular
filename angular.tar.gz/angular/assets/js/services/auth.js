myApp.factory('Auth', ['$http','$state', function ($http,$state) {
    var obj = {};
    obj.getsession = function () {
   
   return   $http.post(baseUrl+ "/login/s_m").then(function(results){
                return  results;
                 console.log(results)
            });
     
    };
     
    return obj;

  }
]);
