$(document).ready(function()
{
	   jQuery.validator.addMethod("noSpace", function (value, element) {
        return value.indexOf(" ") < 0 && value != "";
    }, "No space please");
    jQuery.validator.addMethod("nonNumeric", function (value, element) {
        return this.optional(element) || !value.match(/[0-9]+/);
    }, "Only alphabatic characters allowed.");
    jQuery.validator.addMethod("alpha", function (value, element) {
        return this.optional(element) || !value.match(/[a-z]+/);
    }, "Only alphabatic characters allowed.");


	$('#add_admin').validate(
	
	{
		rules:
		{
			fname:
			{
				required: true,
				nonNumeric: true,
				minlength: 2
			},
			lname:
			{
				required: true,
				nonNumeric: true,
				minlength: 2
			},
			father_name:
			{
				required:true,
				nonNumeric:true,
				minlength:2
			},
			contact_no:
			{
				required:true,
				alpha:true,
				noSpace:true,
				maxlength:12
				
				
			},
			email:
			{
				required:true,
				noSpace:true
			},
			

			password: 
			{
    		required: true,
			minlength: 2
   			},
   			cpassword:
   			{
	   		required: true,
			equalTo:'#password'   
   			},
  
			},
		
		 messages:
		 {
			fname: 
			{
				required: "Please fill your name",
				nonNumeric: "NO DIGITS ALLOWED",
				minlength:  "YOUR FIRST NAME MUST BE ATLEAST LENGTH OF 2 WORDS"
				
            },
			lname: 
			{
				
				required:"Please fill your Last name",
				nonNumeric:"NO DIGITS ALLOWED",
				minlength:"YOUR LAST NAME MUST BE ATLEAST LENGTH OF 2 WORDS"
				
							},
			father_name:
			{
				required:"Please fill your Father name",
				nonNumeric:"NO DIGITS ALLOWED",
				minlength:"YOUR FATHER NAME MUST BE ATLEAST LENGTH OF 2 WORDS"
			},
			contact_no:
			{
				required:"Please fill your Contact Number",
				alpha:"No Alphabets Allowed here",
				noSpace:"No Space Allowed",
				maxlength:"Unvalid Number!!Please Check the Number and Fill again"
			},
			
			email:
			{
				required: "please Enter YOUR Email",
				noSpace: "Space Not ALLOWEd"
			},
	
			password: {
                required: "Please provide Password",
                minlength: "Your password must be at least 5 characters long"
            },
			cpassword :
			{
				required: "PLEASE FILL YOUR CONFIRM PASSWORD",
				 minlength: "Your password must be at least 5 characters long"

			},	
	},
	
	
	
	submitHandler: function (form) {

            form.submit();
	}
		});
	
	
	});

