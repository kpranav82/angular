var myApp = angular.module('myApp');
myApp.controller('viewInstrumentCnt',['$scope','$http','$stateParams','$rootScope','$timeout', function($scope, $http , $stateParams,$rootScope,$timeout){
 
  $scope.currentPage = 1;
  $scope.pageName = $stateParams.page;
  if($stateParams.loc){

  $scope.location = $stateParams.loc;
  }
  console.log($scope.pageName)
  $scope.instrumentFound = false;
  $rootScope.loader = true;
  var pagenm =1;
  $scope.viewInsturment = function(page_no){
    pagenm = page_no;
  if($scope.viewinst1 != undefined){
    $http.post(baseUrl + "/instruments/get_all_instruments/" + pagenm +"/?q="+ $scope.viewinst1).success(function(response){
      $scope.viewinst = response;
      $rootScope.loader = false;
      if(response.status == 0){
        $scope.instrumentFound = true;
      }
      else{
        $scope.instrumentFound = false;
      }
    })
  }
  else{
    $http.post(baseUrl + "/instruments/get_all_instruments/"+pagenm+"/?q="+$scope.location).success(function(response){
     $scope.viewinst = response;
     $rootScope.loader = false;
     if(response.status == 0){
       $scope.instrumentFound = true;
     }
     else{
       $scope.instrumentFound = false;
     }
    })
  }
}

  if($scope.pageName != 'dashboard'){
    $scope.viewInsturment($scope.currentPage);
  }
 else {
  console.log("==============");
  console.log(pagenm)
  $rootScope.loader = true;
  $http.post(baseUrl + "/instruments/get_all_instruments/1/?q="+$scope.location).success(function(response){
   $scope.viewinst = response;
   $rootScope.loader = false;
   if(response.status == 0){
     $scope.instrumentFound = true;
   }
   else{
     $scope.instrumentFound = false;
   }
 });
}
// else if($scope.location == 'shipping'){
//   $rootScope.loader = true;
//   $http.post(baseUrl + "/instruments/get_all_instruments/1/?q="+ $scope.location).success(function(response){
//    $rootScope.loader = false;
//    console.log(response);
//    $scope.viewinst = response;
//    if(response.status == 0){
//     $scope.instrumentFound = true;
//   }
//   else{
//     $scope.instrumentFound = false;
//   }
// });
// }
// else if($scope.location == 'calibration'){
//  $rootScope.loader = true;
//  $http.post(baseUrl + "/instruments/get_all_instruments/1/?q="+$scope.location).success(function(response){
//    $rootScope.loader = false;
//    $scope.viewinst = response;
//    if(response.status == 0){
//      $scope.instrumentFound = true;
//    }
//    else{
//      $scope.instrumentFound = false;
//    }
//  });
// }
// else if($scope.location == 'repair'){
//  $rootScope.loader = true;
//  $http.post(baseUrl + "/instruments/get_all_instruments/1/?q="+$scope.location).success(function(response){
//    $rootScope.loader = false;
//    $scope.viewinst = response;
//    if(response.status == 0){
//      $scope.instrumentFound = true;
//    }
//    else{
//      $scope.instrumentFound = false;
//    }
//  });
// }
// else{
//  $rootScope.loader = true;
//  $http.post(baseUrl + "/instruments/get_all_instruments/1/?q="+$scope.location).success(function(response){
//    $rootScope.loader = false;
//    $scope.viewinst = response;
//    if(response.status == 0){
//     $scope.instrumentFound = true;
//   }
//   else{
//     $scope.instrumentFound = false;
//   }
// })
// }

$scope.searchInst = function(serchInst){
  $scope.viewinst1 = serchInst.searchInst;
  var searchdata = serchInst.searchInst;
  console.log(serchInst.searchInst);
  $rootScope.loader = true;
  $http.post(baseUrl + "/instruments/get_all_instruments?q=" + searchdata).success(function(response){
   $scope.viewinst = response;
   console.log($scope.viewinst);
   $rootScope.loader = false;
   console.log($scope.viewinst);
   if(response.status == 0){
    $scope.instrumentFound = true;
    $rootScope.successmsg = response.message;
    $rootScope.loader = false;
  }
  else{
    $scope.instrumentFound = false;
    $rootScope.loader = false;
  }
})
}
}])



