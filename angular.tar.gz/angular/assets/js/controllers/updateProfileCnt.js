var myApp = angular.module('myApp');
myApp.controller('updateProfileCnt',['$scope','$http','$stateParams','$rootScope','$timeout','ngDialog','$state',function($scope, $http, $stateParams,$rootScope,$timeout,ngDialog,$state){
	$timeout(function () {
		$rootScope.loader = false;
	}, 3000);	
	$scope.updateP = {};
	$scope.editname = function(){
		var userid = localStorage.getItem('userId')
		console.log(userid);
		$http.get(baseUrl +"/users/profile/"+userid).success(function(response){
        console.log(response);
			if(response.status != 0){
				$scope.updateP.name = response.user.name;
			}
		})
	}
	$scope.editname();
	$scope.updateProfile = function(profileData){
		$http.post(baseUrl + "/users/update_user" ,profileData).success(function(response){
			console.log(response);
			if(response.status == 0){
				$rootScope.issuccess = true;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 3000);
			}
			else{
				$rootScope.issuccess = true;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 3000);
			}
		})
	}
}]);                                                                                               