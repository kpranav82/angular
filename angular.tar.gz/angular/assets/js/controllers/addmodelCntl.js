var myApp = angular.module('myApp');
myApp.controller('addmodelCntl',['$scope','$http','$stateParams','$rootScope','$timeout','$location','$state' ,function($scope, $http , $stateParams,$rootScope,$timeout,$location,$state){

  $scope.instrumentFound = false;
	// $rootScope.loader = true;
  $scope.createModel = function(){
    $http.get(baseUrl + "/attributes/get_attributes_list").success(function(response){
      if(response.status == 1){
        $state.go('editmodel1');
       $rootScope.loader = true;
       $http.post(baseUrl + "/models/add_model").success(function(response){
        $rootScope.loader = false;
        $scope.viewinst = response;
        $rootScope.msgid = response.id;
        $scope.params = response.id;
        var path = $location.path();
        $location.path(path+response.id);
        $rootScope.$apply();
        console.log($scope.viewinst)
        if(response.status == 1){
         $rootScope.issuccess = true;
         $rootScope.successmsg = response.message;
         $http.post(baseUrl + '/models/get_model/'+ $rootScope.msgid).success(function(data){
           $rootScope.jsonadata = data.details;
           $rootScope.loader = false;
           $timeout(function () {
             $rootScope.issuccess = false;
           }, 500);
         })
       }
     })
     }
     else{
       $rootScope.issuccess = true;
       $rootScope.successmsg = response.message;
       $timeout(function () {
           $rootScope.issuccess = false;
         }, 700);
     }
   })
  }
  $scope.jsonCheck = function(daataJson){
    $scope.jsonerror = false;
    $rootScope.loader = true;
    $scope.jsonsuccess = false;
    if(/^[\],:{}\s]*$/.test(daataJson.replace(/\\["\\\/bfnrtu]/g, '@').
      replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
      replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
      $http.post(baseUrl + '/models/update_model/' , daataJson).success(function(response){
        $scope.dataDetail = response;
        $scope.jsonadata = response.details;
        $rootScope.loader = false;
        $scope.jsonsuccess = true;
      })
  }
  else{
    $scope.jsonerror = true;
    $rootScope.loader = false;
  }
}
$scope.currentPage1 = 1;
$scope.viewModel = function(pageNo){
  $rootScope.loader = true;
  $http.post(baseUrl + '/models/model_list/' + pageNo + "/?q="+ $scope.querySa).success(function(response){
    $rootScope.loader = false;
    $scope.modelList = response;
    console.log($scope.modelList);
    if(response.status == 0){
     $scope.instrumentFound = true;
     $rootScope.successmsg = response.message;
     $rootScope.loader = false;
   }
   else{
     $scope.instrumentFound = false;
   }
 })
}
$scope.viewModel($scope.currentPage1);
$scope.searchModel = function(serchMod){
 $scope.querySa = serchMod.Smodel;
 var searchdata = serchMod.Smodel;
 console.log(searchdata);
 $http.post(baseUrl + "/models/model_list?q=" + searchdata).success(function(response){
   $scope.modelList = response;
   console.log($scope.modelList);
   if(response.status == 0){
    $scope.instrumentFound = true;
    $rootScope.successmsg = response.message;
    $rootScope.loader = false;
  }
  else{
    $scope.instrumentFound = false;
  }
})
}
}])



