var myApp = angular.module('myApp');
myApp.controller('addcustmCntl',['$scope','$http','$stateParams','$rootScope','$timeout','$state','$location','$filter' ,function($scope, $http , $stateParams,$rootScope,$timeout,$state,$location,$filter){
	$rootScope.loader = true;
	$scope.customAdd ={};
	$timeout(function () {
		$rootScope.loader = false;
	}, 1000);

    $scope.$watch('jsonData', function(json) {
        $scope.customAdd.details = $filter('json')(json);
    }, true);
    $scope.$watch('customAdd.details', function(json) {
        try {
            $scope.jsonData = JSON.parse(json);
            $scope.wellFormed = true;
        } catch(e) {
            $scope.wellFormed = false;
        }
    }, true);
	$scope.addCustom = function(customerData){
		$scope.jsonerror = false;
		$rootScope.loader = true;
		$scope.jsonsuccess = false;
		 console.log("ppppppppp")
   console.log($scope.jsonData);
		var customdet = customerData.details;
		if(/^[\],:{}\s]*$/.test(customdet.replace(/\\["\\\/bfnrtu]/g, '@').
			replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
			replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
			console.log(customdet);
		$http.post(baseUrl+ "/customer/add_customers", customerData).success(function(response){
			if(response.status == 1){
				$rootScope.issuccess = true;
				$scope.jsonsuccess = true;
				$scope.jsonerror = false;	
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 500);
				$timeout(function () {
					$state.go('viewCustomer');
				},800);
			}
		});
	}
	else {
		// $scope.jsonerror = true;
		// $scope.jsonsuccess = false;
		$rootScope.loader = false;
	}
}


}])



