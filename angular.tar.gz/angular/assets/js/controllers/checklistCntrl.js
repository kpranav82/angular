var myApp = angular.module('myApp');
myApp.controller('checklistCntl',['$scope','$http','$state','$rootScope','$timeout','$stateParams', function($scope, $http,$state,$rootScope,$timeout,$stateParams){
	var checklist_id = $stateParams.chkdata;
	// var model_id = $stateParams.model_id;
	var instrument_id = $stateParams.inst_id;
	var chkeckL_attribute;
	var check_arr = {};
	$scope.check_data1 ={};
	var steps =[];
	var stepsData;
	var status_result;
	var chklength;
	var checkListArr1 = [];
	var status_result;
	var newchecklist_data = [];
	$scope.disvalue = false;
	$scope.checkall = false;
	$rootScope.loader = true;
	$scope.chklist = function(){
		$http.post(baseUrl +'/instruments/model_checklist_result/'+ instrument_id+"?checklist_id="+ checklist_id).success(function(response){
			console.log(response)
			$rootScope.loader = false;
			var checklists = response.checklists.steps;
			if(response.checklist_table.length >0){
			 checklist_data = response.checklist_table[0].steps;
			 newchecklist_data = JSON.parse(checklist_data);
			 status_result = response.checklist_table[0].status_result;
			}
			$scope.instrName = response.checklists._id
			for(i=0;i < checklists.length;i++){
				//check_arr=[];
				check_arr[checklists[i]] = '';
				if(response.checklist_table.length >0){
					if(checklist_data.indexOf(checklists[i]) !== -1){
					  checkListArr1[checklists[i]] = 'checked';
					 // console.log('exists');
				  }else{
					 checkListArr1[checklists[i]]='';
				  }
				}
				checklistsarr = [];
				var j = i;
				if(typeof(checklists[i+1]) == 'object' && i < checklists.length){
					while (i < checklists.length) {
						if(typeof(checklists[i+1]) == 'object' && i < checklists.length){
							checklistsarr.push(checklists[i+1]);
							check_arr[checklists[j]] = checklistsarr;
							i++;
						}else{
							break;
						}
					}
				}
				//checkListArr.push();
			}
			if(status_result == 'completed'){
				$scope.checkall = true;
			}
			else{
				$scope.checkall = false;
			}
			//console.log(checkListArr);
			$scope.check_data = check_arr;
			$scope.checked_index = checkListArr1;
			chklength = Object.keys(check_arr).length;
		});
	}
	$scope.chklist();
	$scope.checkdValue = function(chkd){
		
		if(newchecklist_data != undefined ){
			if(newchecklist_data.indexOf(chkd) !== -1){
				var index = newchecklist_data.indexOf(chkd);
				newchecklist_data.splice(index,1);
			}else{
				newchecklist_data.push(chkd);
			}
		}else{
			newchecklist_data.push(chkd);
		}
		console.log(newchecklist_data);
	}

	$scope.savenote = function(notedata,chckData){
		// steps
		// console.log(steps)
		if(notedata != undefined){
			var note = notedata.notetxt;
		}
		$scope.check_dataa = Object.keys($scope.check_data).length;
		steps= newchecklist_data;
		if($scope.check_dataa == steps.length){
			$scope.status_result = "completed";
			status_result = $scope.status_result;
		}
		else{
			$scope.status_result = "incompleted";
			status_result = $scope.status_result;
		}
		$http.post(baseUrl + '/instruments/checklist_event', {instrument_id,checklist_id,status_result,steps,note}).success(function(response){
			if(response.status == 1){
				$rootScope.issuccess = true;
				$scope.jsonsuccess = true;
				$scope.jsonerror = false;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 500);
				$timeout(function () {
					history.go(-1);
				},700);
			}
		})
	}
	
	// function numberOfCheckboxesSelected() {
	// 	return document.querySelectorAll('input[type=checkbox][name="seatdata[]"]:checked').length;
	// }

	// function onChange() {
	// 	document.getElementById('enable-on-all').disabled = numberOfCheckboxesSelected() < chklength;
	// }

	// document.getElementById('world').addEventListener('change', onChange, false);
}])



