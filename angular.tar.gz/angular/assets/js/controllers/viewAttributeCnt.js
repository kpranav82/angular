var myApp = angular.module('myApp');
myApp.controller('viewAttributecnt',['$scope','$http','$rootScope','$timeout', function($scope, $http,$rootScope,$timeout){
  $scope.instrumentFound = false;
  $scope.currentPage = 1;
  $scope.getAtt = function(page){
   $rootScope.loader = true;
   $http.post(baseUrl +"/attributes/get_attributes_list/" + page + " /?q="+ $scope.queryS).success(function(response){
     $scope.viewAttribute = response;
     $rootScope.loader = false;
     if(response.status == 0){
      $scope.instrumentFound = true;
    }
    else{
      $scope.instrumentFound = false;
    }
  });
 }
 $scope.getAtt($scope.currentPage);
 $scope.searchAttr = function(serchAtt){
  $rootScope.loader = true;
   $scope.queryS = serchAtt.search_att;
   var searchdata = serchAtt.search_att;
   $http.post(baseUrl + "/attributes/get_attributes_list?q=" + searchdata).success(function(response){
    $scope.viewAttribute = response;
    if(response.status == 0){
     $scope.instrumentFound = true;
     $rootScope.successmsg = response.message;
     $rootScope.loader = false;
   }
   else{
     $scope.instrumentFound = false;
     $rootScope.loader = false;
   }
 })
 }
}])



