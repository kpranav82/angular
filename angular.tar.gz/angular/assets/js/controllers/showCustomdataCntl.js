var myApp = angular.module('myApp');
myApp.controller('showcustmCntl',['$scope','$state','$http','$stateParams','$rootScope','$timeout','$location' ,function($scope, $state,$http , $stateParams,$rootScope,$timeout,$location){
	var customer_id = $stateParams.id;
	$scope.customerVal = $stateParams.id;
	$scope.instrumentFound = false;
	$scope.customerInstr = function(){
		$rootScope.loader = true;
		$http.post(baseUrl +'/customer/get_instrument_by_customer/'+ customer_id).success(function(response){
			$rootScope.loader = false;
			$scope.customerInst = response;
			$scope.customer_name = response.customer_name;
			if(response.status == 0){
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$scope.instrumentFound = true;
			}
		})
	}	
	$scope.customerInstr();
	$scope.customerInstssr = function(customerVal){
		$rootScope.loader = true;
		$http.post(baseUrl +'/customer/get_instrument_by_customer/'+ customerVal).success(function(response){
			$rootScope.loader = false;
			$scope.customerInst = response;
			$scope.customer_name = response.customer_name;
			if(response.status == 0){
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$scope.instrumentFound = true;
			}
			else{
				$scope.instrumentFound = false;
			}
		})
	}	
	$scope.$watch('customerVal', function(customerVal) {
		if (!customerVal) {
			return;
		}
		    // $scope.customerVal1 = customerVal;
		    $scope.customerInstssr(customerVal);
		    $state.go('CustomerInstrument', {id:customerVal},{ notify: false });
		});
	$scope.searchCustInst = function(srchCustmInst){
		$scope.serchdata= srchCustmInst.searchcustInst1;
		console.log($scope.serchdata);
		$http.get(baseUrl +'/customer/get_instrument_by_customer/'+customer_id+'/?q=' + $scope.serchdata).success(function(response){
			console.log(response)
			$scope.customerInst = response;
			if(response.status == 0){
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$scope.instrumentFound = true;
			}
			else{
				$scope.instrumentFound = false;
			}
		})
	}
	$scope.stateback = function(){
		alert(1);
	}
}])
