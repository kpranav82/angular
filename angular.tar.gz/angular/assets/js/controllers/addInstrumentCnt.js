  var myApp = angular.module('myApp');

  myApp.controller('addInstrumentCnt',['$scope','$http','$rootScope','$timeout','$state' ,function($scope, $http,$rootScope,$timeout,$state){
    $scope.numArr = [];
    $scope.model_num =  false;
    $scope.BinNumber = function(){
      for(i=1;i<=50;i++){
        $scope.numArr.push(i)
      }
    }
    $scope.BinNumber();

    $scope.getCustM = function(){
      $scope.monthSelectorOptions = {
        start: "year",
        depth: "year"
      };
      $scope.getType = function(x) {
        return typeof x;
      };
      $scope.isDate = function(x) {
        return x instanceof Date;
      };
      $scope.addinst = {};
      $scope.addinst.location = '';
      $rootScope.loader = true;
      $http.post(baseUrl+ "/instruments/add_instrument").success(function(response){
        $rootScope.loader = false;
        $scope.ModelCustom = response;
        $scope.addinst.serial_numb = response.serial_number;
        $scope.addinst.serial_number = response.serial_number;
        $scope.addinst.model_id ='';
        $scope.addinst.customer_id = '';
      })
    }
    $scope.getCustM();
    $scope.addInstrument = function(addInstr){
      console.log(addInstr.model_id)
      $scope.model_idA = addInstr.model_id.split(",")[1];
      $scope.model_nameA = addInstr.model_id.split(",")[0];
      if(addInstr.locationB != undefined){
        var locationBin_comb = addInstr.location +"-"+ addInstr.locationB;
      }
      else{
       var locationBin_comb = addInstr.location
     }
     var addInsrument = {
      customer_id : addInstr.customer_id,
      date : addInstr.date,
      location : locationBin_comb,
      model_id : $scope.model_idA,
      serial_number : addInstr.serial_number,
      note : addInstr.note
    }
    $rootScope.loader = true;
    $http.post(baseUrl+ "/instruments/save_instrument",addInsrument).success(function(response){
      $scope.insertInst = response;
      $rootScope.loader = false;
      if(response.status == 1){
        $rootScope.issuccess = true;
        $rootScope.successmsg = response.message;
        $rootScope.loader = false;
        $timeout(function () {
          $rootScope.issuccess = false;
        }, 500); 
        $timeout(function () {
          $rootScope.loader = true;
          $state.go('viewInstrument');
          $rootScope.loader = false;
        },800);
      }
      else{
        $rootScope.issuccess = true;
        $rootScope.successmsg = response.message;
        $rootScope.loader = false;
        $timeout(function () {
          $rootScope.issuccess = false;
        }, 3000);
      }
    })
  }
  $scope.modelSlctd = function(modelName){
    $scope.model_idA = modelName.split(",")[0];
    $scope.addinst.serial_number =  $scope.addinst.serial_numb;
    // seria_num = $scope.addinst.serial_numb;
    $scope.model_num =  true;
    $scope.model_Name = $scope.model_idA;
  }
}])



