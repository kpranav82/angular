var myApp = angular.module('myApp');
myApp.controller('InstrumenthistCntl',['$scope','$http','$stateParams','$rootScope','$timeout','$filter','ngDialog', function($scope, $http , $stateParams,$rootScope,$timeout,$filter,ngDialog){
	  $scope.currentPage = 1;
	$scope.inst_id = $stateParams.id;

   // $scope.allData ={}
   $scope.allData = true;
   $scope.showData = true;
   var arrdata = [];
   
   var alldata = 'all,attribute,checklist,move,note,creation';
   var query = alldata; 
   
   $scope.hist = function(param,valueType){
   	var page = valueType;
   	if(param == 'all'){
   		var query = alldata; 
    console.log("all data");
    console.log(query);
    console.log("------");
   	}
   	else{
   		var index = arrdata.indexOf(param);
   		console.log(index)
   		if(index > -1){
   			arrdata.splice(index, 1);
        console.log("arrdata");
        console.log(arrdata);
        console.log("--------");
   		}
   		else{
        console.log(param);
   			arrdata.push(param);
        // if(arrdata.length == 4){
        // 	arrdata.push("all");
        // }
        // else{
        // arrdata.push(param);
        // }
         console.log("arrdata---------");
        console.log(arrdata);
        console.log("--------");
   		}
   		//console.log(arrdata)
   		var query = arrdata.join(); 
   	}

   	if((arrdata.length == 4 && arrdata.length > 0) || query == alldata){
   		$scope.allData = true;
		
   	}
   	else{
   		$scope.allData = false;
   	}
   	if(arrdata.length == 0){
   		$scope.allData = true;
   	}

   	$rootScope.loader = true;
   	$http.post(baseUrl +'/instruments/get_instrument_history/'  + $scope.inst_id +'/'+page+ '?filter=' + query).success(function(response){
    
   		$scope.histDetails = response.List;
   		$scope.histDet = response;
   		console.log($scope.histDetails);
   		$rootScope.loader = false;
   		console.log(response)
   		var actions_data = response.List;
   		console.log("]]]]]]]]")
   		console.log(response)
   		if(response.List.length >=0){
	  	   $scope.instr_name = response.List[0].instrument_name;
	    }
	  	for(var key in actions_data){			
	  		if(actions_data[key].action == 'creation'){
	  			actions_data[key].actions_data = 'Create Record';
	  		}
	  		else if(actions_data[key].action == 'move'){
	  			var obj = JSON.parse(actions_data[key].actions);
	  			var array = $.map(obj, function(value, index) {
	  				return [value];
	  			});
	  			for(i=0;i<array.length;i++){
	  				actions_data[key].actions_data = "Moved to " +array[i];
	  			}
	  		}
	  		else if(actions_data[key].action == 'note'){
	  			//actions_data[key].actions_data = "changed 'Attribute 1' to ' new value ' from ' old value 'Note : ' note text '";
            var obj = JSON.parse(actions_data[key].actions);
	  			var array = $.map(obj, function(value, index) {
	  				return [value];
	  			});
	  			for(i=0;i<array.length;i++){
	  				actions_data[key].actions_data = "Note:  " +array[i];
	  			}
	  		}
	  		else if(actions_data[key].action =='attribute'){
            console.log(actions_data[key].actions);
	  			var obj = JSON.parse(actions_data[key].actions);
	  			var keyprev = obj.prev;
	  			var replprev = keyprev.replace(/\\/g, "");
	  			var parsevalue = JSON.parse(replprev);
            console.log("0000000000000");
	  			console.log(parsevalue);
	  			var inskey; 
	  			var insvalue;
	  			for(var keypreval in parsevalue){
	  				inskey = keypreval;
	  				insvalue = parsevalue[keypreval];
	  			}
	  			var keynew = obj.new;
	  			var replnewprev = keynew.replace(/\\/g, "");
            console.log(keynew);
           if(keynew!=""){
	  			var parsenewvalue = JSON.parse(replnewprev);
	  			console.log(parsenewvalue);
           }
	  			var insnewkey; 
	  			var insnewvalue;
	  			for(var keynewpreval in parsenewvalue){
	  				inskey = keynewpreval;
	  				insvalue = parsenewvalue[keynewpreval];
	  			}
	  			if(keyprev !=''){
	  				var limitFilter = $filter('limitTo')(insvalue, 6, 0);
	  				actions_data[key].actions_data = "changed  "+ inskey+" from "+ limitFilter+"..." ;
	  			}
	  			else{
	  				var limitFilter = $filter('limitTo')(insvalue, 6, 0);
	  				actions_data[key].actions_data = "New Attribute "+ inskey +"value "+limitFilter;
	  			}
	  			$scope.moredata = function(index){
	  				var preObj = JSON.parse($scope.histDetails[index].actions);
                console.log(preObj);
               
	  				var keyprev1 = preObj.prev;
	  				var attrKey;
	  				var attrValue;
	  				var dialogArr = [];
	  				var keyupdate = preObj.update;
	  				var updateValue;
	  				var newData = preObj.new;
	  				var newvalue;
	  				var newKey;
	  				var newAttributeData = [];
                console.log(preObj.prev);
                 console.log(preObj.new);
               
	  				if(preObj.prev !="null" && preObj.new==""){
	  					var prevfinal = keyprev1.replace(/\\/g, "");
	  					var preData = JSON.parse(prevfinal);
	  					var updatefinal = keyupdate.replace(/\\/g, "");
	  					var updateData = JSON.parse(updatefinal);
	  					for(var k in preData){
	  						attrKey = k;
	  						attrValue = preData[k];
	  						dialogArr.push('<tr><td>'+attrKey+'</td><td>'+attrValue+'</td>');
	  					}
	  					for(var key in updateData){
	  						updateValue = updateData[key];
	  						dialogArr.push('<td>'+updateValue+'</td></tr>');
	  					}
	  					
	  					dialogData = dialogArr.join(' ');
	  					ngDialog.open({template: "<h4>Updated Attributes</h4><hr>"+
	  						"<table class='attrstyle'><tr><th>Attribute Name </th> <th> Old Value</th><th>New Value</th></tr>"
	  						+dialogData+"</table>",
	  						plain: true
	  					});
	  				}
	  				else if(preObj.new != "" && preObj.prev == "null"){
	  					var newfinal = newData.replace(/\\/g, "");
	  					var newAttrData = JSON.parse(newfinal);
	  					for(var newk in newAttrData){
	  						newValue = newAttrData[newk];
	  						newKey = newk;
	  						newAttributeData.push('<tr><td>'+newKey+'</td><td>'+newValue+'</td>');
	  					}
	  					
	  					dialogNewData = newAttributeData.join(' ');
	  					console.log(dialogNewData);
	  					ngDialog.open({template: "<h4>New Attribute</h4><hr><table class='attrstyle'><tr><th>Attribute Name </th><th>New Value</th></tr>"+
	  						dialogNewData+"</table>",
	  						plain: true
	  					})
	  				}
	  				else{
	  					var prevfinal = keyprev1.replace(/\\/g, "");
	  					var preData = JSON.parse(prevfinal);
	  					var updatefinal = keyupdate.replace(/\\/g, "");
                    console.log(updatefinal);
                    return;
	  					var updateData = JSON.parse(updatefinal);
	  					var newfinal = newData.replace(/\\/g, "");
	  					var newAttrData = JSON.parse(newfinal);
	  					for(var k in preData){
	  						attrKey = k;
	  						attrValue = preData[k];
	  						dialogArr.push('<tr><td>'+attrKey+'</td><td>'+attrValue+'</td>');
	  					}
	  					for(var key in updateData){
	  						updateValue = updateData[key];
	  						dialogArr.push('<td>'+updateValue+'</td></tr>');
	  					}
	  					for(var newk in newAttrData){
	  						newValue = newAttrData[newk];
	  						newKey = newk;
	  						newAttributeData.push('<tr><td>'+newKey+'</td><td>'+newValue+'</td>');
	  					}
	  					
	  					dialogData = dialogArr.join(' ');
	  					dialogNewData = newAttributeData.join(' ');
	  					ngDialog.open({template: "<h4>Updated Attributes</h4><hr>"+
	  						"<table class='attrstyle'><tr><th>Attribute Name </th> <th> Old Value</th><th>New Value</th></tr>"
	  						+dialogData+"</table><br><h4>New Attribute</h4><hr><table class='attrstyle'><tr><th>Attribute Name </th><th>New Value</th></tr>"
	  						+dialogNewData+"</table>",
	  						plain: true
	  					})
	  				}
	  				
	  				
	  			}
	  		}
	  		else if(actions_data[key].action =='checklist'){
	  			var obj = JSON.parse(actions_data[key].actions);
	  			var array = $.map(obj, function(value, index) {
	  				return [value];
	  			});console.log(array)
	  			for(i=0;i<array.length;i++){
	  				actions_data[key].actions_data = array[2] + " checklist "+ array[1];
	  			}
	  			// actions_data[key].actions_data = "Completed checklist 'checklist 1' changed 'Attribute 1' to ' new value ' (originally 'old value' )";
	  			// console.log(actions_data[key].actions_data)
	  		}
	  		else{
	  			actions_data[key].actions_data = 'no action';
	  		}
	  	}
	  	$scope.histDetails = actions_data;
	  	
	  })
}
// $scope.hist($scope.currentPage);
$scope.hist('all');
}])



