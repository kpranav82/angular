var myApp = angular.module('myApp');
myApp.controller('dashboardcnt', function($rootScope,$timeout,$scope,$http,$state,$location){
  $scope.instSerch =  true;
  $scope.instrumentFound = false;
  $rootScope.loader = true;
  $timeout(function () {
    $rootScope.loader = false;
  }, 1000);
  
  $scope.manufacLoc = function(){
    $state.go("viewInstrument1",{page : 'dashboard',loc : 'manufacturing'});
  }
  $scope.shippingLoc = function(){
    $state.go("viewInstrument1",{page : 'dashboard',loc : 'shipping'});
  }
  $scope.calibLoc = function(){
    $state.go("viewInstrument1",{page : 'dashboard',loc : 'calibration'});
  }
  $scope.repairLoc = function(){
    $state.go("viewInstrument1",{page : 'dashboard',loc : 'repair'});
  }
  $scope.fieldLoc = function(){
    $state.go("viewInstrument1",{page : 'dashboard',loc : 'field'});
  }
  $scope.searchAuto = function(daata){
    $http.post(baseUrl+'/instruments/autocompleted_serial_number_result/'+daata).success(function(response){
      if(response.status==1){
        $scope.daataC = response.result[0]._id;
        $state.go('manageInstrumnt',{id : $scope.daataC})
      }
      else{
        $scope.instrumentFound = true;
        $timeout(function () {
         $scope.instrumentFound = false;
       }, 3000);
      }
    });
  }
})
