var myApp = angular.module('myApp');
var baseUrl = "http://198.61.174.115/roccit";
myApp.controller('signupcntl',['$scope','$http','$state','$rootScope','$timeout', function($scope, $http,$state,$rootScope,$timeout){
  $scope.hidespan = true;
  $scope.existEmail = false;
  $scope.hideSpan= function(){
    $scope.existEmail = false;
  }
  $scope.hidecpwd=function(){
    $scope.hidespan = false;
  }
  //function for password match validation and register API
  $scope.regist = function(data){
    if(data.password !== data.Cpassword){
      $scope.paswrderr ="Password Mismatch";
    }
    else{
      $scope.paswrderr="";
      var logData = {'name' : data.fullname,'email' : data.email, 'password' : data.password, 'confirm_password' : data.Cpassword}
      $rootScope.loader = true;
      $http.post(baseUrl+ "/login/register", logData)
      .success(function(response){
      console.log(response);
      $rootScope.loader = false;
        if(response.status == 1){
         $rootScope.issuccess = true;
         $rootScope.successmsg = response.message;
         $timeout(function () {
           $rootScope.issuccess = false;
          $state.go('login')
         }, 3000);
        
       }
       else{
         $rootScope.successmsg = response.message;
         $rootScope.loader = false;
         $rootScope.issuccess = true;
         $timeout(function () {
           $rootScope.issuccess = false;
         }, 3000);            
       }
     });
    }
  }
}])



