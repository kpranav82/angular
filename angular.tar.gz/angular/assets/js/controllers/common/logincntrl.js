var myApp = angular.module('myApp');
myApp.directive('modal', function () {
    return {
      template: '<div class="modal fade">' + 
          '<div class="modal-dialog">' + 
            '<div class="modal-content">' + 
              '<div class="modal-header">' + 
                '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' + 
                '<h4 class="modal-title">{{ buttonClicked }} </h4>' + 
              '</div>' + 
              '<div class="modal-body" ng-transclude></div>' + 
            '</div>' + 
          '</div>' + 
        '</div>',
      restrict: 'E',
      transclude: true,
      replace:true,
      scope:true,
      link: function postLink(scope, element, attrs) {
          scope.$watch(attrs.visible, function(value){
          if(value == true)
            $(element).modal('show');
          else
            $(element).modal('hide');
        });

        $(element).on('shown.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = true;
          });
        });

        $(element).on('hidden.bs.modal', function(){
          scope.$apply(function(){
            scope.$parent[attrs.visible] = false;
          });
        });
      }
    };
  });
myApp.controller('logincntl',['$scope', '$http', '$timeout', '$state', '$rootScope','$location', function ($scope, $http, $timeout, $state, $rootScope,$location) {
  $scope.loginfo = {};
   $scope.showModal = false;
    $scope.buttonClicked = "";
    var currentURL = $location.url()
   var idid  ; var codecode;
  $scope.email_verify = function(){
    if(currentURL.indexOf("?") != -1){
     var idandcode = currentURL.split("?")[1];
     var idonly = idandcode.split("&")[0];
     idid = idonly.split("=")[1];
     var codeonly = idandcode.split("&")[1];
     codecode = codeonly.split("=")[1];
     $http.post(baseUrl +"/login/verification/"+ idid+ "/"+codecode).success(function(response){
       if(response.status == 0){
            $rootScope.verified_err = true;
            $rootScope.verified_error = response.message;
            $rootScope.loader = false;
            $timeout(function () {
            $rootScope.verified_err = false;
            }, 3000)
        } 
     else{
         $rootScope.verified_msg1 = true;
         $rootScope.verified_msg = response.message;
         $rootScope.loader = false;
         $timeout(function () {
           $rootScope.verified_msg1 = false;
         }, 3000)
     }
     })
   }
 
 }
     $scope.email_verify();
    $scope.updatePwd = function(pwddata){
      $rootScope.loader = true;
      var idandcode1 = currentURL.split("?")[1];
      var idonly1 = idandcode1.split("&")[0];
      var idid1 = idonly1.split("=")[1];
      var codeonly1 = idandcode1.split("&")[1];
      var codecode1 = codeonly1.split("=")[1];
      $http.post(baseUrl+"/login/email_update_password/"+ idid1+"/"+codecode1 , pwddata).success(function(response){
        console.log(response);
     	 if(response.status == 1){
         	$rootScope.issuccess = true;
            $rootScope.successmsg = response.message;
            $rootScope.loader = false;
            $timeout(function () {
            $rootScope.issuccess = false;
            $state.go('login');
          }, 3000)
     	 }
      else{
      	    $rootScope.issuccess = true;
            $rootScope.successmsg = response.message;
            $rootScope.loader = false;
            $timeout(function () {
            $rootScope.issuccess = false;
          }, 3000)
      }
      });
   }
    $scope.toggleModal = function(btnClicked){
        $scope.buttonClicked = btnClicked;
        $scope.showModal = !$scope.showModal;
    };
    $scope.forget_password = function(emailId){
      $rootScope.loader = true;
      $http.post(baseUrl + "/login/forget_password/" , emailId).success(function(response){
        console.log(response);
         if(response.status == 0){
            $rootScope.issuccess = true;
            $rootScope.successmsg = response.message;
            $rootScope.loader = false;
            $timeout(function () {
            $rootScope.issuccess = false;
          }, 3000)
        }
        else{
            $rootScope.issuccess = true;
            $rootScope.successmsg = response.message;
            $rootScope.loader = false;
            $timeout(function () {
            $rootScope.issuccess = false;
          }, 3000)
        }  
      })
    }
  //API for login user
  $scope.loginf = function (loginfo) {
    $rootScope.loader = true;
    console.log("loginfo")
    console.log(loginfo)
    var loginData = loginfo;
    $http.post(baseUrl + '/login/login', loginData).success(function(response) {
      $scope.resultLogin = response;
      if(response.status == 1){
        $rootScope.loader = false;
        $state.go('dashboard');
      } 
      else {
        $scope.error = response.message;
        $rootScope.loader = false;
        $timeout(function () {
          $scope.error = '';
        }, 5000);
      }
    });
  }
  $scope.email_verify = function(emailL){
     $rootScope.loader = true;
  console.log(emailL);
    $http.post(baseUrl +"/login/resend_verification_code/", emailL).success(function(response){
      $rootScope.loader = false;
      console.log(response);
    })
  }
}]);
