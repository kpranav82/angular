var myApp = angular.module('myApp');
myApp.controller('viewcustmCntl',['$scope','$http','$stateParams','$rootScope','$timeout','$window','$location','$state',function($scope, $http , $stateParams,$rootScope,$timeout,$window,$location,$state){
	$scope.instrumentFound = false;
	$scope.currentPage3 = 1;
	$rootScope.loader = true;
	var locationUrl = window.location.href;
    var locationOriginalUrl = locationUrl.split("#")[1];
	$scope.viewcustomer = function(pageNumber){
		$http.post(baseUrl+ "/customer/list_customers/" + pageNumber+ " /?q="+ $scope.customerDet).success(function(response){
			$rootScope.loader = false;
			$rootScope.listCustom = response;
			$scope.listCustom = response;
		})
	}
	$scope.viewcustomer($scope.currentPage);
	$scope.deleteCustomer= function(customerId,k){
		var index = k.key;
		$scope.id = customerId.id;
		swal({
		  title: "Are you sure?",
		  text: "You will not be able to recover this imaginary file!",
		  type: "warning",
		  showCancelButton: true,
		  confirmButtonColor: "#DD6B55",
		  confirmButtonText: "Yes, delete it!",
		  closeOnConfirm: false
		},
		function(){
			$http.post(baseUrl+"/customer/delete_customers/"+$scope.id).success(function(response){
				if(response.status == 1){
					$scope.listCustom.List.splice(index, 1);
					$rootScope.issuccess = true;
					$rootScope.successmsg = response.message;
					$rootScope.loader = false;
					$timeout(function () {
						$rootScope.issuccess = false;
					}, 3000);
				}
			})
		  swal("Deleted!", "Your imaginary file has been deleted.", "success");
		});
	}
	$scope.searchCustom =function(searchCustomer){
		$scope.customerDet = searchCustomer.customer;
		$rootScope.loader = true;
		$http.post(baseUrl +"/customer/list_customers?q=" +$scope.customerDet).success(function(response){
			$rootScope.loader = false;
			$scope.listCustom = response;
			if(response.status == 0){
				$scope.instrumentFound = true;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
			}
			else{
				$scope.instrumentFound = false;
			}
		})

	}
}])
