var myApp = angular.module('myApp');
myApp.controller('tutorialsCnt',['$scope','$http','$stateParams','$rootScope','$timeout','$state','$location','$filter' ,function($scope, $http , $stateParams,$rootScope,$timeout,$state,$location,$filter){
	$rootScope.loader = true;
	$timeout(function () {
		$rootScope.loader = false;
	}, 1000);
}]);
	
