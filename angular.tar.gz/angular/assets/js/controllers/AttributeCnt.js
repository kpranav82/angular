var myApp = angular.module('myApp');
myApp.controller('Attributecnt',['$scope','$http','$state','$rootScope','$timeout', function($scope, $http,$state,$rootScope,$timeout){
  $rootScope.loader = true;
  $timeout(function () {
    $rootScope.loader = false;
  }, 1000);
  $scope.attributeAdd = {}
  $scope.attributeAdd.default ="";
  $scope.attributeAdd.type = "num";
  $scope.issuccess = false;
  $scope.addAttribute = function(attributeAdd){
   $rootScope.loader = true;
   
   $http.post(baseUrl +"/attributes/add_attribute",attributeAdd).success(function(response){
     $rootScope.loader = false;
     if(response.status == 1){	
      $rootScope.issuccess = true;
      $rootScope.successmsg = response.message;
      console.log(response);
      $timeout(function () {
        $rootScope.issuccess = false;
      }, 3000);
      $timeout(function () {
        $state.go('viewAttribute');
      },3500);
    }
    else{
      $rootScope.issuccess = true;
      $rootScope.successmsg = response.message;

      $timeout(function () {
        $rootScope.issuccess = false;
      }, 3000);
    }
  });
 }
 $scope.chngevalue = function(value){
   $scope.value = value;
   $scope.attributeAdd.default ="";
   // alert($scope.value)
   // alert(value);
  // if(value == 'num'){

  //   $scope.valid = '/^[0-9]*$/';
  
  //   $scope.validerror = 'Enter integer value';
  
  // }
  //  if(value == 'str'){
  //         $scope.valid = '/^[a-zA-Z]*$/';
  
  //   $scope.validerror = 'Enter string value';
  //   // alert(value)
  

  // }
  // else if(value == 'bool'){
  //     // $scope.valid = '/^[a-zA-Z_ ]*$/';
  //     // $scope.validerror = 'Enter string value';
  //   }
  //   else if(value == 'date'){
  //     $scope.valid = '/^([0-9]{2}[-/][0-9]{2}[-/][0-9]{4})|([0-9]{8})/';
  //     $scope.validerror = 'Enter date format';
  //   }
  //   else if(value== 'option'){
  //     $scope.valid = '';
  //     $scope.validerror = '';
  //     }
}
$scope.chngevalue('num');
}])



