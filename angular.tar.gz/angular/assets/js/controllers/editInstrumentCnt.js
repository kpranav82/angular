var myApp = angular.module('myApp');
var images_path = new Array();
var submitBtn   = new Array();
myApp.directive('fileModel', ['$parse', function ($parse) {
	return {
		restrict: 'A',
		link: function(scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;
			element.bind('change', function(){
				scope.$apply(function(){
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);
myApp.service('fileUpload', ['$http', function ($http,$scope,$rootScope) {
	this.uploadFileToUrl = function(file, uploadUrl){
		var fd = new FormData();
		fd.append('file', file);
		$http.post(uploadUrl, fd, {
			transformRequest: angular.identity,
			headers: {'Content-Type': undefined}
		}).success(function(response){
			var pathImg = "http://112.196.33.88/roccit/uploads/instruments/thumbnail/";  
			console.log(response.id);
			var List = {
				created_at:response.created_at,
				image_name:response.id,
				image_path:"http://112.196.33.88/roccit/uploads/instruments/thumbnail/"+response.id
			}
			console.log(images_path);
			images_path.push(List);
		})
		.error(function(){
			console.log("unsuccess");
		});
		
	}
}]);
myApp.controller('editInstrumentCnt',['$scope','$http','$stateParams','$rootScope','$timeout','Upload','fileUpload','ngDialog','$state',function($scope, $http, $stateParams,$rootScope,$timeout,Upload,fileUpload,ngDialog,$state){
	$scope.numArr = [];
	$scope.BinNumber = function(){
		for(i=1;i<=50;i++){
			$scope.numArr.push(i)
		}
	}
	$scope.BinNumber();
	$scope.editinst = {};
	$scope.popcomp = false;
	var oldData = {};
	var model_id;
	$scope.zoomimg = false;
	$scope.atributeData = {};
	$scope.unusedData = {};
	$scope.btnrevrt = true; 
	var resp= {};
	$scope.updateData = true;
	$scope.disselect = false;
	$scope.showthumb = false;
	$scope.note = {};
	$scope.selectedData = '';
	$scope.selectbox = [
	{value: 'true', name: 'True'},
	{value: 'false', name: 'False'}
	];
	$scope.instrument_id = $stateParams.id;
	var instrument_id = $stateParams.id;
	$scope.testdis = function(oldVal, newVal, index){
		if($scope.note[index].action != 'insert'){
			$scope.note[index].action = 'update'; 
		}
		if(submitBtn.indexOf(index) == -1){
			submitBtn.push(index);  
		}
		if(oldVal == newVal){
			if($scope.note[index].action != 'insert'){
				$scope.note[index].action = 'old';
			}
			if(submitBtn.indexOf(index) != -1){
				var index = submitBtn.indexOf(index);
				submitBtn.splice(index, 1);
			}
		}
		if(submitBtn.length > 0){
			$scope.updateData = false;  
		}else{
			$scope.updateData = true;
		}
	}
	$scope.revertfxn= function(oldData , newData,index){
		$scope.note[index].default = oldData;
		if(submitBtn.indexOf(index) != -1){
			var index = submitBtn.indexOf(index);
			submitBtn.splice(index, 1);
		}
		if(submitBtn.length > 0){
			$scope.updateData = false;  
		}else{
			$scope.updateData = true;
		}
	}
	$scope.editinst.location = 'manufacturing';
	$scope.inst_id = $stateParams.id;
	$scope.slctedData = function(){
		$rootScope.loader = true;
		$http.post(baseUrl + "/instruments/get_instrument/" + $scope.inst_id).success(function(response){
			$scope.note = response.attibute_result;
			var resp = $scope.note;
			model_id = response.Instrument.model_id;
			$rootScope.loader = false;
			$scope.atributeData = $scope.note;
			for(data in resp){
				resp[data].old = resp[data].default;
				oldData = resp[data].old;
		}
		$scope.editinst.locationComb = response.Instrument.location;
		$scope.editinst.location = $scope.editinst.locationComb.split('-')[0];
		$scope.editinst.locationBin = $scope.editinst.locationComb.split('-')[1];
		$scope.model_name = response.model_name;
	})
	}
	$scope.slctedData();
	$scope.editInstrument = function(EditInst1){
		if(EditInst1.locationBin != undefined){
			$scope.locationas =EditInst1.location +"-"+ EditInst1.locationBin;
		}
		else{
			$scope.locationas =EditInst1.location;
		}
		var editData = {
			instrument_id : $scope.instrument_id,
			location:$scope.locationas,
			note:EditInst1.note
		};
		$rootScope.loader = true;
		$http.post(baseUrl + "/instruments/move/" , editData).success(function(response){
			$rootScope.loader = false;
			$scope.editinst1 = response;
			if(response.status == 1){
				$rootScope.issuccess = true;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 3000);
			}
			else{
				$rootScope.issuccess = true;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 3000);
			}
		})
	}
	$scope.notefxn = function(noteData){
		$rootScope.loader = true;
		$scope.noteData.instrument_id = $stateParams.id;
		$http.post(baseUrl + '/instruments/note', noteData).success(function(response){
			$rootScope.loader = false;
			if(response.status == 1){
				$rootScope.issuccess = true;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 3000);
			}
		})
	}
	$scope.chcklist = function(){
		$http.post(baseUrl + '/instruments/model_checklist/'+ $scope.inst_id).success(function(chkdata){
			$scope.checklists = chkdata;
			$scope.checklistData = "";
		})
	}
	$scope.chcklist();
	$scope.unusedAttribute = function(){
		$http.post(baseUrl + '/instruments/unused_attributes/'+ $scope.inst_id).success(function(response){
			$scope.unusedData = response.unused_attributes;
			console.log("unusedData")
			console.log(response);
		})
	}
	$scope.unusedAttribute();
	
	$scope.addDataUnused = function(){
		if ($scope.selectedData != "" && $scope.selectedData != undefined){
			$scope.msg =$scope.selectedData;
			$scope.attribute_name =$scope.unusedData[$scope.msg].attribute_id;
			var default_val = $scope.unusedData[$scope.msg].default;
			$scope.default1 = default_val.trim();
			console.log("old value");
			console.log($scope.default1);
			$scope.type = $scope.unusedData[$scope.msg].type;
			var dataa = $scope.note;
			$scope.unusedData.splice($scope.msg, 1);
			$scope.selectedData =""
			var note_data = {'attribute_name' : $scope.attribute_name, 'default': $scope.default1,'old': $scope.default1,'type' : $scope.type,'action':'insert'};
			var index = $scope.attribute_name.trim();
			if (!$scope.note) $scope.note = {};
			$scope.note[index] = note_data;
			submitBtn.push('new');
			if(submitBtn.length > 0){
				$scope.updateData = false;  
			}else{
				$scope.updateData = true;
			}
		}else{
			alert('Please select unused attribute');
			return;
		}
	}
	$scope.updateAttribute = function(note){
		var data = $scope.note;
		console.log("okokokokok")
		console.log(data);
		var insert = new Array();
		var update = new Array();
		var old = new Array();
		for(var key in data){
			if(data[key].action == 'insert'){
				insert.push(data[key]);
			}else if(data[key].default == data[key].old){
				console.log('')
			}else{
				update.push(data[key]);
			}
		}
		
		var up_data = {
			'instrument_id':$scope.inst_id,
			'new':insert,
			'update':update,	 
			'note': note,
			'all':data
		};
		$http.post(baseUrl + '/instruments/update_attribute/', up_data).success(function(response){
			if(response.status == 1){
				console.log(response);
				$scope.slctedData();
				$scope.unusedAttribute();
				$scope.selectedData = '';
				$rootScope.issuccess = true;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 3000);
			}
		})	
	}
	$scope.changeValue =function(){
		$scope.updateData = false;
	}
	$scope.uploadImg = function(){
		var file = $scope.files;
		if(file != '' ){
			var uploadUrl = baseUrl+'/instruments/upload_file/'+$scope.inst_id ;
			var fd = new FormData();
			fd.append('file', file);
			
			$http.post(uploadUrl, fd, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			}).success(function(response){
				var pathImg = "http://112.196.33.88/roccit/uploads/instruments/thumbnail/";  
				var List = {
					created_at:response.created_at,
					image_name:response.id,
					image_path:"http://112.196.33.88/roccit/uploads/instruments/thumbnail/"+response.id
				}
				$scope.getImages();
				images_path.push(List);
			})
			.error(function(){
				console.log("unsuccess");
			});
			$scope.files = '';
		}}
		$scope.getImages = function(){
			$http.get(baseUrl+'/instruments/get_images/'+$scope.inst_id).success(function(response){
				if(response.List != undefined){
					images_path = response.List;  
				}else{
					images_path = []; 
				}
				$scope.imgPath = response;
			});
		}
		$scope.getImages();
		$scope.deleteImg = function(id , index){
			if(confirm('Are You Sure you want to delete???')){
				$http.post(baseUrl + '/instruments/delete_image/' + id).success(function(response){
					images_path.splice(index,1);
				});
			}
		}
		$scope.zoomImage = function(url){
			ngDialog.open({  template: '<img src="'+url +'" style="">',
				plain: true
			});
		}
		$scope.runChecklist = function(chkData){
			var checklist_id = chkData;
			// $http.post(baseUrl +'/instruments/model_checklist_result/'+ model_id+"?checklist_id="+ checklist_id).success(function(response){
				$state.go("checklist",{chkdata : chkData , inst_id : $scope.inst_id});
   			// console.log(response);
   // })
}
$scope.checkcomp = function(inorcom){
	var checklist_id = inorcom;
	$http.post(baseUrl + '/instruments/checklist_notification',{ instrument_id , checklist_id}).success(function(response){
		console.log(response);
		if(response.status == 1){
			$scope.popcomp = true;
			$scope.notiShow = response.status_result;
			$timeout(function () {
				$scope.popcomp = false;
			}, 3000);
		}
	})
}
}])



