var myApp = angular.module('myApp');
myApp.controller('editcustmCntl',['$scope','$http','$stateParams','$rootScope','$timeout','$state','$filter' ,function($scope, $http , $stateParams,$rootScope,$timeout,$state,$filter){
	var customer_id = $stateParams.id;
	$scope.editCustom = function(){
		$scope.CustomerData={}
		$scope.id = $stateParams.id;
		$rootScope.loader = true;
		$http.post(baseUrl+ "/customer/profile/" + customer_id ).success(function(response){
		// console.log(response.customer.details)
		var jsondata = JSON.parse(response.customer.details);
		$scope.jsonData = jsondata;
	    $scope.$watch('jsonData', function(json) {
	        $scope.CustomerData.details = $filter('json')(json);
	        console.log(($scope.CustomerData.details));
	    }, true);
	    $scope.$watch('CustomerData.details', function(json) {
	        try {
	            $scope.jsonData = JSON.parse(json);
	            $scope.wellFormed = true;
	        } catch(e) {
	            $scope.wellFormed = false;
	        }
	    }, true);


			$scope.CustomerData.name = response.customer.name;
			$scope.CustomerData.user_name = response.customer.user_name;
			// $scope.CustomerData.details = ;
			$rootScope.loader = false;
			// $scope.CustomerDataDeta = JSON.parse($scope.CustomerData.details);
		})
	}
	$scope.editCustom();
	$scope.updateCustom = function(data){
		$scope.customer ={}
		var customdet = data.details;
		if (/^[\],:{}\s]*$/.test(customdet.replace(/\\["\\\/bfnrtu]/g, '@').
			replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
			replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
			data.customer_id = $stateParams.id;
		$rootScope.loader = true;
		$scope.jsonerror = false;
		$http.post(baseUrl +'/customer/update_customer', data).success(function(response){
			if(response.status == 1){
				$scope.jsonsuccess = true;
				$scope.jsonerror = false;
				$rootScope.issuccess = true;
				$rootScope.successmsg = response.message;
				$rootScope.loader = false;
				$timeout(function () {
					$rootScope.issuccess = false;
				}, 3000);
				$timeout(function () {
					$state.go('viewCustomer');
				},3500);
			}
		})
	}
	else {
		// $scope.jsonerror = true;
		// $scope.jsonsuccess = false;
		$rootScope.loader = false;
	}
}

$scope.searchCustInst =function(searchData){
	$scope.queryS = searchData.searchcustInst;
	var searchdata = searchData.searchcustInst;
	searchdata.id= customer_id;
	$http.post(baseUrl + '/customer/get_instrument_by_customer?q=' +  searchdata).success(function(response){
			// console.log(response);
		})
}
}])
