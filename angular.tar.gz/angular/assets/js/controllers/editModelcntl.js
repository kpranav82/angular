var myApp = angular.module('myApp');
myApp.controller('editModelCntl',['$scope','$http','$stateParams','$rootScope','$timeout','$stateParams','$state','$filter' ,function($scope, $http , $stateParams,$rootScope,$timeout,$stateParams,$state,$filter){
  $scope.jsonadata ={};
  var model_id = $stateParams.id;
  $scope.data = {};
  $scope.editModel = function(){
  // $rootScope.loader = true;
  $http.post(baseUrl + '/models/get_model/' + model_id).success(function(response){
    $scope.dataDetail = response;
    $rootScope.loader = false;
    $scope.identifier = response.identifier;
    $scope.data.modelNo = $scope.identifier.split('-')[0];
    $scope.data.modelname = $scope.identifier.split('-')[1];

    var jsonadata1 = response.details;
    // console.log(jsonadata1);
    // return;
    // var str =response.details;
    // $scope.jsonadata1 = str.replace(/""/g, '');
    // var jsonadata2 = jsonadata1.replace(/\\/g, "");
   // var jsonadata = jsonadata2;
    // $scope.jsonadata2 = jsonadata1.replace(/""/g, '');
    // var jsonadata3 = $scope.jsonadata2.replace(/\\/g, "");
    $scope.jsonData = JSON.parse(jsonadata1);
      $scope.$watch('jsonData', function(json) {
          $scope.data.jsonadata = $filter('json')(json);
      }, true);
      $scope.$watch('data.jsonadata', function(json) {
          try {
              $scope.jsonData = JSON.parse(json);
              $scope.wellFormed = true;
          } catch(e) {
              $scope.wellFormed = false;
          }
      }, true);
  })

}
$scope.editModel();
$scope.jsonCheck = function(daataJson){
 $scope.modelNo = daataJson.modelNo;
 $scope.modelname = daataJson.modelname;
 $scope.jsondata = daataJson.jsonadata;
 console.log($scope.jsondata)
 var stringJson = JSON.stringify($scope.jsondata);
 var details1 =  {details:JSON.parse($scope.jsondata)};
 console.log($scope.jsondata);
 //var abcdddd = $scope.jsonadata.replace(/↵/g,"<br>");
  //console.log({details:JSON.parse(abcdddd)} );
 
    // $scope.jsonadata['identifier']= modelfull;
    details1['identifier'] = $scope.modelNo+'-'+$scope.modelname;
    
    $scope.jsonerror = false;
    $rootScope.loader = true;
    $scope.jsonsuccess = false;
    
      $http.post(baseUrl + '/models/update_model/' + model_id ,details1).success(function(response){
        $rootScope.loader = false;
        if(response.status == 1){
        
         $rootScope.issuccess = true;
         $rootScope.successmsg = response.message;
         $rootScope.loader = false;
         $timeout(function () {
           $rootScope.issuccess = false;
         }, 3000);
         $timeout(function () {
           $state.go('addmodel');
         },3500);
         $rootScope.loader = false;
         $scope.jsonsuccess = true;
       }
       else{
         $rootScope.issuccess = true;
         $rootScope.successmsg = response.message;
         $rootScope.loader = false;
         $timeout(function () {
           $rootScope.issuccess = false;
         }, 3000);
         $rootScope.loader = false;
         $scope.jsonsuccess = true;
       }
     })
    $rootScope.loader = false;
  
}
}]);


