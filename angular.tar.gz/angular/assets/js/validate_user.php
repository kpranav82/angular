$(document).ready(function()
{
	   jQuery.validator.addMethod("noSpace", function (value, element) {
        return value.indexOf(" ") < 0 && value != "";
    }, "No space please");
    jQuery.validator.addMethod("nonNumeric", function (value, element) {
        return this.optional(element) || !value.match(/[0-9]+/);
    }, "Only alphabatic characters allowed.");
    jQuery.validator.addMethod("alpha", function (value, element) {
        return this.optional(element) || !value.match(/[a-z]+/);
    }, "Only alphabatic characters allowed.");


	$('#add_user').validate(
	
	{
		rules:
		{
			fname:
			{
				required: true,
				minlength: 2,
				nonNumeric: true
			},
			lname:
			{
				required:true,
				minlength:2,
				nonNumeric:true
			},
			father_name:
			{
				required:true,
				minlength:2,
				nonNumeric:true
			},
			contact_no:
			{
				required:true,
				maxlength:12,
				alpha:true,
				noSpace:true
			},
			email:
			{
				required:true,
				noSpace:true
			},
			

			password: {
    		required: true,
			minlength: 2
    
   			},
   			cpassword:
   			{
	   		required: true,
			equalTo:'#password'   
   			},
  
			},
		
		 messages:
		 {
			fname: 
			{
				required: "Please fill your name",
				minlength:  "YOUR FIRST NAME MUST BE ATLEAST LENGTH OF 2 WORDS",
				nonNumeric: "NO DIGITS ALLOWED"
            },
			lname: 
			{
				
				required:"Please fill your Last name",
				minlength:"YOUR FIRST NAME MUST BE ATLEAST LENGTH OF 2 WORDS",
				nonNumeric:"NO DIGITS ALLOWED"
							},
			father_name:
			{
				required:"Please fill your Father name",
				minlength:"YOUR FATHER NAME MUST BE ATLEAST LENGTH OF 2 WORDS",
				nonNumeric:"NO DIGITS ALLOWED"
			},
			contact_no:
			{
				required:"Please fill your Contact Number"",
				maxlength:"Unvalid Number!!Please Check the Number and Fill again",
				alpha:"No Alphabets Allowed here",
				noSpace:"No Space Allowed"
			},
			
			email:
			{
				required: "please Enter YOUR Email",
				noSpace: "Space Not ALLOWEd"
			},
	
			password: {
                required: "Please provide Password",
                minlength: "Your password must be at least 5 characters long"
            },
			cpassword :
			{
				required: "PLEASE FILL YOUR CONFIRM PASSWORD",
				 minlength: "Your password must be at least 5 characters long"

			},	
	},
	
	
	
	submitHandler: function (form) {

            form.submit();
	}
		});
	
	
	});

